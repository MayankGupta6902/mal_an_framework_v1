# 🔐 HashCalc - Advanced File Hashing and Analysis Tool

A single-file, multi-functional Python CLI utility for calculating cryptographic hashes, analyzing files, and verifying integrity.

---

## ✅ Features

- 🧠 Calculates MD5, SHA1, SHA2, SHA3, BLAKE2 hash digests
- 🧪 File entropy analysis
- 🗂️ Recursive hashing of entire folders
- 🔎 PE signature detection (on Windows)
- 🔁 File comparison using selected hash algorithm
- 🔐 Hash verification (e.g. verify SHA256 against known hash)
- 📋 Clipboard support (copy any hash digest)
- 🧾 Export results in JSON or CSV
- 🎨 Colored output (if `colorama` installed)
- 📊 Progress bar (if `tqdm` installed)

---

## 📦 Requirements

Install the dependencies:

```bash
pip install -r requirements.txt
