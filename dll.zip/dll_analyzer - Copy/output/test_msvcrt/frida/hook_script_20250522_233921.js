
    'use strict';

    // Common WinAPI functions to monitor
    const hookTargets = [
        // File operations
        { module: 'kernel32.dll', function: 'CreateFileA' },
        { module: 'kernel32.dll', function: 'CreateFileW' },
        { module: 'kernel32.dll', function: 'WriteFile' },
        { module: 'kernel32.dll', function: 'ReadFile' },
        { module: 'kernel32.dll', function: 'DeleteFileA' },
        { module: 'kernel32.dll', function: 'DeleteFileW' },
        { module: 'kernel32.dll', function: 'CopyFileA' },
        { module: 'kernel32.dll', function: 'CopyFileW' },
        
        // Process operations
        { module: 'kernel32.dll', function: 'CreateProcessA' },
        { module: 'kernel32.dll', function: 'CreateProcessW' },
        { module: 'kernel32.dll', function: 'OpenProcess' },
        { module: 'kernel32.dll', function: 'TerminateProcess' },
        
        // Registry operations
        { module: 'advapi32.dll', function: 'RegOpenKeyExA' },
        { module: 'advapi32.dll', function: 'RegOpenKeyExW' },
        { module: 'advapi32.dll', function: 'RegCreateKeyExA' },
        { module: 'advapi32.dll', function: 'RegCreateKeyExW' },
        { module: 'advapi32.dll', function: 'RegSetValueExA' },
        { module: 'advapi32.dll', function: 'RegSetValueExW' },
        { module: 'advapi32.dll', function: 'RegDeleteValueA' },
        { module: 'advapi32.dll', function: 'RegDeleteValueW' },
        
        // Network operations
        { module: 'ws2_32.dll', function: 'socket' },
        { module: 'ws2_32.dll', function: 'connect' },
        { module: 'ws2_32.dll', function: 'send' },
        { module: 'ws2_32.dll', function: 'recv' },
        { module: 'wininet.dll', function: 'InternetOpenA' },
        { module: 'wininet.dll', function: 'InternetOpenW' },
        { module: 'wininet.dll', function: 'InternetConnectA' },
        { module: 'wininet.dll', function: 'InternetConnectW' },
        
        // Memory operations
        { module: 'kernel32.dll', function: 'VirtualAlloc' },
        { module: 'kernel32.dll', function: 'VirtualAllocEx' },
        { module: 'kernel32.dll', function: 'VirtualProtect' },
        { module: 'kernel32.dll', function: 'VirtualProtectEx' }
    ];

    // Log function
    function log(message) {
        send({
            type: 'log',
            message: message
        });
    }

    // Log API call details
    function logApiCall(apiName, args, retval, context) {
        send({
            type: 'api_call',
            api_name: apiName,
            args: args,
            retval: retval !== undefined ? retval.toString() : 'void',
            timestamp: new Date().toISOString(),
            context: context || {}
        });
    }

    // Helper functions to convert arguments to meaningful strings
    function stringFromPtr(ptr) {
        if (ptr.isNull())
            return 'NULL';
        try {
            return ptr.readUtf8String();
        } catch (e) {
            try {
                return ptr.readUtf16String();
            } catch (e2) {
                return `ptr(${ptr})`;
            }
        }
    }

    function formatCreateFileArgs(args) {
        return {
            lpFileName: stringFromPtr(args[0]),
            dwDesiredAccess: args[1].toUInt32(),
            dwShareMode: args[2].toUInt32(),
            lpSecurityAttributes: args[3],
            dwCreationDisposition: args[4].toUInt32(),
            dwFlagsAndAttributes: args[5].toUInt32(),
            hTemplateFile: args[6]
        };
    }

    function formatRegistryArgs(args) {
        return {
            hKey: args[0],
            lpSubKey: stringFromPtr(args[1]),
            ulOptions: args[2] ? args[2].toUInt32() : 0,
            samDesired: args[3] ? args[3].toUInt32() : 0
        };
    }

    function formatCreateProcessArgs(args) {
        return {
            lpApplicationName: stringFromPtr(args[0]),
            lpCommandLine: stringFromPtr(args[1]),
            lpProcessAttributes: args[2],
            lpThreadAttributes: args[3],
            bInheritHandles: args[4].toUInt32(),
            dwCreationFlags: args[5].toUInt32(),
            lpEnvironment: args[6],
            lpCurrentDirectory: stringFromPtr(args[7])
        };
    }

    // Install hooks when script is loaded
    log('Frida script loaded, installing hooks...');

    // Hook all specified API functions
    hookTargets.forEach(target => {
        try {
            const targetModule = Process.getModuleByName(target.module);
            const targetFunction = targetModule.getExportByName(target.function);
            
            log(`Hooking ${target.module}!${target.function}...`);
            
            Interceptor.attach(targetFunction, {
                onEnter: function(args) {
                    // Save context information for the onLeave callback
                    this.functionName = target.function;
                    this.moduleName = target.module;
                    
                    // Format arguments based on function type
                    let formattedArgs = {};
                    
                    if (target.function.startsWith('CreateFile')) {
                        formattedArgs = formatCreateFileArgs(args);
                    }
                    else if (target.function.includes('RegOpenKey') || 
                             target.function.includes('RegCreateKey')) {
                        formattedArgs = formatRegistryArgs(args);
                    }
                    else if (target.function.startsWith('CreateProcess')) {
                        formattedArgs = formatCreateProcessArgs(args);
                    }
                    else {
                        // Generic argument logging - just convert addresses to strings
                        for (let i = 0; i < 8; i++) {  // Log up to 8 arguments
                            try {
                                formattedArgs['arg' + i] = args[i] ? args[i].toString() : 'null';
                            } catch (e) {
                                break;  // Stop when we run out of arguments
                            }
                        }
                    }
                    
                    this.formattedArgs = formattedArgs;
                    
                    log(`Called ${target.module}!${target.function}`);
                },
                
                onLeave: function(retval) {
                    logApiCall(
                        `${this.moduleName}!${this.functionName}`, 
                        this.formattedArgs, 
                        retval,
                        {
                            threadId: this.threadId,
                            backtrace: Thread.backtrace(this.context).map(DebugSymbol.fromAddress)
                        }
                    );
                }
            });
        } catch (e) {
            log(`Error hooking ${target.module}!${target.function}: ${e.message}`);
        }
    });

    // Monitor DLL loads
    Process.enumerateModules({
        onMatch: function(module) {
            log(`Module loaded: ${module.name} (${module.base}, ${module.size} bytes)`);
        },
        onComplete: function() {}
    });
    
    log('All hooks installed. Monitoring API calls...');
    