
# PowerShell script to call system safely using WinDbg
$logFile = "output\dll_analysis\msvcrt\debugger\debug_system_1748005021.log"

# Create a dummy process to attach to
$notepadProcess = Start-Process notepad -PassThru

try {
    # Give notepad time to start
    Start-Sleep -Seconds 2
    
    # Create a temporary WinDbg command file
    $dbgCommandFile = [System.IO.Path]::GetTempFileName()
    
    # Write commands to the file
    @"
.load msvcrt.dll
.sympath+ c:\windows\symbols
.reload
? msvcrt!system
.echo Calling system...
$$>a< "{$dbgCommandFile}"
.echo Function call completed
q
"@ | Out-File -FilePath $dbgCommandFile -Encoding ascii
    
    # Call WinDbg with the command file
    $windbgOutput = & cdb -p $notepadProcess.Id -c "`$<$dbgCommandFile" 2>&1
    
    # Log the output
    $windbgOutput | Out-File -FilePath $logFile
    
    # Return the output
    $windbgOutput
}
catch {
    "Error executing WinDbg: $_" | Out-File -FilePath $logFile -Append
    throw $_
}
finally {
    # Clean up
    if ($notepadProcess -ne $null) {
        try { Stop-Process -Id $notepadProcess.Id -Force -ErrorAction SilentlyContinue } catch { }
    }
}
