# DLL Analyzer

A comprehensive Windows DLL analysis framework for dynamic and static analysis of DLL files. This tool helps security researchers and system administrators analyze DLL behavior, extract potential indicators of compromise, and generate detailed reports.

## Features

- **Multiple Analysis Modes**
  - **Full Analysis**: Combines structure analysis, function invocation, and runtime monitoring
  - **Structure Analysis**: Static analysis of PE headers, imports, exports, and sections
  - **Function Analysis**: Targeted analysis of specific exported functions
  - **Monitoring**: Runtime behavior monitoring using Procmon and Frida

- **Comprehensive Analysis**
  - PE structure validation and parsing
  - Import/export table analysis
  - Function invocation with multiple methods
  - System activity monitoring
  - Automated IOC (Indicators of Compromise) extraction
  - VirusTotal integration

- **Robust Reporting**
  - JSON reports with detailed analysis results
  - HTML visualization of analysis findings
  - Risk scoring and assessment
  - Exportable monitoring data

## System Requirements

- Windows 10/11
- Python 3.8 or newer
- Administrator privileges (for certain monitoring features)

## Installation

1. Clone the repository:
   ```
   git clone https://github.com/yourusername/dll_analyzer.git
   cd dll_analyzer
   ```

2. Install required dependencies:
   ```
   pip install -r requirements.txt
   ```

3. Install optional dependencies for extended functionality:
   ```
   pip install frida frida-tools lief
   ```

4. Ensure Procmon (Process Monitor) is available:
   - Download from SysInternals and place executables in the `tools/procmon` directory
   - Or ensure it's available in your system PATH

## Usage

### Command Line Interface

```bash
python analyze_dll.py --input path/to/dll --mode [full|structure|ftn|monitor] [options]
```

### Batch Script (Windows)

```
run_analyzer.bat path/to/dll [options]
```

### Options

- `--input`, `-i`: Path to the DLL file (required)
- `--mode`, `-m`: Analysis mode (default: full)
  - `full`: Complete analysis
  - `structure`: Structure analysis only
  - `ftn`: Function analysis
  - `monitor`: Runtime monitoring only
- `--function`, `-f`: Function name to analyze (for ftn mode)
- `--output`, `-o`: Custom output directory
- `--timeout`, `-t`: Maximum execution time in seconds (default: 60)
- `--verbose`, `-v`: Enable detailed console output
- `--html`, `-h`: Generate HTML report
- `--virustotal`, `-vt`: Check file against VirusTotal

### Examples

```bash
# Full analysis with HTML report
python analyze_dll.py --input malware.dll --mode full --html

# Analyze specific function
python analyze_dll.py --input kernel32.dll --mode ftn --function GetVersion

# Monitor only with VirusTotal check
python analyze_dll.py --input suspicious.dll --mode monitor --virustotal
```

## Project Structure

```
dll_analyzer/
├── analyze_dll.py       # Main entry script
├── run_analyzer.bat     # Windows batch runner
├── src/
│   ├── core/            # Core analysis components
│   │   ├── dll_validator.py
│   │   └── ioc_extractor.py
│   ├── loaders/         # DLL loading and function invocation
│   │   └── invocation_engine.py
│   ├── monitors/        # Runtime monitoring
│   │   ├── frida_monitor.py
│   │   └── procmon_monitor.py
│   └── utils/           # Utilities
│       ├── exceptions.py
│       ├── file_utils.py
│       ├── logger.py
│       ├── report_visualizer.py
│       └── virustotal.py
├── tools/               # External tools
│   └── procmon/         # Process Monitor executables
├── testing_sample/      # Sample DLLs for testing
├── logs/                # Log files
└── output/              # Analysis output
```

## Testing and Error Handling

The framework includes a test script that verifies functionality using `msvcrt.dll`:

```bash
python test_analyzer.py
```

The test framework:
- Validates DLL structure analysis
- Tests function invocation
- Verifies monitoring capabilities
- Performs automated error diagnosis
- Provides suggestions for fixing issues

## Extending the Framework

The DLL Analyzer is designed to be modular and extensible:

1. **Adding new analyzers**: Extend the core modules in `src/core/`
2. **Supporting new invocation methods**: Add to `src/loaders/invocation_engine.py`
3. **Integrating additional monitoring tools**: Create new monitors in `src/monitors/`
4. **Extending IOC detection**: Update patterns in `src/core/ioc_extractor.py`

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Acknowledgments

- The SysInternals team for Process Monitor
- The Frida project for dynamic instrumentation
- The LIEF and pefile projects for PE parsing

## Disclaimer

This tool is meant for research and defense purposes only. Always ensure you have proper authorization before analyzing any DLL files. 