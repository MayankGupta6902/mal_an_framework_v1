param(
    [Parameter(Mandatory=$true, Position=0)]
    [string]$dllPath,
    
    [Parameter(Mandatory=$false)]
    [switch]$html,
    
    [Parameter(Mandatory=$false)]
    [int]$maxExports = 0,
    
    [Parameter(Mandatory=$false)]
    [ValidateSet("all", "rundll32", "ctypes", "c_harness", "debugger")]
    [string]$engine = "all"
)

Write-Host "Setting up environment for DLL Analysis..." -ForegroundColor Green

# Check if the DLL exists
if (-not (Test-Path $dllPath)) {
    Write-Host "Error: The specified DLL was not found: $dllPath" -ForegroundColor Red
    exit 1
}

# Check Python dependencies
Write-Host "Checking Python dependencies..." -ForegroundColor Cyan
try {
    python -c "import pefile, lief, ctypes" 2>$null
}
catch {
    Write-Host "Installing required dependencies..." -ForegroundColor Yellow
    pip install pefile lief
}

# Check if output directory exists
if (-not (Test-Path "output\dll_analysis")) {
    New-Item -Path "output\dll_analysis" -ItemType Directory | Out-Null
}

# Build command arguments
$arguments = @($dllPath)

if ($html) {
    $arguments += "--html"
}

if ($maxExports -gt 0) {
    $arguments += "--max-exports"
    $arguments += $maxExports
}

if ($engine -ne "all") {
    $arguments += "--engine"
    $arguments += $engine
}

# Run the DLL analyzer
Write-Host "Running DLL analyzer..." -ForegroundColor Green
$argumentString = $arguments -join " "
Write-Host "Command: python dll_analyzer.py $argumentString" -ForegroundColor Cyan

try {
    python dll_analyzer.py $argumentString
    
    if ($LASTEXITCODE -eq 0) {
        Write-Host "Analysis completed successfully." -ForegroundColor Green
    }
    else {
        Write-Host "Analysis completed with errors. Check logs for details." -ForegroundColor Yellow
    }
}
catch {
    Write-Host "Error running DLL analyzer: $_" -ForegroundColor Red
    exit 1
} 