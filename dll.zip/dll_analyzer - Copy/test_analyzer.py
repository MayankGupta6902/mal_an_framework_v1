#!/usr/bin/env python3
"""
Test script for the DLL Analyzer framework
Runs a full analysis on msvcrt.dll and verifies the output
"""

import os
import sys
import json
import time
import logging
from pathlib import Path

from src.utils.logger import DLLAnalyzerLogger
from src.utils.exceptions import DLLAnalyzerException
from src.core.dll_validator import DLLValidator
from src.core.ioc_extractor import IOCExtractor
from src.loaders.invocation_engine import InvocationEngine
from src.monitors.procmon_monitor import ProcmonMonitor
from src.monitors.frida_monitor import FridaMonitor
from src.utils.report_visualizer import ReportVisualizer

# Configure logging
log_dir = Path("logs")
os.makedirs(log_dir, exist_ok=True)

# Initialize logger
logger = DLLAnalyzerLogger("TestAnalyzer", verbose=True)

def test_dll_validation():
    """Test DLL structure validation"""
    logger.info("Testing DLL structure validation...")
    
    try:
        dll_path = Path("testing_sample") / "msvcrt.dll"
        validator = DLLValidator(logger)
        results = validator.validate(str(dll_path))
        
        # Verify we have expected fields
        assert "pe_info" in results, "Missing PE info in validation results"
        assert "exports_count" in results, "Missing exports count in validation results"
        assert "imports" in results, "Missing imports in validation results"
        
        logger.info(f"Validation successful. Found {results['exports_count']} exports.")
        return True, results
    
    except AssertionError as e:
        logger.error(f"Validation test failed: {str(e)}")
        return False, {"error": str(e)}
    
    except Exception as e:
        logger.error(f"Unexpected error in validation test: {str(e)}")
        return False, {"error": str(e)}

def test_export_invocation():
    """Test invoking exports from the DLL"""
    logger.info("Testing DLL export invocation...")
    
    try:
        dll_path = Path("testing_sample") / "msvcrt.dll"
        engine = InvocationEngine(logger)
        
        # Get exports
        exports = engine.list_exports(str(dll_path))
        assert len(exports) > 0, "No exports found in msvcrt.dll"
        
        # Find a simple function to test (toupper is a good candidate)
        toupper_export = None
        for export in exports:
            if export.get("name") == "toupper":
                toupper_export = export
                break
        
        # If toupper not found, try _toupper
        if not toupper_export:
            for export in exports:
                if export.get("name") == "_toupper":
                    toupper_export = export
                    break
        
        # If still not found, just use the first export
        if not toupper_export and exports:
            toupper_export = exports[0]
        
        assert toupper_export is not None, "Could not find a suitable export to test"
        
        export_name = toupper_export.get("name")
        logger.info(f"Testing invocation of export: {export_name}")
        
        # Invoke the export
        try:
            result = engine.invoke_function_ctypes(
                str(dll_path), 
                export_name, 
                timeout=10
            )
            logger.info(f"Export {export_name} invocation result: {result}")
            return True, {"export": export_name, "result": str(result)}
        except Exception as e:
            logger.warning(f"Error invoking {export_name}: {str(e)}")
            # Consider this a soft failure - continue with tests
            return True, {"export": export_name, "error": str(e)}
    
    except AssertionError as e:
        logger.error(f"Export invocation test failed: {str(e)}")
        return False, {"error": str(e)}
    
    except Exception as e:
        logger.error(f"Unexpected error in export invocation test: {str(e)}")
        return False, {"error": str(e)}

def test_monitoring():
    """Test monitoring DLL execution"""
    logger.info("Testing DLL execution monitoring...")
    
    try:
        dll_path = Path("testing_sample") / "msvcrt.dll"
        
        # Create output directory
        output_dir = Path("output") / "test_msvcrt"
        os.makedirs(output_dir, exist_ok=True)
        
        # Start Procmon monitoring
        try:
            procmon = ProcmonMonitor(output_dir=str(output_dir), logger=logger)
            procmon_started = procmon.start_monitoring()
            logger.info(f"Procmon monitoring started: {procmon_started}")
        except Exception as e:
            logger.warning(f"Failed to start Procmon: {str(e)}")
            procmon_started = False
        
        # Start Frida monitoring
        try:
            frida = FridaMonitor(output_dir=str(output_dir), logger=logger)
        except Exception as e:
            logger.warning(f"Failed to initialize Frida: {str(e)}")
            frida = None
        
        # Execute the DLL using rundll32
        logger.info(f"Executing msvcrt.dll using rundll32...")
        cmd = ["rundll32.exe", str(dll_path), "DllMain"]
        
        import subprocess
        process = subprocess.Popen(cmd)
        
        # Try to attach Frida to the process if available
        if frida:
            try:
                frida.attach_to_process(process.pid)
                logger.info(f"Frida attached to process {process.pid}")
            except Exception as e:
                logger.warning(f"Failed to attach Frida: {str(e)}")
        
        # Wait for execution
        time.sleep(10)
        
        # Terminate the process
        process.terminate()
        
        # Collect monitoring results
        results = {}
        
        # Stop Procmon monitoring if started
        if procmon_started:
            try:
                procmon.stop_monitoring()
                logger.info("Procmon monitoring stopped")
                
                # Export to CSV
                csv_file = procmon.export_to_csv()
                if csv_file:
                    logger.info(f"Procmon log exported to {csv_file}")
                    
                    # Parse events
                    events = procmon.parse_csv_to_json(csv_file)
                    if events:
                        results["procmon"] = {
                            "event_count": len(events),
                            "csv_file": csv_file
                        }
            except Exception as e:
                logger.warning(f"Error processing Procmon results: {str(e)}")
        
        # Get Frida results if available
        if frida:
            try:
                results["frida"] = {
                    "api_calls": len(frida.api_calls),
                    "dll_loads": len(frida.dll_loads)
                }
                logger.info(f"Captured {len(frida.api_calls)} API calls with Frida")
            except Exception as e:
                logger.warning(f"Error processing Frida results: {str(e)}")
        
        return True, results
    
    except Exception as e:
        logger.error(f"Unexpected error in monitoring test: {str(e)}")
        return False, {"error": str(e)}

def test_full_pipeline():
    """Test the full analysis pipeline"""
    logger.info("Testing full analysis pipeline...")
    
    results = {
        "validation": None,
        "invocation": None,
        "monitoring": None,
        "success": False
    }
    
    # Run DLL validation
    validation_success, validation_results = test_dll_validation()
    results["validation"] = {
        "success": validation_success,
        "results": validation_results
    }
    
    # Run export invocation
    invocation_success, invocation_results = test_export_invocation()
    results["invocation"] = {
        "success": invocation_success,
        "results": invocation_results
    }
    
    # Run monitoring
    monitoring_success, monitoring_results = test_monitoring()
    results["monitoring"] = {
        "success": monitoring_success,
        "results": monitoring_results
    }
    
    # Overall success if all tests passed
    overall_success = validation_success and invocation_success and monitoring_success
    results["success"] = overall_success
    
    # Save results to file
    output_dir = Path("output") / "test_results"
    os.makedirs(output_dir, exist_ok=True)
    
    result_path = output_dir / f"test_results_{time.strftime('%Y%m%d_%H%M%S')}.json"
    with open(result_path, "w") as f:
        json.dump(results, f, indent=2)
    
    logger.info(f"Test results saved to: {result_path}")
    logger.info(f"Overall test success: {overall_success}")
    
    return overall_success, results

def fix_errors_from_logs():
    """Attempt to diagnose and fix errors from logs"""
    logger.info("Checking logs for errors...")
    
    error_log_path = Path("logs") / "errors.log"
    if not error_log_path.exists():
        logger.warning("No error log file found")
        return []
    
    fixes = []
    
    with open(error_log_path, "r") as f:
        log_content = f.read()
    
    # Check for common errors and suggest fixes
    if "Procmon not found" in log_content:
        fixes.append({
            "error": "Procmon not found",
            "fix": "Ensure Procmon.exe is in the tools/procmon directory"
        })
    
    if "No module named 'frida'" in log_content:
        fixes.append({
            "error": "Frida module not found",
            "fix": "Install Frida using: pip install frida frida-tools"
        })
    
    if "Failed to load DLL" in log_content:
        fixes.append({
            "error": "DLL loading failed",
            "fix": "Ensure msvcrt.dll is in the testing_sample directory and readable"
        })
    
    if "Failed to attach to process" in log_content:
        fixes.append({
            "error": "Frida failed to attach to process",
            "fix": "Run as administrator or disable antivirus temporarily"
        })
    
    # Log all fixes
    for fix in fixes:
        logger.info(f"Suggested fix for error '{fix['error']}': {fix['fix']}")
    
    return fixes

if __name__ == "__main__":
    logger.info("Starting DLL Analyzer test suite")
    
    # Run the full pipeline test
    success, results = test_full_pipeline()
    
    # If test failed, check logs for errors and suggest fixes
    if not success:
        fixes = fix_errors_from_logs()
        if fixes:
            logger.info("Found potential issues. Please apply the suggested fixes and run tests again.")
            for fix in fixes:
                print(f"ERROR: {fix['error']}")
                print(f"FIX: {fix['fix']}")
                print()
    
    # Exit with appropriate code
    sys.exit(0 if success else 1) 