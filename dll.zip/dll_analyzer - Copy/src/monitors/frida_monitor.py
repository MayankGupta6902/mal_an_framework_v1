"""
Frida integration for the DLL Analyzer framework.
Provides API hooking and behavior monitoring using Frida.
"""

import json
import os
import subprocess
import sys
import tempfile
import time
from pathlib import Path
from typing import Dict, List, Optional, Union, Any, Set

from src.utils.exceptions import FridaError, MissingToolError
from src.utils.logger import DLLAnalyzerLogger


class FridaMonitor:
    """
    Wrapper for Frida to monitor and hook DLL API calls.
    """
    
    # Default JavaScript for basic API hooking
    DEFAULT_API_HOOK_SCRIPT = """
    'use strict';

    // Common WinAPI functions to monitor
    const hookTargets = [
        // File operations
        { module: 'kernel32.dll', function: 'CreateFileA' },
        { module: 'kernel32.dll', function: 'CreateFileW' },
        { module: 'kernel32.dll', function: 'WriteFile' },
        { module: 'kernel32.dll', function: 'ReadFile' },
        { module: 'kernel32.dll', function: 'DeleteFileA' },
        { module: 'kernel32.dll', function: 'DeleteFileW' },
        { module: 'kernel32.dll', function: 'CopyFileA' },
        { module: 'kernel32.dll', function: 'CopyFileW' },
        
        // Process operations
        { module: 'kernel32.dll', function: 'CreateProcessA' },
        { module: 'kernel32.dll', function: 'CreateProcessW' },
        { module: 'kernel32.dll', function: 'OpenProcess' },
        { module: 'kernel32.dll', function: 'TerminateProcess' },
        
        // Registry operations
        { module: 'advapi32.dll', function: 'RegOpenKeyExA' },
        { module: 'advapi32.dll', function: 'RegOpenKeyExW' },
        { module: 'advapi32.dll', function: 'RegCreateKeyExA' },
        { module: 'advapi32.dll', function: 'RegCreateKeyExW' },
        { module: 'advapi32.dll', function: 'RegSetValueExA' },
        { module: 'advapi32.dll', function: 'RegSetValueExW' },
        { module: 'advapi32.dll', function: 'RegDeleteValueA' },
        { module: 'advapi32.dll', function: 'RegDeleteValueW' },
        
        // Network operations
        { module: 'ws2_32.dll', function: 'socket' },
        { module: 'ws2_32.dll', function: 'connect' },
        { module: 'ws2_32.dll', function: 'send' },
        { module: 'ws2_32.dll', function: 'recv' },
        { module: 'wininet.dll', function: 'InternetOpenA' },
        { module: 'wininet.dll', function: 'InternetOpenW' },
        { module: 'wininet.dll', function: 'InternetConnectA' },
        { module: 'wininet.dll', function: 'InternetConnectW' },
        
        // Memory operations
        { module: 'kernel32.dll', function: 'VirtualAlloc' },
        { module: 'kernel32.dll', function: 'VirtualAllocEx' },
        { module: 'kernel32.dll', function: 'VirtualProtect' },
        { module: 'kernel32.dll', function: 'VirtualProtectEx' }
    ];

    // Log function
    function log(message) {
        send({
            type: 'log',
            message: message
        });
    }

    // Log API call details
    function logApiCall(apiName, args, retval, context) {
        send({
            type: 'api_call',
            api_name: apiName,
            args: args,
            retval: retval !== undefined ? retval.toString() : 'void',
            timestamp: new Date().toISOString(),
            context: context || {}
        });
    }

    // Helper functions to convert arguments to meaningful strings
    function stringFromPtr(ptr) {
        if (ptr.isNull())
            return 'NULL';
        try {
            return ptr.readUtf8String();
        } catch (e) {
            try {
                return ptr.readUtf16String();
            } catch (e2) {
                return `ptr(${ptr})`;
            }
        }
    }

    function formatCreateFileArgs(args) {
        return {
            lpFileName: stringFromPtr(args[0]),
            dwDesiredAccess: args[1].toUInt32(),
            dwShareMode: args[2].toUInt32(),
            lpSecurityAttributes: args[3],
            dwCreationDisposition: args[4].toUInt32(),
            dwFlagsAndAttributes: args[5].toUInt32(),
            hTemplateFile: args[6]
        };
    }

    function formatRegistryArgs(args) {
        return {
            hKey: args[0],
            lpSubKey: stringFromPtr(args[1]),
            ulOptions: args[2] ? args[2].toUInt32() : 0,
            samDesired: args[3] ? args[3].toUInt32() : 0
        };
    }

    function formatCreateProcessArgs(args) {
        return {
            lpApplicationName: stringFromPtr(args[0]),
            lpCommandLine: stringFromPtr(args[1]),
            lpProcessAttributes: args[2],
            lpThreadAttributes: args[3],
            bInheritHandles: args[4].toUInt32(),
            dwCreationFlags: args[5].toUInt32(),
            lpEnvironment: args[6],
            lpCurrentDirectory: stringFromPtr(args[7])
        };
    }

    // Install hooks when script is loaded
    log('Frida script loaded, installing hooks...');

    // Hook all specified API functions
    hookTargets.forEach(target => {
        try {
            const targetModule = Process.getModuleByName(target.module);
            const targetFunction = targetModule.getExportByName(target.function);
            
            log(`Hooking ${target.module}!${target.function}...`);
            
            Interceptor.attach(targetFunction, {
                onEnter: function(args) {
                    // Save context information for the onLeave callback
                    this.functionName = target.function;
                    this.moduleName = target.module;
                    
                    // Format arguments based on function type
                    let formattedArgs = {};
                    
                    if (target.function.startsWith('CreateFile')) {
                        formattedArgs = formatCreateFileArgs(args);
                    }
                    else if (target.function.includes('RegOpenKey') || 
                             target.function.includes('RegCreateKey')) {
                        formattedArgs = formatRegistryArgs(args);
                    }
                    else if (target.function.startsWith('CreateProcess')) {
                        formattedArgs = formatCreateProcessArgs(args);
                    }
                    else {
                        // Generic argument logging - just convert addresses to strings
                        for (let i = 0; i < 8; i++) {  // Log up to 8 arguments
                            try {
                                formattedArgs['arg' + i] = args[i] ? args[i].toString() : 'null';
                            } catch (e) {
                                break;  // Stop when we run out of arguments
                            }
                        }
                    }
                    
                    this.formattedArgs = formattedArgs;
                    
                    log(`Called ${target.module}!${target.function}`);
                },
                
                onLeave: function(retval) {
                    logApiCall(
                        `${this.moduleName}!${this.functionName}`, 
                        this.formattedArgs, 
                        retval,
                        {
                            threadId: this.threadId,
                            backtrace: Thread.backtrace(this.context).map(DebugSymbol.fromAddress)
                        }
                    );
                }
            });
        } catch (e) {
            log(`Error hooking ${target.module}!${target.function}: ${e.message}`);
        }
    });

    // Monitor DLL loads
    Process.enumerateModules({
        onMatch: function(module) {
            log(`Module loaded: ${module.name} (${module.base}, ${module.size} bytes)`);
        },
        onComplete: function() {}
    });
    
    log('All hooks installed. Monitoring API calls...');
    """
    
    def __init__(self, output_dir: str = "output", 
                logger: Optional[DLLAnalyzerLogger] = None):
        """
        Initialize the Frida monitor.
        
        Args:
            output_dir: Directory to save output files
            logger: Optional logger instance
        """
        self.logger = logger or DLLAnalyzerLogger("frida_monitor")
        self.output_dir = Path(output_dir)
        
        # Check for Frida installation
        self._check_frida_installation()
        
        # Create output directories
        self.ensure_directories()
        
        # Storage for captured API calls
        self.api_calls = []
        self.dll_loads = []
        self.processes = set()
    
    def _check_frida_installation(self) -> None:
        """
        Check if Frida is installed.
        
        Raises:
            MissingToolError: If Frida is not installed
        """
        try:
            import frida
            self.logger.info("Frida is installed")
            self.frida_available = True
        except ImportError:
            self.logger.error("Frida is not installed")
            self.frida_available = False
            # Don't raise here to allow graceful fallback
    
    def ensure_directories(self) -> None:
        """Ensure the output directories exist."""
        try:
            os.makedirs(self.output_dir, exist_ok=True)
            os.makedirs(self.output_dir / "frida", exist_ok=True)
        except Exception as e:
            self.logger.error(f"Failed to create directories: {str(e)}")
            raise
    
    def _create_script_file(self, script_content: str = None) -> str:
        """
        Create a temporary JavaScript file for Frida.
        
        Args:
            script_content: JavaScript code for Frida
            
        Returns:
            Path to the created script file
        """
        if script_content is None:
            script_content = self.DEFAULT_API_HOOK_SCRIPT
        
        # Create a script file in the output directory
        timestamp = time.strftime("%Y%m%d_%H%M%S")
        script_path = self.output_dir / "frida" / f"hook_script_{timestamp}.js"
        
        with open(script_path, "w") as f:
            f.write(script_content)
        
        self.logger.info(f"Created Frida script at: {script_path}")
        return str(script_path)
    
    def on_message(self, message: Dict[str, Any], data: Any) -> None:
        """
        Handle messages from Frida script.
        
        Args:
            message: Message from Frida
            data: Associated data
        """
        try:
            if message['type'] == 'send':
                payload = message['payload']
                
                # Handle different message types
                if payload['type'] == 'api_call':
                    self._handle_api_call(payload)
                elif payload['type'] == 'log':
                    self.logger.info(f"Frida: {payload['message']}")
                else:
                    self.logger.debug(f"Received message: {json.dumps(payload)}")
                    
            elif message['type'] == 'error':
                self.logger.error(f"Frida error: {message['description']}")
                
        except Exception as e:
            self.logger.error(f"Error processing Frida message: {str(e)}")
    
    def _handle_api_call(self, call_data: Dict[str, Any]) -> None:
        """
        Process an API call from Frida.
        
        Args:
            call_data: API call details
        """
        # Add timestamp if not present
        if 'timestamp' not in call_data:
            call_data['timestamp'] = time.strftime("%Y-%m-%dT%H:%M:%S.%fZ")
        
        # Extract module and function name
        api_name = call_data.get('api_name', '')
        if '!' in api_name:
            module, function = api_name.split('!')
            call_data['module'] = module
            call_data['function'] = function
        
        # Store the API call
        self.api_calls.append(call_data)
        
        # Extract additional information
        if function.lower() in ('loadlibrarya', 'loadlibraryw', 'loadlibraryexa', 'loadlibraryexw'):
            # Extract loaded DLL name
            dll_name = None
            if 'args' in call_data and isinstance(call_data['args'], dict):
                if 'lpLibFileName' in call_data['args']:
                    dll_name = call_data['args']['lpLibFileName']
                elif 'arg0' in call_data['args']:
                    dll_name = call_data['args']['arg0']
            
            if dll_name and dll_name != 'NULL':
                self.dll_loads.append({
                    'dll': dll_name,
                    'timestamp': call_data['timestamp']
                })
        
        elif function.lower() in ('createprocessa', 'createprocessw'):
            # Extract created process name
            if 'args' in call_data and isinstance(call_data['args'], dict):
                app_name = call_data['args'].get('lpApplicationName')
                cmd_line = call_data['args'].get('lpCommandLine')
                
                if app_name and app_name != 'NULL':
                    self.processes.add(app_name)
                elif cmd_line and cmd_line != 'NULL':
                    # Extract executable from command line
                    parts = cmd_line.split()
                    if parts:
                        self.processes.add(parts[0])
    
    def attach_to_process(self, process_id: int, script_content: str = None) -> Dict[str, Any]:
        """
        Attach to a running process and inject the Frida script.
        
        Args:
            process_id: ID of the process to attach to
            script_content: JavaScript code for Frida
            
        Returns:
            Dictionary with monitoring results
            
        Raises:
            FridaError: If attachment fails
        """
        if not self.frida_available:
            raise MissingToolError("Frida is not installed")
        
        try:
            import frida
            
            # Reset stored data
            self.api_calls = []
            self.dll_loads = []
            self.processes = set()
            
            # Create script file
            script_path = self._create_script_file(script_content)
            with open(script_path, 'r') as f:
                script_code = f.read()
            
            # Attach to the process
            self.logger.info(f"Attaching to process {process_id}")
            session = frida.attach(process_id)
            
            # Create script
            script = session.create_script(script_code)
            script.on('message', self.on_message)
            
            # Load the script
            self.logger.info("Loading Frida script")
            script.load()
            
            # Return the session and script for further use
            return {
                "session": session,
                "script": script,
                "script_path": script_path
            }
            
        except frida.ProcessNotFoundError:
            self.logger.error(f"Process {process_id} not found")
            raise FridaError(f"Process {process_id} not found")
        except frida.InvalidArgumentError as e:
            self.logger.error(f"Invalid argument: {str(e)}")
            raise FridaError(f"Invalid argument: {str(e)}")
        except Exception as e:
            self.logger.error(f"Frida error: {str(e)}")
            raise FridaError(f"Failed to attach to process: {str(e)}")
    
    def spawn_and_hook(self, command: str, script_content: str = None, 
                      timeout: int = 30) -> Dict[str, Any]:
        """
        Spawn a new process, inject Frida, and monitor API calls.
        
        Args:
            command: Command to execute
            script_content: JavaScript code for Frida
            timeout: Monitoring time in seconds
            
        Returns:
            Dictionary with monitoring results
            
        Raises:
            FridaError: If hooking fails
        """
        if not self.frida_available:
            raise MissingToolError("Frida is not installed")
        
        try:
            import frida
            
            # Reset stored data
            self.api_calls = []
            self.dll_loads = []
            self.processes = set()
            
            # Create script file
            script_path = self._create_script_file(script_content)
            with open(script_path, 'r') as f:
                script_code = f.read()
            
            # Prepare output file
            timestamp = time.strftime("%Y%m%d_%H%M%S")
            output_file = self.output_dir / "frida" / f"frida_output_{timestamp}.json"
            
            # Parse the command
            command_parts = command.split()
            program = command_parts[0]
            args = command_parts[1:] if len(command_parts) > 1 else []
            
            # Spawn the process
            self.logger.info(f"Spawning process: {command}")
            pid = frida.spawn([program] + args)
            
            # Attach to the process
            self.logger.info(f"Attaching to process {pid}")
            session = frida.attach(pid)
            
            # Create script
            script = session.create_script(script_code)
            script.on('message', self.on_message)
            
            # Load the script
            self.logger.info("Loading Frida script")
            script.load()
            
            # Start execution
            self.logger.info(f"Resuming process {pid}")
            frida.resume(pid)
            
            # Wait for specified duration
            self.logger.info(f"Monitoring for {timeout} seconds")
            time.sleep(timeout)
            
            # Detach and save results
            self.logger.info(f"Detaching from process {pid}")
            session.detach()
            
            # Save API calls to file
            self.save_results(output_file)
            
            return {
                "pid": pid,
                "api_calls": len(self.api_calls),
                "dll_loads": len(self.dll_loads),
                "output_file": str(output_file)
            }
            
        except frida.ProcessNotFoundError:
            self.logger.error(f"Process not found: {program}")
            raise FridaError(f"Process not found: {program}")
        except frida.InvalidArgumentError as e:
            self.logger.error(f"Invalid argument: {str(e)}")
            raise FridaError(f"Invalid argument: {str(e)}")
        except Exception as e:
            self.logger.error(f"Frida error: {str(e)}")
            raise FridaError(f"Failed to hook process: {str(e)}")
    
    def save_results(self, output_file: str) -> None:
        """
        Save monitoring results to a file.
        
        Args:
            output_file: Path to save the results
        """
        results = {
            "api_calls": self.api_calls,
            "dll_loads": self.dll_loads,
            "processes": list(self.processes),
            "timestamp": time.strftime("%Y-%m-%dT%H:%M:%S.%fZ")
        }
        
        try:
            with open(output_file, 'w') as f:
                json.dump(results, f, indent=2)
            
            self.logger.info(f"Saved monitoring results to {output_file}")
        except Exception as e:
            self.logger.error(f"Failed to save results: {str(e)}")
    
    def extract_ioc_from_calls(self) -> Dict[str, Any]:
        """
        Extract indicators of compromise from API calls.
        
        Returns:
            Dictionary with extracted IOCs
        """
        iocs = {
            "file_operations": [],
            "registry_operations": [],
            "process_operations": [],
            "network_operations": [],
            "memory_operations": [],
            "loaded_dlls": []
        }
        
        # Helper to extract file paths
        def extract_file_path(args):
            if isinstance(args, dict):
                if 'lpFileName' in args:
                    return args['lpFileName']
                elif 'arg0' in args and isinstance(args['arg0'], str) and ('\\' in args['arg0'] or '/' in args['arg0']):
                    return args['arg0']
            return None
        
        # Process each API call
        for call in self.api_calls:
            try:
                api_name = call.get('api_name', '')
                module = call.get('module', '')
                function = call.get('function', '')
                args = call.get('args', {})
                
                # File operations
                if function.startswith(('CreateFile', 'WriteFile', 'DeleteFile', 'CopyFile')):
                    file_path = extract_file_path(args)
                    if file_path and file_path != 'NULL':
                        iocs["file_operations"].append({
                            "operation": function,
                            "path": file_path
                        })
                
                # Registry operations
                elif module == 'advapi32.dll' and function.startswith(('Reg')):
                    key_path = None
                    if isinstance(args, dict) and 'lpSubKey' in args:
                        key_path = args['lpSubKey']
                    
                    if key_path and key_path != 'NULL':
                        iocs["registry_operations"].append({
                            "operation": function,
                            "key": key_path
                        })
                
                # Process operations
                elif function.startswith(('CreateProcess', 'OpenProcess')):
                    process_name = None
                    if isinstance(args, dict):
                        if 'lpApplicationName' in args and args['lpApplicationName'] != 'NULL':
                            process_name = args['lpApplicationName']
                        elif 'lpCommandLine' in args and args['lpCommandLine'] != 'NULL':
                            process_name = args['lpCommandLine']
                    
                    if process_name:
                        iocs["process_operations"].append({
                            "operation": function,
                            "process": process_name
                        })
                
                # Network operations
                elif module in ('ws2_32.dll', 'wininet.dll'):
                    iocs["network_operations"].append({
                        "operation": function,
                        "details": str(args)
                    })
                
                # Memory operations
                elif function.startswith(('VirtualAlloc', 'VirtualProtect')):
                    iocs["memory_operations"].append({
                        "operation": function,
                        "details": str(args)
                    })
            
            except Exception as e:
                self.logger.warning(f"Error extracting IOC: {str(e)}")
        
        # Add loaded DLLs
        for dll in self.dll_loads:
            iocs["loaded_dlls"].append(dll['dll'])
        
        return iocs
    
    def run_command_with_frida(self, command: str, script_content: str = None, 
                              timeout: int = 30) -> Dict[str, Any]:
        """
        Run a command with Frida monitoring.
        
        Args:
            command: Command to execute
            script_content: JavaScript code for Frida
            timeout: Monitoring time in seconds
            
        Returns:
            Dictionary with monitoring results
        """
        if not self.frida_available:
            self.logger.warning("Frida is not installed, running without monitoring")
            # Just execute the command normally
            try:
                process = subprocess.Popen(command.split(), stdout=subprocess.PIPE, stderr=subprocess.PIPE)
                stdout, stderr = process.communicate(timeout=timeout)
                return {
                    "command": command,
                    "return_code": process.returncode,
                    "stdout": stdout.decode('utf-8', errors='replace'),
                    "stderr": stderr.decode('utf-8', errors='replace'),
                    "monitoring": "none"
                }
            except Exception as e:
                self.logger.error(f"Error executing command: {str(e)}")
                return {
                    "command": command,
                    "error": str(e),
                    "monitoring": "none"
                }
        
        # Run with Frida monitoring
        try:
            results = self.spawn_and_hook(command, script_content, timeout)
            
            # Extract IOCs
            iocs = self.extract_ioc_from_calls()
            results["iocs"] = iocs
            
            return results
        except Exception as e:
            self.logger.error(f"Error running with Frida: {str(e)}")
            return {
                "command": command,
                "error": str(e),
                "monitoring": "failed"
            } 