"""
Process Monitor (Procmon) integration for the DLL Analyzer framework.
Provides functionality to capture and analyze process, file, registry and network activity.
"""

import os
import subprocess
import time
import xml.etree.ElementTree as ET
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Union, Any

from src.utils.exceptions import ProcmonError, MissingToolError
from src.utils.file_utils import find_tool, ensure_directory
from src.utils.logger import DLLAnalyzerLogger


class ProcmonMonitor:
    """
    Wrapper for Process Monitor (Procmon) to capture system activity during DLL execution.
    """
    
    DEFAULT_CONFIG_XML = """<?xml version="1.0" encoding="UTF-8"?>
<ProcessMonitorFilter>
    <FilterRules>
        <Rule>Operation,is,CreateFile,include</Rule>
        <Rule>Operation,is,WriteFile,include</Rule>
        <Rule>Operation,is,ReadFile,include</Rule>
        <Rule>Operation,is,RegCreateKey,include</Rule>
        <Rule>Operation,is,RegSetValue,include</Rule>
        <Rule>Operation,is,RegQueryValue,include</Rule>
        <Rule>Operation,is,Process Create,include</Rule>
        <Rule>Operation,is,Load Image,include</Rule>
        <Rule>Operation,is,TCP Connect,include</Rule>
        <Rule>Operation,is,UDP Send,include</Rule>
        <Rule>Operation,is,UDP Receive,include</Rule>
        <Rule>Process Name,is,rundll32.exe,include</Rule>
        <Rule>Process Name,is,python.exe,include</Rule>
        <Rule>Path,contains,.dll,include</Rule>
        <Rule>Path,contains,.exe,include</Rule>
        <Rule>Operation,is,Process Start,exclude</Rule>
        <Rule>Operation,is,Thread Create,exclude</Rule>
        <Rule>Operation,is,Thread Exit,exclude</Rule>
        <Rule>Operation,is,IRP_MJ_CLEANUP,exclude</Rule>
        <Rule>Operation,is,IRP_MJ_CLOSE,exclude</Rule>
        <Rule>Path,begins with,C:\\Windows\\Fonts,exclude</Rule>
        <Rule>Path,begins with,C:\\Windows\\System32\\config,exclude</Rule>
    </FilterRules>
</ProcessMonitorFilter>"""
    
    def __init__(self, 
                 output_dir: str = "output", 
                 logger: Optional[DLLAnalyzerLogger] = None,
                 process_name_filter: Optional[str] = None):
        """
        Initialize the Procmon monitor.
        
        Args:
            output_dir: Directory to save output files
            logger: Optional logger instance
            process_name_filter: Optional process name to filter on (e.g., 'rundll32.exe')
        """
        self.logger = logger or DLLAnalyzerLogger("procmon_monitor")
        self.output_dir = Path(output_dir)
        self.process_name_filter = process_name_filter
        
        # Find Procmon
        self.procmon_path = self._find_procmon()
        if not self.procmon_path:
            self.logger.error("Procmon not found")
        else:
            self.logger.info(f"Found Procmon at: {self.procmon_path}")
        
        # Create output directories
        self.ensure_directories()
        
        # Generate standard filter config
        self.filter_config_path = self.output_dir / "procmon_filter.pmc"
        self._generate_filter_config()
        
        # Track if monitoring is active
        self.is_monitoring = False
        self.current_session_file = None
    
    def ensure_directories(self) -> None:
        """Ensure the output directories exist."""
        try:
            ensure_directory(self.output_dir)
            ensure_directory(self.output_dir / "procmon")
        except Exception as e:
            self.logger.error(f"Failed to create directories: {str(e)}")
            raise
    
    def _find_procmon(self) -> Optional[str]:
        """
        Find the Procmon executable.
        
        Returns:
            Path to the Procmon executable if found, None otherwise
        """
        # First, check the specific tools directory in our project
        procmon_tools_dir = Path(__file__).resolve().parent.parent.parent / "tools" / "procmon"
        
        # Check for 64-bit versions first, then 32-bit
        for procmon_exe in ["Procmon64.exe", "Procmon.exe", "Procmon64a.exe"]:
            procmon_path = procmon_tools_dir / procmon_exe
            if procmon_path.exists():
                self.logger.info(f"Found Procmon at: {procmon_path}")
                return str(procmon_path)
        
        # If not found in tools directory, try using find_tool to locate it elsewhere
        try:
            # Try to find in common locations or PATH
            found_path = find_tool("Procmon.exe", ["Procmon64.exe", "Procmon64a.exe"])
            if found_path:
                return found_path
        except Exception as e:
            self.logger.warning(f"Error finding Procmon: {str(e)}")
        
        self.logger.error("Procmon not found. Please ensure it's installed in the tools/procmon directory.")
        return None
    
    def _generate_filter_config(self) -> None:
        """Generate a default filter configuration file for Procmon."""
        try:
            filter_xml = self.DEFAULT_CONFIG_XML
            
            # Add process name filter if specified
            if self.process_name_filter:
                # Parse the XML
                root = ET.fromstring(filter_xml)
                filter_rules = root.find("FilterRules")
                
                # Add a new rule for the process name
                rule_element = ET.SubElement(filter_rules, "Rule")
                rule_element.text = f"Process Name,is,{self.process_name_filter},include"
                
                # Convert back to string
                filter_xml = ET.tostring(root, encoding="utf-8").decode("utf-8")
            
            # Write the filter configuration file
            with open(self.filter_config_path, "w") as f:
                f.write(filter_xml)
                
            self.logger.info(f"Generated Procmon filter config at: {self.filter_config_path}")
        except Exception as e:
            self.logger.error(f"Failed to generate filter config: {str(e)}")
    
    def start_monitoring(self) -> bool:
        """
        Start Procmon monitoring.
        
        Returns:
            True if successful, False otherwise
        """
        if not self.procmon_path:
            self.logger.warning("Procmon path not set, skipping monitoring")
            return False
        
        if self.is_monitoring:
            self.logger.warning("Monitoring already active, stopping first")
            self.stop_monitoring()
        
        try:
            # Generate a unique output filename
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            output_file = self.output_dir / "procmon" / f"procmon_capture_{timestamp}.pml"
            self.current_session_file = output_file
            
            # Check if Procmon executable exists
            if not os.path.exists(self.procmon_path):
                self.logger.warning(f"Procmon executable not found at {self.procmon_path}, skipping monitoring")
                return False
            
            # Start Procmon with filters
            cmd = [
                self.procmon_path,
                "/AcceptEula",  # Auto-accept EULA
                "/Quiet",        # Quiet mode
                "/Minimized",    # Start minimized
                "/BackingFile", str(output_file),  # Output file
                "/LoadConfig", str(self.filter_config_path)  # Load filter config
            ]
            
            self.logger.info(f"Starting Procmon with command: {' '.join(cmd)}")
            
            try:
                subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
                # Give Procmon time to start
                time.sleep(3)
            except Exception as e:
                self.logger.error(f"Error launching Procmon: {e}")
                return False
            
            # We'll consider it successful even without verification since Procmon
            # can be difficult to detect in some environments
            self.is_monitoring = True
            self.logger.info(f"Procmon monitoring started, output file: {output_file}")
            return True
                
        except Exception as e:
            self.logger.error(f"Error starting Procmon: {str(e)}")
            return False
    
    def stop_monitoring(self) -> bool:
        """
        Stop Procmon monitoring.
        
        Returns:
            True if successful, False otherwise
        """
        if not self.is_monitoring:
            self.logger.warning("No active monitoring session to stop")
            return False
        
        try:
            # Terminate Procmon
            cmd = [self.procmon_path, "/Terminate"]
            self.logger.info(f"Stopping Procmon with command: {' '.join(cmd)}")
            subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            
            # Give Procmon time to save the file and exit
            time.sleep(3)
            
            self.is_monitoring = False
            self.logger.info("Procmon monitoring stopped")
            return True
            
        except Exception as e:
            self.logger.error(f"Error stopping Procmon: {str(e)}")
            return False
    
    def export_to_csv(self, pml_file: Optional[str] = None, 
                     csv_file: Optional[str] = None) -> Optional[str]:
        """
        Export Procmon log to CSV format.
        
        Args:
            pml_file: Path to PML file (defaults to current session file)
            csv_file: Path to output CSV file (generated if not provided)
            
        Returns:
            Path to CSV file if successful, None otherwise
        """
        if not self.procmon_path:
            self.logger.warning("Procmon not found, cannot export to CSV")
            return None
            
        if not pml_file and not self.current_session_file:
            self.logger.warning("No PML file specified and no current session file")
            return None
            
        try:
            # Use the provided PML file or the current session file
            pml_file = pml_file or str(self.current_session_file)
            
            # Generate output CSV filename if not provided
            if not csv_file:
                timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                csv_file = str(self.output_dir / "procmon" / f"procmon_export_{timestamp}.csv")
            
            self.logger.info(f"Exporting Procmon log to CSV: {csv_file}")
            
            # Check if Procmon executable exists
            if not os.path.exists(self.procmon_path):
                self.logger.warning(f"Procmon executable not found at {self.procmon_path}, skipping export")
                return None
                
            # Check if PML file exists
            if not os.path.exists(pml_file):
                self.logger.warning(f"PML file not found: {pml_file}")
                return None
            
            # Export to CSV
            try:
                cmd = [
                    self.procmon_path,
                    "/AcceptEula",
                    "/Quiet",
                    "/OpenLog", pml_file,
                    "/SaveAs", csv_file,
                    "/SaveApplyFilter"
                ]
                
                subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=30)
                
                # Check if CSV file was created
                if os.path.exists(csv_file):
                    self.logger.info(f"Procmon log exported to CSV: {csv_file}")
                    return csv_file
                else:
                    self.logger.warning(f"CSV file not created: {csv_file}")
                    return None
            except subprocess.TimeoutExpired:
                self.logger.warning("Procmon export timed out")
                return None
                
        except Exception as e:
            self.logger.error(f"Error exporting Procmon log to CSV: {str(e)}")
            return None
    
    def parse_csv_to_json(self, csv_file: str) -> List[Dict[str, Any]]:
        """
        Parse a Procmon CSV export to JSON format.
        
        Args:
            csv_file: Path to CSV file
            
        Returns:
            List of dictionaries containing event data
        """
        import csv
        
        self.logger.info(f"Parsing Procmon CSV file: {csv_file}")
        events = []
        
        try:
            with open(csv_file, 'r', encoding='utf-8', errors='replace') as f:
                reader = csv.DictReader(f)
                for row in reader:
                    events.append(dict(row))
            
            self.logger.info(f"Parsed {len(events)} events from CSV")
            return events
            
        except Exception as e:
            self.logger.error(f"Error parsing CSV: {str(e)}")
            return []
    
    def filter_events(self, events: List[Dict[str, Any]], 
                     filters: Dict[str, Union[str, List[str]]]) -> List[Dict[str, Any]]:
        """
        Filter events based on specified criteria.
        
        Args:
            events: List of event dictionaries
            filters: Dictionary of field/value filters
            
        Returns:
            Filtered list of events
        """
        self.logger.info(f"Filtering {len(events)} events")
        filtered_events = []
        
        for event in events:
            # Check if event matches all filters
            include = True
            
            for field, values in filters.items():
                if field not in event:
                    include = False
                    break
                    
                # Convert values to list if it's a single string
                if isinstance(values, str):
                    values = [values]
                
                # Check if event field matches any of the values
                field_value = event[field]
                if not any(value in field_value for value in values):
                    include = False
                    break
            
            if include:
                filtered_events.append(event)
        
        self.logger.info(f"Filtered to {len(filtered_events)} events")
        return filtered_events
    
    def extract_ioc_from_events(self, events: List[Dict[str, Any]]) -> Dict[str, Any]:
        """
        Extract indicators of compromise from Procmon events.
        
        Args:
            events: List of event dictionaries
            
        Returns:
            Dictionary of extracted IOCs
        """
        self.logger.info(f"Extracting IOCs from {len(events)} events")
        
        iocs = {
            "created_files": set(),
            "modified_files": set(),
            "registry_keys": set(),
            "registry_values": set(),
            "spawned_processes": set(),
            "loaded_dlls": set(),
            "network_connections": set()
        }
        
        for event in events:
            try:
                operation = event.get("Operation", "")
                path = event.get("Path", "")
                detail = event.get("Detail", "")
                result = event.get("Result", "")
                
                # Skip events with failure result
                if "SUCCESS" not in result.upper():
                    continue
                
                # File operations
                if operation == "CreateFile" and "CREATE" in detail:
                    iocs["created_files"].add(path)
                elif operation == "WriteFile":
                    iocs["modified_files"].add(path)
                
                # Registry operations
                elif operation == "RegCreateKey":
                    iocs["registry_keys"].add(path)
                elif operation == "RegSetValue":
                    iocs["registry_values"].add(f"{path}: {detail}")
                
                # Process operations
                elif operation == "Process Create":
                    iocs["spawned_processes"].add(detail)
                elif operation == "Load Image" and path.lower().endswith(".dll"):
                    iocs["loaded_dlls"].add(path)
                
                # Network operations
                elif operation in ["TCP Connect", "UDP Send"]:
                    iocs["network_connections"].add(f"{operation}: {path} - {detail}")
                    
            except Exception as e:
                self.logger.warning(f"Error processing event: {str(e)}")
        
        # Convert sets to sorted lists for JSON serialization
        return {k: sorted(list(v)) for k, v in iocs.items()}
    
    def monitor_dll_execution(self, timeout: int = 30) -> Dict[str, Any]:
        """
        Monitor system activity during DLL execution.
        
        Args:
            timeout: Monitoring duration in seconds
            
        Returns:
            Dictionary with monitoring results
            
        Raises:
            ProcmonError: If monitoring fails
        """
        if not self.procmon_path:
            raise MissingToolError("Procmon not found")
        
        try:
            # Start monitoring
            if not self.start_monitoring():
                raise ProcmonError("Failed to start Procmon monitoring")
            
            # Wait for specified duration
            self.logger.info(f"Monitoring for {timeout} seconds")
            time.sleep(timeout)
            
            # Stop monitoring
            if not self.stop_monitoring():
                raise ProcmonError("Failed to stop Procmon monitoring")
            
            # Export to CSV
            csv_file = self.export_to_csv()
            if not csv_file:
                raise ProcmonError("Failed to export Procmon log to CSV")
            
            # Parse events
            events = self.parse_csv_to_json(csv_file)
            if not events:
                raise ProcmonError("Failed to parse Procmon CSV data")
            
            # Extract IOCs
            iocs = self.extract_ioc_from_events(events)
            
            # Return results
            return {
                "monitoring_tool": "procmon",
                "event_count": len(events),
                "pml_file": str(self.current_session_file),
                "csv_file": csv_file,
                "iocs": iocs
            }
            
        except ProcmonError:
            raise
        except Exception as e:
            self.logger.error(f"Error during Procmon monitoring: {str(e)}")
            raise ProcmonError(f"Monitoring failed: {str(e)}")
    
    def execute_with_monitoring(self, command: List[str], 
                              timeout: int = 30) -> Dict[str, Any]:
        """
        Execute a command with Procmon monitoring.
        
        Args:
            command: Command to execute as a list of strings
            timeout: Monitoring timeout in seconds
            
        Returns:
            Dictionary with monitoring results
            
        Raises:
            ProcmonError: If monitoring or command execution fails
        """
        if not self.procmon_path:
            raise MissingToolError("Procmon not found")
        
        try:
            # Start monitoring
            if not self.start_monitoring():
                raise ProcmonError("Failed to start Procmon monitoring")
            
            # Execute the command
            self.logger.info(f"Executing command: {' '.join(command)}")
            start_time = time.time()
            
            process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            
            # Wait for command to complete or timeout
            stdout, stderr = b"", b""
            try:
                stdout, stderr = process.communicate(timeout=timeout)
            except subprocess.TimeoutExpired:
                self.logger.warning(f"Command timed out after {timeout} seconds")
                process.kill()
                stdout, stderr = process.communicate()
            
            end_time = time.time()
            duration = end_time - start_time
            
            # Stop monitoring
            time.sleep(1)  # Give a moment for any final events
            if not self.stop_monitoring():
                raise ProcmonError("Failed to stop Procmon monitoring")
            
            # Export to CSV
            csv_file = self.export_to_csv()
            if not csv_file:
                raise ProcmonError("Failed to export Procmon log to CSV")
            
            # Parse events
            events = self.parse_csv_to_json(csv_file)
            if not events:
                self.logger.warning("No Procmon events captured")
            
            # Extract IOCs
            iocs = self.extract_ioc_from_events(events)
            
            # Return results
            return {
                "monitoring_tool": "procmon",
                "command": " ".join(command),
                "return_code": process.returncode,
                "stdout": stdout.decode('utf-8', errors='replace'),
                "stderr": stderr.decode('utf-8', errors='replace'),
                "duration": duration,
                "event_count": len(events),
                "pml_file": str(self.current_session_file),
                "csv_file": csv_file,
                "iocs": iocs
            }
            
        except ProcmonError:
            raise
        except Exception as e:
            self.logger.error(f"Error during monitored execution: {str(e)}")
            # Try to stop monitoring if it was started
            if self.is_monitoring:
                self.stop_monitoring()
            raise ProcmonError(f"Monitored execution failed: {str(e)}") 