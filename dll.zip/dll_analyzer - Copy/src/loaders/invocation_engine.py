"""
Invocation Engine for the DLL Analyzer framework.
Provides functionality for invoking DLL exports, DllMain, and TLS callbacks.
"""

import ctypes
import os
import random
import subprocess
import sys
import time
import tempfile
from ctypes import WinError, wintypes
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple, Union, Callable

from src.utils.exceptions import (
    ExportNotFoundError,
    LoadLibraryError,
    FunctionCallError,
    InvocationError
)
from src.utils.logger import DLLAnalyzerLogger, log_api_call


# Windows constants required for DLL loading
LOAD_LIBRARY_AS_DATAFILE = 0x00000002
LOAD_WITH_ALTERED_SEARCH_PATH = 0x00000008
DONT_RESOLVE_DLL_REFERENCES = 0x00000001
LOAD_IGNORE_CODE_AUTHZ_LEVEL = 0x00000010
LOAD_LIBRARY_AS_IMAGE_RESOURCE = 0x00000020

# DLL Entry reasons
DLL_PROCESS_ATTACH = 1
DLL_THREAD_ATTACH = 2
DLL_THREAD_DETACH = 3
DLL_PROCESS_DETACH = 0

# Common function prototypes
CDLL_FUNC_TYPE = ctypes.CFUNCTYPE(ctypes.c_int)
DLLMAIN_FUNC_TYPE = ctypes.WINFUNCTYPE(
    ctypes.c_int,  # Return type: BOOL (as int)
    ctypes.c_void_p,  # hinstDLL: HINSTANCE
    ctypes.c_uint,  # fdwReason: DWORD
    ctypes.c_void_p  # lpvReserved: LPVOID
)


class InvocationEngine:
    """
    Engine for invoking DLL exports and entry points.
    """
    
    def __init__(self, logger: Optional[DLLAnalyzerLogger] = None):
        """
        Initialize the invocation engine.
        
        Args:
            logger: Optional logger instance
        """
        self.logger = logger or DLLAnalyzerLogger("invocation_engine")
        self.loaded_dlls = {}
        self.exported_functions = {}
    
    def list_exports(self, dll_path: str) -> List[Dict[str, Any]]:
        """
        List exported functions from a DLL.
        
        Args:
            dll_path: Path to the DLL file
            
        Returns:
            List of dictionaries containing export information
        """
        self.logger.info(f"Listing exports for {dll_path}")
        
        try:
            # Try using PE parser directly
            import pefile
            pe = pefile.PE(dll_path, fast_load=True)
            exports = []
            
            if hasattr(pe, 'DIRECTORY_ENTRY_EXPORT'):
                for exp in pe.DIRECTORY_ENTRY_EXPORT.symbols:
                    if exp.name:
                        exports.append({
                            "name": exp.name.decode('utf-8', errors='ignore'),
                            "address": hex(pe.OPTIONAL_HEADER.ImageBase + exp.address),
                            "ordinal": exp.ordinal
                        })
            
            self.logger.info(f"Found {len(exports)} exports")
            return exports
            
        except Exception as e:
            # Fall back to dumpbin
            self.logger.warning(f"Failed to parse exports with pefile: {str(e)}")
            return self._list_exports_dumpbin(dll_path)
    
    def _list_exports_dumpbin(self, dll_path: str) -> List[Dict[str, Any]]:
        """
        List exports using the dumpbin tool.
        
        Args:
            dll_path: Path to the DLL file
            
        Returns:
            List of dictionaries containing export information
        """
        try:
            # Check if dumpbin is available
            dumpbin_path = self._find_dumpbin()
            if not dumpbin_path:
                self.logger.warning("Dumpbin.exe not found, cannot list exports")
                return []
            
            # Run dumpbin /EXPORTS on the DLL
            cmd = [dumpbin_path, '/EXPORTS', dll_path]
            result = subprocess.run(cmd, capture_output=True, text=True)
            
            if result.returncode != 0:
                self.logger.warning(f"Dumpbin failed: {result.stderr}")
                return []
            
            # Parse the output
            output = result.stdout
            exports = []
            in_export_section = False
            
            for line in output.splitlines():
                line = line.strip()
                
                # Skip until we find the exports section
                if "ordinal hint RVA      name" in line:
                    in_export_section = True
                    continue
                
                if in_export_section:
                    # Sometimes there's a line of dashes after the header
                    if line.startswith("----"):
                        continue
                        
                    # Empty line might indicate end of exports section
                    if not line:
                        continue
                    
                    # Parse the export line
                    parts = line.split()
                    if len(parts) >= 4:
                        try:
                            ordinal = int(parts[0])
                            name = parts[3]
                            exports.append({
                                "name": name,
                                "ordinal": ordinal,
                                "address": "0x" + parts[2]  # RVA
                            })
                        except (ValueError, IndexError):
                            continue
            
            self.logger.info(f"Found {len(exports)} exports using dumpbin")
            return exports
            
        except Exception as e:
            self.logger.error(f"Failed to list exports with dumpbin: {str(e)}")
            return []
    
    def _find_dumpbin(self) -> Optional[str]:
        """
        Find the dumpbin.exe tool in common Visual Studio paths.
        
        Returns:
            Path to dumpbin.exe if found, None otherwise
        """
        # Check if dumpbin is in PATH
        if os.system("where dumpbin.exe >nul 2>&1") == 0:
            return "dumpbin.exe"
        
        # Common Visual Studio paths
        vs_paths = [
            os.path.expandvars("%ProgramFiles(x86)%\\Microsoft Visual Studio"),
            os.path.expandvars("%ProgramFiles%\\Microsoft Visual Studio")
        ]
        
        for base_path in vs_paths:
            if not os.path.exists(base_path):
                continue
                
            # Search for dumpbin.exe in Visual Studio directories
            for root, dirs, files in os.walk(base_path):
                if "dumpbin.exe" in files:
                    return os.path.join(root, "dumpbin.exe")
        
        return None
    
    def load_dll(self, dll_path: str, flags: int = 0) -> int:
        """
        Load a DLL into memory.
        
        Args:
            dll_path: Path to the DLL file
            flags: LoadLibrary flags
            
        Returns:
            Handle to the loaded DLL
            
        Raises:
            LoadLibraryError: If loading the DLL fails
        """
        self.logger.info(f"Loading DLL: {dll_path}")
        
        # Check if already loaded
        if dll_path in self.loaded_dlls:
            self.logger.info(f"DLL already loaded: {dll_path}")
            return self.loaded_dlls[dll_path]
        
        try:
            # Resolve the full path
            full_path = os.path.abspath(dll_path)
            
            # Load the DLL
            kernel32 = ctypes.WinDLL('kernel32', use_last_error=True)
            handle = kernel32.LoadLibraryExW(
                full_path, 
                None, 
                flags
            )
            
            if handle == 0:
                error_code = ctypes.get_last_error()
                raise LoadLibraryError(
                    f"Failed to load DLL: {dll_path}", 
                    {"error_code": error_code, "error_message": str(WinError(error_code))}
                )
                
            self.loaded_dlls[dll_path] = handle
            self.logger.info(f"Successfully loaded DLL: {dll_path}, handle: {handle}")
            
            # Cache exported functions
            self._cache_exports(dll_path, handle)
            
            return handle
            
        except LoadLibraryError:
            # Re-raise LoadLibraryError exceptions
            raise
        except Exception as e:
            raise LoadLibraryError(f"Error loading DLL: {str(e)}", {"error": str(e)})
    
    def _cache_exports(self, dll_path: str, handle: int) -> None:
        """
        Cache the exported functions from a loaded DLL.
        
        Args:
            dll_path: Path to the DLL file
            handle: Handle to the loaded DLL
        """
        try:
            exports = self.list_exports(dll_path)
            self.exported_functions[dll_path] = {}
            
            for export in exports:
                name = export.get("name")
                if name:
                    self.exported_functions[dll_path][name] = export
            
            self.logger.debug(f"Cached {len(exports)} exports for {dll_path}")
        except Exception as e:
            self.logger.warning(f"Failed to cache exports: {str(e)}")
    
    def free_dll(self, dll_path: str) -> bool:
        """
        Free a loaded DLL.
        
        Args:
            dll_path: Path to the DLL file
            
        Returns:
            True if successful, False otherwise
        """
        if dll_path not in self.loaded_dlls:
            self.logger.warning(f"DLL not loaded: {dll_path}")
            return False
        
        handle = self.loaded_dlls[dll_path]
        
        try:
            kernel32 = ctypes.WinDLL('kernel32', use_last_error=True)
            result = kernel32.FreeLibrary(handle)
            
            if result == 0:
                error_code = ctypes.get_last_error()
                self.logger.error(
                    f"Failed to free DLL: {dll_path}",
                    {"error_code": error_code, "error_message": str(WinError(error_code))}
                )
                return False
                
            # Remove from cache
            del self.loaded_dlls[dll_path]
            if dll_path in self.exported_functions:
                del self.exported_functions[dll_path]
                
            self.logger.info(f"Successfully freed DLL: {dll_path}")
            return True
            
        except Exception as e:
            self.logger.error(f"Error freeing DLL: {str(e)}")
            return False
    
    def get_proc_address(self, dll_path: str, function_name: str) -> int:
        """
        Get the address of a function in a loaded DLL.
        
        Args:
            dll_path: Path to the DLL file
            function_name: Name of the function
            
        Returns:
            Address of the function
            
        Raises:
            ExportNotFoundError: If the function is not found
            LoadLibraryError: If the DLL is not loaded
        """
        # Ensure DLL is loaded
        if dll_path not in self.loaded_dlls:
            handle = self.load_dll(dll_path)
        else:
            handle = self.loaded_dlls[dll_path]
        
        try:
            kernel32 = ctypes.WinDLL('kernel32', use_last_error=True)
            address = kernel32.GetProcAddress(handle, function_name.encode('ascii'))
            
            if address == 0:
                error_code = ctypes.get_last_error()
                raise ExportNotFoundError(
                    f"Function not found: {function_name}", 
                    {"error_code": error_code, "error_message": str(WinError(error_code))}
                )
                
            self.logger.info(f"Found function {function_name} at address {hex(address)}")
            return address
            
        except ExportNotFoundError:
            raise
        except Exception as e:
            raise ExportNotFoundError(f"Error getting function address: {str(e)}", {"error": str(e)})
    
    def get_function_pointer(self, dll_path: str, function_name: str, argtypes=None, restype=None):
        """
        Get a function pointer from a DLL.
        
        Args:
            dll_path: Path to the DLL file
            function_name: Name of the function to get
            argtypes: List of argument types
            restype: Return type
            
        Returns:
            Function pointer
            
        Raises:
            ExportNotFoundError: If the function is not found
        """
        self.logger.info(f"Getting function pointer for {function_name} in {dll_path}")
        
        try:
            # Load the DLL with ctypes
            dll = ctypes.CDLL(dll_path)
            
            # Get the function
            func = getattr(dll, function_name)
            
            # Set argument and return types if provided
            if argtypes is not None:
                func.argtypes = argtypes
            if restype is not None:
                func.restype = restype
                
            return func
            
        except AttributeError:
            raise ExportNotFoundError(f"Function not found: {function_name}")
        except Exception as e:
            raise ExportNotFoundError(f"Error getting function pointer: {str(e)}", {"error": str(e)})
    
    def invoke_function_ctypes(
        self, 
        dll_path: str, 
        function_name: str, 
        argtypes: Optional[List[Any]] = None, 
        args: Optional[List[Any]] = None,
        restype: Any = ctypes.c_int,
        timeout: Optional[int] = None
    ) -> Any:
        """
        Invoke a function in a DLL using ctypes.
        
        Args:
            dll_path: Path to the DLL file
            function_name: Name of the function to invoke
            argtypes: List of argument types
            args: List of arguments to pass
            restype: Return type
            timeout: Optional timeout in seconds
            
        Returns:
            Function result
            
        Raises:
            FunctionCallError: If calling the function fails
        """
        self.logger.info(f"Invoking function: {function_name} in {dll_path}")
        
        # Default argument values
        if argtypes is None:
            argtypes = []
        if args is None:
            args = []
        
        try:
            # Ensure DLL is loaded
            if dll_path not in self.loaded_dlls:
                self.load_dll(dll_path)
            
            # Create a CDLL instance
            dll = ctypes.CDLL(dll_path)
            
            # Get the function
            func = getattr(dll, function_name)
            
            # Set argument and return types
            func.argtypes = argtypes
            func.restype = restype
            
            # Log the call with argument types
            self.logger.info(
                f"Calling {function_name} with {len(args)} arguments",
                {
                    "argtypes": [str(t) for t in argtypes],
                    "args": [str(a) for a in args]
                }
            )
            
            # Invoke the function with timeout if specified
            start_time = time.time()
            
            if timeout:
                import threading
                
                # Create a thread to run the function
                result_container = []
                exception_container = []
                
                def call_function():
                    try:
                        result_container.append(func(*args))
                    except Exception as e:
                        exception_container.append(e)
                
                thread = threading.Thread(target=call_function)
                thread.daemon = True
                thread.start()
                thread.join(timeout)
                
                if thread.is_alive():
                    # Timeout occurred
                    raise TimeoutError(f"Function call timed out after {timeout} seconds")
                
                if exception_container:
                    # Re-raise any exception that occurred in the thread
                    raise exception_container[0]
                
                result = result_container[0]
            else:
                # No timeout, call directly
                result = func(*args)
                
            duration = (time.time() - start_time) * 1000  # ms
            
            # Log the result            
            self.logger.info(
                f"Function {function_name} returned: {result}",
                {"duration_ms": duration, "return_type": str(restype)}
            )
            
            return result
            
        except TimeoutError:
            self.logger.error(f"Function call timed out after {timeout} seconds")
            raise FunctionCallError(f"Timeout after {timeout} seconds")
        except AttributeError:
            raise FunctionCallError(f"Function not found: {function_name}")
        except Exception as e:
            raise FunctionCallError(f"Error calling function: {str(e)}", {"error": str(e)})
    
    def invoke_function_rundll32(self, dll_path: str, function_name: str, args: Optional[str] = None) -> str:
        """
        Invoke a function in a DLL using rundll32.
        
        Args:
            dll_path: Path to the DLL file
            function_name: Name of the function to invoke
            args: Arguments to pass to the function
            
        Returns:
            Command output
            
        Raises:
            FunctionCallError: If calling the function fails
        """
        self.logger.info(f"Invoking function via rundll32: {function_name} in {dll_path}")
        
        try:
            # Build the rundll32 command
            dll_path = os.path.abspath(dll_path)
            cmd = ["rundll32.exe", dll_path, function_name]
            
            if args:
                cmd.append(args)
                
            self.logger.info(f"Running command: {' '.join(cmd)}")
            
            # Execute the command
            start_time = time.time()
            result = subprocess.run(cmd, capture_output=True, text=True)
            duration = (time.time() - start_time) * 1000  # ms
            
            # Log the result
            self.logger.info(
                f"rundll32 returned with code: {result.returncode}",
                {
                    "duration_ms": duration,
                    "stdout_size": len(result.stdout),
                    "stderr_size": len(result.stderr),
                }
            )
            
            if result.returncode != 0:
                self.logger.warning(
                    f"rundll32 returned non-zero code: {result.returncode}",
                    {"stderr": result.stderr}
                )
            
            # Return combined output
            return f"STDOUT: {result.stdout}\nSTDERR: {result.stderr}"
            
        except Exception as e:
            raise FunctionCallError(f"Error invoking function with rundll32: {str(e)}", {"error": str(e)})
    
    def invoke_dllmain(self, dll_path: str, reason: int = DLL_PROCESS_ATTACH) -> int:
        """
        Manually invoke DllMain in a DLL.
        
        Args:
            dll_path: Path to the DLL file
            reason: DllMain reason code
            
        Returns:
            DllMain return value
            
        Raises:
            FunctionCallError: If calling DllMain fails
        """
        self.logger.info(f"Manually invoking DllMain in {dll_path} with reason {reason}")
        
        try:
            # Load the DLL with DONT_RESOLVE_DLL_REFERENCES to prevent automatic DllMain call
            handle = self.load_dll(dll_path, DONT_RESOLVE_DLL_REFERENCES)
            
            # Get the entry point
            kernel32 = ctypes.WinDLL('kernel32', use_last_error=True)
            entry_point_rva = self._get_entry_point_rva(dll_path)
            
            if entry_point_rva == 0:
                raise FunctionCallError("Entry point not found")
            
            # Calculate the absolute address
            entry_point = handle + entry_point_rva
            
            # Create function prototype
            dllmain = DLLMAIN_FUNC_TYPE(entry_point)
            
            # Call DllMain
            start_time = time.time()
            result = dllmain(handle, reason, None)
            duration = (time.time() - start_time) * 1000  # ms
            
            self.logger.info(
                f"DllMain returned: {result}",
                {"duration_ms": duration, "reason": reason}
            )
            
            return result
            
        except Exception as e:
            raise FunctionCallError(f"Error calling DllMain: {str(e)}", {"error": str(e)})
    
    def _get_entry_point_rva(self, dll_path: str) -> int:
        """
        Get the relative virtual address of a DLL's entry point.
        
        Args:
            dll_path: Path to the DLL file
            
        Returns:
            Entry point RVA
        """
        try:
            import pefile
            pe = pefile.PE(dll_path, fast_load=True)
            return pe.OPTIONAL_HEADER.AddressOfEntryPoint
        except Exception as e:
            self.logger.warning(f"Failed to get entry point: {str(e)}")
            return 0
    
    def invoke_tls_callbacks(self, dll_path: str, reason: int = DLL_PROCESS_ATTACH) -> List[int]:
        """
        Invoke TLS callbacks in a DLL.
        
        Args:
            dll_path: Path to the DLL file
            reason: TLS callback reason code
            
        Returns:
            List of TLS callback return values
            
        Raises:
            FunctionCallError: If calling TLS callbacks fails
        """
        self.logger.info(f"Invoking TLS callbacks in {dll_path} with reason {reason}")
        
        try:
            # Get TLS callbacks
            import pefile
            pe = pefile.PE(dll_path, fast_load=True)
            
            # Check if TLS directory exists
            if not hasattr(pe, 'DIRECTORY_ENTRY_TLS'):
                self.logger.info(f"No TLS directory found in {dll_path}")
                return []
            
            # Check if AddressOfCallBacks is present
            if not hasattr(pe.DIRECTORY_ENTRY_TLS.struct, 'AddressOfCallBacks'):
                self.logger.info(f"No TLS callbacks found in {dll_path}")
                return []
            
            # Get the callbacks array address
            callbacks_va = pe.DIRECTORY_ENTRY_TLS.struct.AddressOfCallBacks
            
            if callbacks_va == 0:
                self.logger.info(f"No TLS callbacks found in {dll_path}")
                return []
            
            # Load the DLL
            handle = self.load_dll(dll_path, DONT_RESOLVE_DLL_REFERENCES)
            
            # Calculate the RVA of the callbacks array
            image_base = pe.OPTIONAL_HEADER.ImageBase
            callbacks_rva = callbacks_va - image_base
            
            # Get the section containing the callbacks
            section = None
            for s in pe.sections:
                if s.contains_rva(callbacks_rva):
                    section = s
                    break
                    
            if not section:
                raise FunctionCallError("Could not find section containing TLS callbacks")
            
            # Calculate the file offset
            callbacks_offset = (callbacks_rva - section.VirtualAddress) + section.PointerToRawData
            
            # Read the array of callback addresses
            pointer_size = 8 if pe.FILE_HEADER.Machine == pefile.MACHINE_TYPE['IMAGE_FILE_MACHINE_AMD64'] else 4
            callback_offset = callbacks_offset
            callbacks = []
            
            while True:
                pe.seek(callback_offset)
                callback_rva_bytes = pe.read(pointer_size)
                
                # Convert bytes to integer
                if pointer_size == 8:
                    callback_va = int.from_bytes(callback_rva_bytes, byteorder='little')
                else:
                    callback_va = int.from_bytes(callback_rva_bytes, byteorder='little')
                
                # End of array is marked by a null pointer
                if callback_va == 0:
                    break
                    
                callbacks.append(callback_va)
                callback_offset += pointer_size
            
            # Invoke each callback
            results = []
            
            for i, callback_va in enumerate(callbacks):
                # Calculate the RVA
                callback_rva = callback_va - image_base
                
                # Calculate the offset in the loaded DLL
                callback_addr = handle + callback_rva
                
                # Create function prototype
                tls_callback = ctypes.WINFUNCTYPE(
                    None,  # Return type: void
                    ctypes.c_void_p,  # hModule: HINSTANCE
                    ctypes.c_uint,  # fdwReason: DWORD
                    ctypes.c_void_p  # lpvReserved: LPVOID
                )(callback_addr)
                
                # Call the callback
                self.logger.info(f"Invoking TLS callback {i} at {hex(callback_va)}")
                
                try:
                    start_time = time.time()
                    tls_callback(handle, reason, None)
                    duration = (time.time() - start_time) * 1000  # ms
                    
                    self.logger.info(
                        f"TLS callback {i} completed",
                        {"duration_ms": duration}
                    )
                    
                    results.append(1)  # Success
                except Exception as e:
                    self.logger.error(f"Error in TLS callback {i}: {str(e)}")
                    results.append(0)  # Failure
            
            return results
            
        except Exception as e:
            raise FunctionCallError(f"Error invoking TLS callbacks: {str(e)}", {"error": str(e)})
    
    def fuzz_function(self, dll_path: str, function_name: str, num_runs: int = 5) -> Dict[str, Any]:
        """
        Fuzz a function with various inputs.
        
        Args:
            dll_path: Path to the DLL file
            function_name: Name of the function to fuzz
            num_runs: Number of fuzzing runs to perform
            
        Returns:
            Dictionary with fuzzing results
        """
        self.logger.info(f"Fuzzing function {function_name} in {dll_path} with {num_runs} runs")
        
        results = {
            "function": function_name,
            "dll_path": dll_path,
            "runs": []
        }
        
        # Common argument types for fuzzing
        arg_types = [
            ([], []),  # No args
            ([ctypes.c_int], [0]),
            ([ctypes.c_int], [1]),
            ([ctypes.c_int], [-1]),
            ([ctypes.c_int], [0x7FFFFFFF]),  # MAX_INT
            ([ctypes.c_int], [0xFFFFFFFF]),  # -1 as unsigned
            ([ctypes.c_char_p], [None]),  # NULL
            ([ctypes.c_char_p], [b""]),  # Empty string
            ([ctypes.c_char_p], [b"test"]),  # Simple string
            ([ctypes.c_char_p], [b"A" * 1000]),  # Long string
            ([ctypes.c_void_p], [None]),  # NULL pointer
            ([ctypes.c_int, ctypes.c_int], [0, 0]),  # Two integers
            ([ctypes.c_int, ctypes.c_char_p], [0, None]),  # Integer and NULL
            ([ctypes.c_int, ctypes.c_char_p], [1, b"test"]),  # Integer and string
        ]
        
        for i in range(min(num_runs, len(arg_types))):
            argtypes, args = arg_types[i]
            
            try:
                self.logger.info(
                    f"Fuzzing run {i+1}/{num_runs} for {function_name}",
                    {"argtypes": [str(t) for t in argtypes], "args": [str(a) for a in args]}
                )
                
                # Try with different return types
                for restype in [ctypes.c_int, ctypes.c_void_p, ctypes.c_char_p]:
                    try:
                        start_time = time.time()
                        result = self.invoke_function_ctypes(
                            dll_path, function_name, argtypes, args, restype
                        )
                        duration = (time.time() - start_time) * 1000  # ms
                        
                        run_result = {
                            "args": [str(a) for a in args],
                            "argtypes": [str(t) for t in argtypes],
                            "restype": str(restype),
                            "result": str(result),
                            "duration_ms": duration,
                            "status": "success"
                        }
                        
                        results["runs"].append(run_result)
                        break  # Found a working return type
                        
                    except Exception as e:
                        if isinstance(e, FunctionCallError):
                            # If it's a function call error, move to the next argument set
                            pass
                        # Continue with the next return type
                
            except Exception as e:
                run_result = {
                    "args": [str(a) for a in args],
                    "argtypes": [str(t) for t in argtypes],
                    "error": str(e),
                    "status": "failure"
                }
                results["runs"].append(run_result)
        
        self.logger.info(f"Completed fuzzing {function_name} with {len(results['runs'])} results")
        return results
    
    def generate_c_loader(self, dll_path: str, function_name: str) -> Tuple[str, str]:
        """
        Generate a C program to load and call a DLL function.
        
        Args:
            dll_path: Path to the DLL file
            function_name: Name of the function to call
            
        Returns:
            Tuple of (source_code, exe_path)
        """
        self.logger.info(f"Generating C loader for {function_name} in {dll_path}")
        
        # Generate a unique output filename
        timestamp = int(time.time())
        random_id = random.randint(1000, 9999)
        output_dir = Path("output") / "loaders"
        output_dir.mkdir(parents=True, exist_ok=True)
        
        base_name = f"dll_loader_{timestamp}_{random_id}"
        source_path = output_dir / f"{base_name}.c"
        exe_path = output_dir / f"{base_name}.exe"
        
        # Generate the C source code
        source_code = f"""
#include <windows.h>
#include <stdio.h>

typedef int (*FunctionType)(void);

int main(int argc, char** argv) {{
    HMODULE hModule;
    FunctionType function;
    int result;
    
    // Load the DLL
    printf("Loading DLL: {dll_path}\\n");
    hModule = LoadLibraryA("{dll_path.replace('\\', '\\\\')}");
    if (!hModule) {{
        printf("Failed to load DLL. Error: %lu\\n", GetLastError());
        return 1;
    }}
    
    // Get function address
    printf("Getting function address: {function_name}\\n");
    function = (FunctionType)GetProcAddress(hModule, "{function_name}");
    if (!function) {{
        printf("Failed to get function address. Error: %lu\\n", GetLastError());
        FreeLibrary(hModule);
        return 1;
    }}
    
    // Call the function
    printf("Calling function: {function_name}\\n");
    __try {{
        result = function();
        printf("Function returned: %d (0x%08X)\\n", result, result);
    }}
    __except(EXCEPTION_EXECUTE_HANDLER) {{
        printf("Exception occurred during function execution: 0x%08X\\n", GetExceptionCode());
    }}
    
    // Cleanup
    FreeLibrary(hModule);
    printf("Done.\\n");
    
    return 0;
}}
"""
        
        # Write the source code to file
        with open(source_path, "w") as f:
            f.write(source_code)
        
        self.logger.info(f"Generated C source at {source_path}")
        
        return str(source_path), str(exe_path)
    
    def compile_c_loader(self, source_path: str, exe_path: str) -> bool:
        """
        Compile a C loader program.
        
        Args:
            source_path: Path to the C source file
            exe_path: Path to output the compiled executable
            
        Returns:
            True if compilation was successful, False otherwise
        """
        self.logger.info(f"Compiling C loader from {source_path} to {exe_path}")
        
        try:
            # Look for the Visual C++ compiler (cl.exe)
            cl_path = self._find_cl_exe()
            if not cl_path:
                self.logger.warning("cl.exe not found, cannot compile C loader")
                return False
            
            # Compile the program
            cmd = [
                cl_path,
                "/nologo",
                "/EHsc",
                "/Ox",  # Optimize for speed
                "/W3",  # Warning level
                f"/Fe{exe_path}",  # Output file
                source_path
            ]
            
            self.logger.debug(f"Compilation command: {' '.join(cmd)}")
            
            result = subprocess.run(cmd, capture_output=True, text=True)
            
            if result.returncode != 0:
                self.logger.error(f"Compilation failed: {result.stderr}")
                return False
            
            self.logger.info(f"Successfully compiled to {exe_path}")
            return True
            
        except Exception as e:
            self.logger.error(f"Error during compilation: {str(e)}")
            return False
    
    def _find_cl_exe(self) -> Optional[str]:
        """
        Find the cl.exe compiler in common Visual Studio paths.
        
        Returns:
            Path to cl.exe if found, None otherwise
        """
        # Check if cl.exe is in PATH
        if os.system("where cl.exe >nul 2>&1") == 0:
            return "cl.exe"
        
        # Common Visual Studio paths
        vs_paths = [
            os.path.expandvars("%ProgramFiles(x86)%\\Microsoft Visual Studio"),
            os.path.expandvars("%ProgramFiles%\\Microsoft Visual Studio")
        ]
        
        for base_path in vs_paths:
            if not os.path.exists(base_path):
                continue
                
            # Search for cl.exe in Visual Studio directories
            for root, dirs, files in os.walk(base_path):
                if "cl.exe" in files:
                    return os.path.join(root, "cl.exe")
        
        return None
    
    def run_c_loader(self, exe_path: str) -> str:
        """
        Run a compiled C loader program.
        
        Args:
            exe_path: Path to the compiled executable
            
        Returns:
            Program output
        """
        self.logger.info(f"Running C loader: {exe_path}")
        
        try:
            # Execute the program
            start_time = time.time()
            result = subprocess.run([exe_path], capture_output=True, text=True)
            duration = (time.time() - start_time) * 1000  # ms
            
            # Log the result
            self.logger.info(
                f"C loader returned with code: {result.returncode}",
                {
                    "duration_ms": duration,
                    "stdout_size": len(result.stdout),
                    "stderr_size": len(result.stderr),
                }
            )
            
            # Return combined output
            return f"STDOUT: {result.stdout}\nSTDERR: {result.stderr}"
            
        except Exception as e:
            self.logger.error(f"Error running C loader: {str(e)}")
            return f"ERROR: {str(e)}"
    
    def create_and_run_c_loader(self, dll_path: str, function_name: str) -> str:
        """
        Create, compile, and run a C loader program for a DLL function.
        
        Args:
            dll_path: Path to the DLL file
            function_name: Name of the function to call
            
        Returns:
            Program output
        """
        try:
            # Generate C source
            source_path, exe_path = self.generate_c_loader(dll_path, function_name)
            
            # Compile
            if not self.compile_c_loader(source_path, exe_path):
                return f"Failed to compile C loader for {function_name}"
            
            # Run
            return self.run_c_loader(exe_path)
            
        except Exception as e:
            self.logger.error(f"Error in create_and_run_c_loader: {str(e)}")
            return f"ERROR: {str(e)}" 