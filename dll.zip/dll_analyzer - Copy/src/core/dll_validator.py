"""
DLL validation module for the DLL Analyzer framework.
Provides functionality for analyzing and validating PE/DLL files.
"""

import os
from typing import Dict, List, Optional, Set, Tuple, Any

import pefile
import lief

from src.utils.exceptions import (
    NotDLLError,
    PEParsingError,
    CorruptHeadersError,
    ValidationError
)
from src.utils.logger import DLLAnalyzerLogger, log_api_call
from src.utils.file_utils import calculate_file_hash, get_file_metadata
from src.core.types import (
    ExportInfo,
    ImportInfo,
    DllImport,
    SectionInfo,
    TLSInfo,
    PEInfo,
    LIEFInfo,
    ValidationResult
)
from src.core.constants import (
    IMAGE_FILE_DLL,
    IMAGE_DLLCHARACTERISTICS_DYNAMIC_BASE,
    IMAGE_DLLCHARACTERISTICS_FORCE_INTEGRITY,
    IMAGE_DLLCHARACTERISTICS_NX_COMPAT,
    IMAGE_DLLCHARACTERISTICS_NO_ISOLATION,
    IMAGE_DLLCHARACTERISTICS_NO_SEH,
    IMAGE_DLLCHARACTERISTICS_NO_BIND,
    IMAGE_DLLCHARACTERISTICS_WDM_DRIVER,
    IMAGE_DLLCHARACTERISTICS_TERMINAL_SERVER_AWARE,
    MAX_TLS_CALLBACKS,
    MAX_EXPORTS,
    MAX_IMPORTS,
    MAX_SECTION_NAME_LENGTH,
    SUSPICIOUS_ENTROPY_THRESHOLD,
    HIGH_ENTROPY_THRESHOLD,
    DLL_CHARACTERISTIC_NAMES
)


class DLLValidator:
    """
    Class for validating and analyzing DLL files.
    """
    
    def __init__(self, logger: Optional[DLLAnalyzerLogger] = None):
        """
        Initialize the DLL validator.
        
        Args:
            logger: Optional logger instance
        """
        self.logger = logger or DLLAnalyzerLogger("dll_validator")
    
    def validate(self, file_path: str) -> ValidationResult:
        """
        Validate a DLL file and extract basic information.
        
        Args:
            file_path: Path to the DLL file
            
        Returns:
            Dictionary with DLL information
            
        Raises:
            NotDLLError: If the file is not a DLL
            PEParsingError: If PE parsing fails
            CorruptHeadersError: If PE headers are corrupt
        """
        if not os.path.exists(file_path):
            raise ValidationError(f"File not found: {file_path}", {"file_path": file_path})
        
        self.logger.info(f"Validating DLL: {file_path}")
        
        try:
            # Get file metadata
            metadata = get_file_metadata(file_path)
            
            # Calculate file hashes
            hashes = calculate_file_hash(file_path)
            
            # Try to parse with pefile
            pe_info = self._analyze_with_pefile(file_path)
            
            # If no exports found, try manual extraction
            if not pe_info.get("exports") or len(pe_info.get("exports", [])) == 0:
                self.logger.info("No exports found using pefile, trying manual extraction")
                exports = self._extract_exports_manually(file_path)
                pe_info["exports"] = exports
                pe_info["exports_count"] = len(exports)
                
            # Also try with LIEF for additional info
            lief_info = self._analyze_with_lief(file_path)
            
            # Combine all information
            result = ValidationResult(
                valid=True,
                metadata=metadata,
                hashes=hashes,
                pe_info=pe_info,
                lief_info=lief_info
            )
            
            self.logger.info("DLL validation successful", {"dll_path": file_path})
            return result
            
        except NotDLLError as e:
            self.logger.error(f"Not a DLL: {e}", {"dll_path": file_path})
            raise
        except PEParsingError as e:
            self.logger.error(f"PE parsing error: {e}", {"dll_path": file_path})
            raise
        except CorruptHeadersError as e:
            self.logger.error(f"Corrupt PE headers: {e}", {"dll_path": file_path})
            raise
        except Exception as e:
            self.logger.error(f"Unexpected error during validation: {e}", {"dll_path": file_path})
            raise ValidationError(str(e), {"dll_path": file_path})

    def _analyze_with_pefile(self, file_path: str) -> PEInfo:
        """
        Analyze a DLL file using pefile.
        
        Args:
            file_path: Path to the DLL file
            
        Returns:
            Dictionary with PE information
            
        Raises:
            PEParsingError: If PE parsing fails
            NotDLLError: If the file is not a DLL
            CorruptHeadersError: If PE headers are corrupt
        """
        try:
            pe = pefile.PE(file_path, fast_load=True)
            
            # Check if it's a DLL
            if not (pe.FILE_HEADER.Characteristics & IMAGE_FILE_DLL):
                self.logger.warning("File is not marked as a DLL", {"dll_path": file_path})
                raise NotDLLError("File is not marked as a DLL", {"dll_path": file_path})
            
            # Extract basic information
            machine_type = pe.FILE_HEADER.Machine
            machine_name = pefile.MACHINE_TYPE.get(machine_type, f"Unknown (0x{machine_type:04x})")
            
            # Extract timestamp
            timestamp = pe.FILE_HEADER.TimeDateStamp
            
            # Extract exports
            exports = self._extract_exports(pe)
            
            # Extract imports
            imports = self._extract_imports(pe)
            
            # Extract TLS callbacks
            tls_callbacks = self._extract_tls_callbacks(pe)
            
            # Extract sections
            sections = self._extract_sections(pe)
            
            # Extract DLL characteristics
            characteristics = self._extract_dll_characteristics(pe)
            
            return PEInfo(
                machine_type=machine_name,
                timestamp=timestamp,
                sections=sections,
                characteristics=characteristics,
                image_base=hex(pe.OPTIONAL_HEADER.ImageBase),
                entry_point=hex(pe.OPTIONAL_HEADER.AddressOfEntryPoint),
                exports=exports,
                exports_count=len(exports),
                export_directory=self._extract_export_directory(pe),
                imports=imports,
                tls_callbacks=tls_callbacks,
                subsystem=pefile.SUBSYSTEM_TYPE.get(
                    pe.OPTIONAL_HEADER.Subsystem,
                    f"Unknown (0x{pe.OPTIONAL_HEADER.Subsystem:04x})"
                ),
                size_of_image=pe.OPTIONAL_HEADER.SizeOfImage,
                checksum=pe.OPTIONAL_HEADER.CheckSum
            )
            
        except pefile.PEFormatError as e:
            if "DOS Header magic not found" in str(e):
                raise NotDLLError("Not a valid PE file", {"error_details": str(e), "file_path": file_path})
            elif "Invalid NT Headers signature" in str(e):
                raise CorruptHeadersError("Invalid NT headers", {"error_details": str(e), "file_path": file_path})
                    else:
                raise PEParsingError(f"PE parsing error: {str(e)}", {"error_details": str(e), "file_path": file_path})
        except Exception as e:
            raise PEParsingError(f"Unexpected error during PE analysis: {str(e)}", {"error_details": str(e), "file_path": file_path})

    def _extract_exports(self, pe: pefile.PE) -> List[ExportInfo]:
        """
        Extract exports from a PE file.
        
        Args:
            pe: PE file object
            
        Returns:
            List of export information
        """
        exports = []
        if not hasattr(pe, 'DIRECTORY_ENTRY_EXPORT'):
            return exports
            
        for exp in pe.DIRECTORY_ENTRY_EXPORT.symbols:
            if len(exports) >= MAX_EXPORTS:
                self.logger.warning(f"Reached maximum number of exports ({MAX_EXPORTS})")
                break
                
            export_info = ExportInfo(
                name=exp.name.decode('utf-8', errors='ignore') if exp.name else f"Ordinal_{exp.ordinal}",
                ordinal=exp.ordinal,
                address=pe.OPTIONAL_HEADER.ImageBase + exp.address,
                address_hex=hex(pe.OPTIONAL_HEADER.ImageBase + exp.address),
                ordinal_only=not bool(exp.name),
                forwarder=exp.forwarder.decode('utf-8', errors='ignore') if hasattr(exp, 'forwarder') and exp.forwarder else None
            )
            exports.append(export_info)
            
        return exports

    def _extract_imports(self, pe: pefile.PE) -> List[DllImport]:
        """
        Extract imports from a PE file.
        
        Args:
            pe: PE file object
            
        Returns:
            List of import information
        """
            imports = []
        if not hasattr(pe, 'DIRECTORY_ENTRY_IMPORT'):
            return imports
            
                for imp_dll in pe.DIRECTORY_ENTRY_IMPORT:
            if len(imports) >= MAX_IMPORTS:
                self.logger.warning(f"Reached maximum number of imports ({MAX_IMPORTS})")
                break
                
                    dll_imports = []
                    dll_name = imp_dll.dll.decode('utf-8', errors='ignore')
                    
                    for imp in imp_dll.imports:
                import_info = ImportInfo(
                    name=imp.name.decode('utf-8', errors='ignore') if imp.name else None,
                    ordinal=imp.ordinal if not imp.name else None,
                    address=hex(imp.address)
                )
                dll_imports.append(import_info)
                    
            imports.append(DllImport(
                dll=dll_name,
                imports=dll_imports
            ))
            
        return imports

    def _extract_tls_callbacks(self, pe: pefile.PE) -> List[TLSInfo]:
        """
        Extract TLS callbacks from a PE file.
        
        Args:
            pe: PE file object
            
        Returns:
            List of TLS callback information
        """
            tls_callbacks = []
        if not hasattr(pe, 'DIRECTORY_ENTRY_TLS') or not hasattr(pe.DIRECTORY_ENTRY_TLS.struct, 'AddressOfCallBacks'):
            return tls_callbacks
            
                callback_array_va = pe.DIRECTORY_ENTRY_TLS.struct.AddressOfCallBacks
        if not callback_array_va:
            return tls_callbacks
                
                    # Get the RVA
                    callback_array_rva = callback_array_va - pe.OPTIONAL_HEADER.ImageBase
                    
                    # Find the section containing the callbacks
                    section = None
                    for s in pe.sections:
                        if s.contains_rva(callback_array_rva):
                            section = s
                            break
                    
        if not section:
            return tls_callbacks
            
                        # Calculate the file offset
                        callbacks_offset = (callback_array_rva - section.VirtualAddress) + section.PointerToRawData
                        
                        # Read the array of callback addresses (each entry is a pointer)
                        pointer_size = 8 if pe.FILE_HEADER.Machine == pefile.MACHINE_TYPE['IMAGE_FILE_MACHINE_AMD64'] else 4
                        callback_offset = callbacks_offset
                        
        callback_count = 0
        while callback_count < MAX_TLS_CALLBACKS:
                            pe.seek(callback_offset)
                            callback_rva_bytes = pe.read(pointer_size)
                            
                            # Convert bytes to integer (respecting architecture)
                                callback_rva = int.from_bytes(callback_rva_bytes, byteorder='little')
                            
                            # End of array is marked by a null pointer
                            if callback_rva == 0:
                                break
                                
            tls_callbacks.append(TLSInfo(
                address=hex(callback_rva),
                rva=hex(callback_rva - pe.OPTIONAL_HEADER.ImageBase)
            ))
                            
                            callback_offset += pointer_size
            callback_count += 1
            
        if callback_count >= MAX_TLS_CALLBACKS:
            self.logger.warning(f"Reached maximum number of TLS callbacks ({MAX_TLS_CALLBACKS})")
            
        return tls_callbacks

    def _extract_sections(self, pe: pefile.PE) -> List[SectionInfo]:
        """
        Extract section information from a PE file.
        
        Args:
            pe: PE file object
            
        Returns:
            List of section information
        """
            sections = []
            for section in pe.sections:
            # Validate section name length
            name = section.Name.decode('utf-8', errors='replace').strip('\x00')
            if len(name) > MAX_SECTION_NAME_LENGTH:
                self.logger.warning(f"Section name exceeds maximum length: {name}")
                name = name[:MAX_SECTION_NAME_LENGTH]
                
            # Calculate entropy
            entropy = section.get_entropy()
            
            # Log suspicious entropy
            if entropy >= SUSPICIOUS_ENTROPY_THRESHOLD:
                self.logger.warning(f"High entropy section detected: {name} ({entropy:.2f})")
            elif entropy >= HIGH_ENTROPY_THRESHOLD:
                self.logger.info(f"Moderately high entropy section: {name} ({entropy:.2f})")
                
            sections.append(SectionInfo(
                name=name,
                virtual_size=section.Misc_VirtualSize,
                virtual_address=hex(section.VirtualAddress),
                raw_size=section.SizeOfRawData,
                characteristics=hex(section.Characteristics),
                entropy=entropy
            ))
            
        return sections

    def _extract_dll_characteristics(self, pe: pefile.PE) -> List[str]:
        """
        Extract DLL characteristics from a PE file.
        
        Args:
            pe: PE file object
            
        Returns:
            List of characteristic names
        """
        characteristics = []
        dll_characteristics = pe.OPTIONAL_HEADER.DllCharacteristics
        
        for flag_value, flag_name in DLL_CHARACTERISTIC_NAMES.items():
                if dll_characteristics & flag_value:
                    characteristics.append(flag_name)
                
        return characteristics

    def _extract_export_directory(self, pe: pefile.PE) -> Dict[str, Any]:
        """
        Extract export directory information from a PE file.
        
        Args:
            pe: PE file object
            
        Returns:
            Dictionary with export directory information
        """
        if not hasattr(pe, 'DIRECTORY_ENTRY_EXPORT'):
            return {}
            
            return {
            "characteristics": pe.DIRECTORY_ENTRY_EXPORT.struct.Characteristics,
            "timestamp": pe.DIRECTORY_ENTRY_EXPORT.struct.TimeDateStamp,
            "major_version": pe.DIRECTORY_ENTRY_EXPORT.struct.MajorVersion,
            "minor_version": pe.DIRECTORY_ENTRY_EXPORT.struct.MinorVersion,
            "name": pe.DIRECTORY_ENTRY_EXPORT.struct.Name,
            "base": pe.DIRECTORY_ENTRY_EXPORT.struct.Base,
            "number_of_functions": pe.DIRECTORY_ENTRY_EXPORT.struct.NumberOfFunctions,
            "number_of_names": pe.DIRECTORY_ENTRY_EXPORT.struct.NumberOfNames,
            "address_of_functions": pe.DIRECTORY_ENTRY_EXPORT.struct.AddressOfFunctions,
            "address_of_names": pe.DIRECTORY_ENTRY_EXPORT.struct.AddressOfNames,
            "address_of_name_ordinals": pe.DIRECTORY_ENTRY_EXPORT.struct.AddressOfNameOrdinals
        }

    def _analyze_with_lief(self, file_path: str) -> LIEFInfo:
        """
        Analyze a DLL file using LIEF.
        
        Args:
            file_path: Path to the DLL file
            
        Returns:
            Dictionary with additional information from LIEF
            
        Raises:
            NotDLLError: If the file is not a valid PE file
        """
        try:
            binary = lief.parse(file_path)
            
            if binary is None:
                raise NotDLLError("Not a valid PE file", {"file_path": file_path})
                
            # Check if it's a PE file
            is_pe = False
            if hasattr(binary, 'format'):
                if hasattr(lief, 'EXE_FORMATS'):
                    is_pe = binary.format == lief.EXE_FORMATS.PE
                else:
                    is_pe = 'PE' in str(binary.format)
            else:
                is_pe = hasattr(binary, 'header') and hasattr(binary, 'optional_header')
                
            if not is_pe:
                raise NotDLLError("Not a valid PE file", {"file_path": file_path})
                
            # Extract resources
            resources = []
            if hasattr(binary, 'has_resources') and binary.has_resources:
                for resource_type in binary.resources.childs:
                    for resource_id in resource_type.childs:
                        for resource_lang in resource_id.childs:
                            resources.append({
                                "type": resource_type.id,
                                "id": resource_id.id,
                                "language": resource_lang.id,
                                "size": len(resource_lang.content) if resource_lang.content else 0
                            })
            
            # Extract signatures
            signatures = []
            if hasattr(binary, 'has_signatures') and binary.has_signatures:
                for signature in binary.signatures:
                    signatures.append({
                        "version": signature.version,
                        "digest_algorithm": str(signature.digest_algorithm)
                    })
            
            # Extract debug information
            debug_info = []
            if hasattr(binary, 'has_debug') and binary.has_debug:
                for debug_entry in binary.debug:
                    debug_info.append({
                        "type": str(debug_entry.type),
                        "characteristics": debug_entry.characteristics,
                        "timestamp": debug_entry.timestamp,
                        "major_version": debug_entry.major_version,
                        "minor_version": debug_entry.minor_version
                    })
            
            # Rich header info
            rich_header = {}
            if hasattr(binary, 'has_rich_header') and binary.has_rich_header:
                rich_header = {
                    "key": binary.rich_header.key,
                    "entries": [
                        {
                            "id": entry.id,
                            "build_id": entry.build_id,
                            "count": entry.count
                        }
                        for entry in binary.rich_header.entries
                    ]
                }
            
            return LIEFInfo(
                resources=resources,
                signatures=signatures,
                debug_info=debug_info,
                rich_header=rich_header,
                compiler=str(binary.header.characteristics_list) if hasattr(binary, 'header') and hasattr(binary.header, 'characteristics_list') else "",
                error=None,
                parsed=True
            )
            
        except Exception as e:
            self.logger.warning(f"LIEF analysis failed: {e}", {"file_path": file_path})
            return LIEFInfo(
                resources=[],
                signatures=[],
                debug_info=[],
                rich_header={},
                compiler="",
                error=f"LIEF analysis failed: {str(e)}",
                parsed=False
            )

    def _extract_exports_manually(self, file_path: str) -> List[ExportInfo]:
        """
        Manually extract exports from a DLL using direct PE parsing.
        
        Args:
            file_path: Path to the DLL file
            
        Returns:
            List of exports with names and ordinals
        """
        try:
            self.logger.info(f"Manually extracting exports from {file_path}")
            
            # Load the DLL using ctypes to get exports
            from ctypes import WinDLL, c_void_p, byref, sizeof, Structure, POINTER, c_char, c_ulong
            from ctypes.wintypes import HMODULE, DWORD, LPCSTR, WORD, BYTE
            
            # Load Windows API functions
            from ctypes import windll
            
            # Define structures for PE parsing
            class IMAGE_EXPORT_DIRECTORY(Structure):
                _fields_ = [
                    ("Characteristics", DWORD),
                    ("TimeDateStamp", DWORD),
                    ("MajorVersion", WORD),
                    ("MinorVersion", WORD),
                    ("Name", DWORD),
                    ("Base", DWORD),
                    ("NumberOfFunctions", DWORD),
                    ("NumberOfNames", DWORD),
                    ("AddressOfFunctions", DWORD),
                    ("AddressOfNames", DWORD),
                    ("AddressOfNameOrdinals", DWORD)
                ]
            
            # Load the DLL
            dll_handle = windll.kernel32.LoadLibraryExA(file_path.encode(), 0, 2)  # DONT_RESOLVE_DLL_REFERENCES
            if not dll_handle:
                self.logger.error(f"Failed to load DLL for export analysis: {file_path}")
                return []
            
            try:
                # Get module information
                exports = []
                
                # Get export directory
                export_dir_rva = self._get_export_directory_rva(dll_handle)
                if not export_dir_rva:
                    self.logger.warning(f"No export directory found in {file_path}")
                    return []
                
                # Get export directory
                export_dir = c_void_p(dll_handle + export_dir_rva)
                export_dir = IMAGE_EXPORT_DIRECTORY.from_address(export_dir.value)
                
                # Get function addresses, names, and ordinals
                functions_rva = export_dir.AddressOfFunctions
                names_rva = export_dir.AddressOfNames
                ordinals_rva = export_dir.AddressOfNameOrdinals
                
                # Get function count
                num_functions = export_dir.NumberOfFunctions
                num_names = export_dir.NumberOfNames
                ordinal_base = export_dir.Base
                
                self.logger.info(f"Found {num_functions} functions, {num_names} named exports")
                
                # Extract named exports
                for i in range(num_names):
                    if len(exports) >= MAX_EXPORTS:
                        self.logger.warning(f"Reached maximum number of exports ({MAX_EXPORTS})")
                        break
                        
                    # Get name RVA
                    name_rva_ptr = c_void_p(dll_handle + names_rva + i * 4)
                    name_rva = DWORD.from_address(name_rva_ptr.value).value
                    
                    # Get name
                    name_ptr = c_void_p(dll_handle + name_rva)
                    name = self._read_c_string(name_ptr.value)
                    
                    # Get ordinal
                    ordinal_ptr = c_void_p(dll_handle + ordinals_rva + i * 2)
                    ordinal = WORD.from_address(ordinal_ptr.value).value
                    
                    # Get function address
                    function_rva_ptr = c_void_p(dll_handle + functions_rva + ordinal * 4)
                    function_rva = DWORD.from_address(function_rva_ptr.value).value
                    
                    # Add to exports
                    exports.append(ExportInfo(
                        name=name,
                        ordinal=ordinal_base + ordinal,
                        address=dll_handle + function_rva,
                        address_hex=hex(dll_handle + function_rva),
                        ordinal_only=False,
                        forwarder=None
                    ))
                
                # Extract ordinal-only exports
                if num_functions > num_names:
                    for i in range(num_functions):
                        if len(exports) >= MAX_EXPORTS:
                            self.logger.warning(f"Reached maximum number of exports ({MAX_EXPORTS})")
                            break
                            
                        # Check if this function is already in exports (has a name)
                        if any(export["ordinal"] == ordinal_base + i for export in exports):
                            continue
                        
                        # Get function address
                        function_rva_ptr = c_void_p(dll_handle + functions_rva + i * 4)
                        function_rva = DWORD.from_address(function_rva_ptr.value).value
                        
                        # Skip if function is not exported
                        if function_rva == 0:
                            continue
                        
                        # Add to exports
                        exports.append(ExportInfo(
                            name=f"Ordinal_{ordinal_base + i}",
                            ordinal=ordinal_base + i,
                            address=dll_handle + function_rva,
                            address_hex=hex(dll_handle + function_rva),
                            ordinal_only=True,
                            forwarder=None
                        ))
                
                return exports
                
            finally:
                # Free the library
                windll.kernel32.FreeLibrary(dll_handle)
                
        except Exception as e:
            self.logger.error(f"Error extracting exports manually: {str(e)}")
            return []
    
    def _read_c_string(self, address: int) -> str:
        """
        Read a null-terminated C string from memory.
        
        Args:
            address: Memory address to read from
            
        Returns:
            Decoded string
        """
        result = ""
        i = 0
        while True:
            char = chr(BYTE.from_address(address + i).value)
            if char == '\0':
                break
            result += char
            i += 1
        return result
    
    def _get_export_directory_rva(self, module_base: int) -> int:
        """
        Get the RVA (Relative Virtual Address) of the export directory.
        
        Args:
            module_base: Base address of the module
            
        Returns:
            RVA of the export directory or 0 if not found
        """
        try:
            # Define constants
            IMAGE_DIRECTORY_ENTRY_EXPORT = 0
            
            # Get DOS header
            dos_header = c_void_p(module_base)
            e_lfanew = DWORD.from_address(dos_header.value + 0x3C).value
            
            # Get NT headers
            nt_headers = c_void_p(module_base + e_lfanew)
            
            # Get data directory (export directory is at index 0)
            data_directory_offset = 0x78  # Offset to data directory in PE32+
            data_directory = c_void_p(nt_headers.value + data_directory_offset)
            
            # Get export directory RVA
            export_dir_rva = DWORD.from_address(data_directory.value + 
                               IMAGE_DIRECTORY_ENTRY_EXPORT * 8).value
            
            return export_dir_rva
            
        except Exception as e:
            self.logger.error(f"Error getting export directory RVA: {str(e)}")
            return 0 