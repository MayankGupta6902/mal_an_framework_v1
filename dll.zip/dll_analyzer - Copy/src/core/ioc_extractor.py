"""
IOC Extractor - Extract potential indicators of compromise from DLL analysis results
"""

import re
import json
import math
from pathlib import Path
from typing import Dict, List, Any, Optional, Set, Tuple

import config
from src.utils.logger import DLLAnalyzerLogger as Logger
from src.utils.exceptions import IOCExtractionError

logger = Logger("IOCExtractor")

class IOCExtractor:
    """Extract and analyze potential indicators of compromise from DLL analysis results"""
    
    def __init__(self, analysis_results: Dict[str, Any], dll_path: str):
        """
        Initialize the IOC extractor
        
        Args:
            analysis_results: Dictionary containing analysis results from various components
            dll_path: Path to the analyzed DLL file
        """
        self.analysis_results = analysis_results
        self.dll_path = Path(dll_path)
        self.iocs: Dict[str, Any] = {
            "suspicious_strings": [],
            "suspicious_imports": [],
            "suspicious_sections": [],
            "suspicious_behavior": {
                "file_operations": [],
                "registry_operations": [],
                "network_operations": [],
                "process_operations": [],
                "crypto_operations": [],
            },
            "overall_risk_score": 0,
        }
    
    def extract_iocs(self) -> Dict[str, Any]:
        """
        Extract all potential indicators of compromise
        
        Returns:
            Dictionary containing extracted IOCs and risk assessment
        """
        try:
            # Extract IOCs from structure analysis
            if "structure_analysis" in self.analysis_results:
                self._extract_from_structure()
            
            # Extract IOCs from function invocation
            if "function_invocation" in self.analysis_results or "dllmain_invocation" in self.analysis_results:
                self._extract_from_invocation()
            
            # Extract IOCs from monitoring results
            if "monitoring" in self.analysis_results:
                self._extract_from_monitoring()
            
            # Calculate overall risk score
            self._calculate_risk_score()
            
            return self.iocs
        
        except Exception as e:
            logger.error(f"Error extracting IOCs: {str(e)}", exc_info=True)
            raise IOCExtractionError(f"Failed to extract IOCs: {str(e)}")
    
    def _extract_from_structure(self) -> None:
        """Extract IOCs from DLL structure analysis"""
        structure = self.analysis_results["structure_analysis"]
        
        # Check for suspicious imports
        if "imports" in structure:
            self._analyze_imports(structure["imports"])
        
        # Check for suspicious sections
        if "sections" in structure:
            self._analyze_sections(structure["sections"])
        
        # Check for suspicious strings
        if "strings" in structure:
            self._analyze_strings(structure["strings"])
    
    def _extract_from_invocation(self) -> None:
        """Extract IOCs from function invocation results"""
        invocation = self.analysis_results.get("function_invocation", 
                                              self.analysis_results.get("dllmain_invocation", {}))
        
        # Check for exceptions or crashes
        if "error" in invocation:
            self.iocs["suspicious_behavior"]["crashes"] = invocation["error"]
        
        # Check for return values
        if "return_value" in invocation:
            self._analyze_return_value(invocation["return_value"])
    
    def _extract_from_monitoring(self) -> None:
        """Extract IOCs from monitoring results"""
        monitoring = self.analysis_results["monitoring"]
        
        # Extract from Procmon results
        if "procmon" in monitoring:
            self._analyze_procmon_results(monitoring["procmon"])
        
        # Extract from Frida API monitoring
        if "frida" in monitoring:
            self._analyze_frida_results(monitoring["frida"])
    
    def _analyze_imports(self, imports: List[Dict[str, Any]]) -> None:
        """
        Analyze imported functions for suspicious patterns
        
        Args:
            imports: List of imported functions and libraries
        """
        suspicious_imports = []
        
        # Known suspicious imports and their risk scores
        suspicious_import_patterns = {
            # Anti-analysis techniques
            "IsDebuggerPresent": 7,
            "CheckRemoteDebuggerPresent": 8,
            "OutputDebugString": 5,
            "GetTickCount": 3,
            "QueryPerformanceCounter": 3,
            
            # Code injection
            "VirtualAlloc": 5,
            "VirtualProtect": 6,
            "WriteProcessMemory": 8,
            "CreateRemoteThread": 9,
            
            # Process manipulation
            "CreateProcess": 4,
            "ShellExecute": 6,
            "WinExec": 7,
            "system": 8,
            
            # Registry manipulation
            "RegCreateKey": 5,
            "RegSetValue": 5,
            
            # Network activity
            "WSAStartup": 4,
            "connect": 4,
            "InternetOpen": 4,
            "HttpSendRequest": 5,
            
            # Persistence
            "RegSetValueEx": 6,
        }
        
        for imp in imports:
            library = imp.get("library", "").lower()
            functions = imp.get("functions", [])
            
            # Check for suspicious libraries
            if any(lib in library for lib in ["wininet", "urlmon", "ws2_32"]):
                suspicious_imports.append({
                    "type": "library",
                    "name": library,
                    "risk_score": 4,
                    "reason": "Networking capabilities"
                })
            
            # Check for suspicious functions
            for function in functions:
                for pattern, risk_score in suspicious_import_patterns.items():
                    if pattern.lower() in function.lower():
                        suspicious_imports.append({
                            "type": "function",
                            "name": function,
                            "library": library,
                            "risk_score": risk_score,
                            "reason": self._get_import_reason(pattern)
                        })
        
        self.iocs["suspicious_imports"] = suspicious_imports
    
    def _get_import_reason(self, import_name: str) -> str:
        """Get the reason why an import is considered suspicious"""
        reasons = {
            "IsDebuggerPresent": "Anti-debugging technique",
            "CheckRemoteDebuggerPresent": "Anti-debugging technique",
            "OutputDebugString": "Possible anti-debugging technique",
            "GetTickCount": "Possible anti-VM/sandbox evasion",
            "QueryPerformanceCounter": "Possible anti-VM/sandbox evasion",
            "VirtualAlloc": "Memory allocation (possible for shellcode)",
            "VirtualProtect": "Memory protection modification (possible for shellcode execution)",
            "WriteProcessMemory": "Process memory manipulation",
            "CreateRemoteThread": "Remote code execution capability",
            "CreateProcess": "Process creation capability",
            "ShellExecute": "Process execution capability",
            "WinExec": "Process execution capability",
            "system": "Command execution capability",
            "RegCreateKey": "Registry modification capability",
            "RegSetValue": "Registry modification capability",
            "WSAStartup": "Network communication capability",
            "connect": "Network connection capability",
            "InternetOpen": "Web access capability",
            "HttpSendRequest": "Web request capability",
            "RegSetValueEx": "Persistence capability",
        }
        
        return reasons.get(import_name, "Suspicious behavior")
    
    def _analyze_sections(self, sections: List[Dict[str, Any]]) -> None:
        """
        Analyze PE sections for suspicious characteristics
        
        Args:
            sections: List of PE sections with their properties
        """
        suspicious_sections = []
        
        for section in sections:
            section_name = section.get("name", "")
            entropy = section.get("entropy", 0)
            characteristics = section.get("characteristics", [])
            
            # Check for high entropy (possible packing/encryption)
            if entropy > config.IOC_THRESHOLDS["entropy_threshold"]:
                suspicious_sections.append({
                    "name": section_name,
                    "entropy": entropy,
                    "risk_score": 7,
                    "reason": f"High entropy ({entropy:.2f}) suggests encryption or packing"
                })
            
            # Check for suspicious characteristics
            if "MEM_EXECUTE" in characteristics and "MEM_WRITE" in characteristics:
                suspicious_sections.append({
                    "name": section_name,
                    "characteristics": characteristics,
                    "risk_score": 8,
                    "reason": "Section has both write and execute permissions (potential shellcode)"
                })
            
            # Check for unusual section names
            if section_name not in [".text", ".data", ".rdata", ".rsrc", ".reloc"]:
                suspicious_sections.append({
                    "name": section_name,
                    "risk_score": 3,
                    "reason": "Unusual section name"
                })
        
        self.iocs["suspicious_sections"] = suspicious_sections
    
    def _analyze_strings(self, strings: List[str]) -> None:
        """
        Analyze embedded strings for suspicious patterns
        
        Args:
            strings: List of strings extracted from the DLL
        """
        suspicious_strings = []
        
        # Check for known suspicious strings
        for string in strings:
            for pattern in config.SUSPICIOUS_STRINGS:
                if pattern.lower() in string.lower():
                    suspicious_strings.append({
                        "string": string,
                        "matched_pattern": pattern,
                        "risk_score": 6,
                        "reason": "Contains suspicious command or program reference"
                    })
        
        # Check for URLs and IP addresses
        url_pattern = r'https?://[^\s/$.?#].[^\s]*'
        ip_pattern = r'\b(?:\d{1,3}\.){3}\d{1,3}\b'
        
        for string in strings:
            # Check for URLs
            urls = re.findall(url_pattern, string)
            for url in urls:
                suspicious_strings.append({
                    "string": url,
                    "risk_score": 5,
                    "reason": "Contains URL"
                })
            
            # Check for IP addresses
            ips = re.findall(ip_pattern, string)
            for ip in ips:
                suspicious_strings.append({
                    "string": ip,
                    "risk_score": 5,
                    "reason": "Contains IP address"
                })
        
        self.iocs["suspicious_strings"] = suspicious_strings
    
    def _analyze_return_value(self, return_value: Any) -> None:
        """
        Analyze function return values for suspicious patterns
        
        Args:
            return_value: Return value from function invocation
        """
        # Implementation depends on the specific function called
        # This is a placeholder for custom analysis
        pass
    
    def _analyze_procmon_results(self, procmon_results: List[Dict[str, Any]]) -> None:
        """
        Analyze Process Monitor results for suspicious behavior
        
        Args:
            procmon_results: List of events captured by Process Monitor
        """
        file_ops = []
        registry_ops = []
        process_ops = []
        
        # Count operations by type
        file_op_count = 0
        reg_op_count = 0
        proc_op_count = 0
        
        for event in procmon_results:
            event_type = event.get("type", "")
            path = event.get("path", "")
            result = event.get("result", "")
            
            # File operations
            if event_type in ["CreateFile", "WriteFile", "ReadFile", "DeleteFile"]:
                file_op_count += 1
                
                # Check for operations on sensitive paths
                for sensitive_path in config.SENSITIVE_PATHS:
                    if sensitive_path in path:
                        file_ops.append({
                            "operation": event_type,
                            "path": path,
                            "result": result,
                            "risk_score": 7 if event_type in ["WriteFile", "DeleteFile"] else 4,
                            "reason": f"Operation on sensitive path: {sensitive_path}"
                        })
            
            # Registry operations
            elif event_type in ["RegOpenKey", "RegCreateKey", "RegSetValue", "RegDeleteValue", "RegDeleteKey"]:
                reg_op_count += 1
                
                # Check for operations on sensitive registry keys
                for sensitive_path in config.SENSITIVE_PATHS:
                    if sensitive_path in path and "HKEY_" in path:
                        registry_ops.append({
                            "operation": event_type,
                            "path": path,
                            "result": result,
                            "risk_score": 7 if event_type in ["RegCreateKey", "RegSetValue", "RegDeleteValue"] else 4,
                            "reason": f"Operation on sensitive registry key: {sensitive_path}"
                        })
            
            # Process operations
            elif event_type in ["Process Create", "Thread Create"]:
                proc_op_count += 1
                
                # Check for process creation
                if event_type == "Process Create":
                    process_ops.append({
                        "operation": event_type,
                        "path": path,
                        "result": result,
                        "risk_score": 8,
                        "reason": "Process creation detected"
                    })
        
        # Check for excessive operations
        if file_op_count > config.IOC_THRESHOLDS["max_file_operations"]:
            self.iocs["suspicious_behavior"]["file_operations"].append({
                "type": "excessive_operations",
                "count": file_op_count,
                "risk_score": 6,
                "reason": f"Excessive file operations: {file_op_count}"
            })
        
        if reg_op_count > config.IOC_THRESHOLDS["max_registry_operations"]:
            self.iocs["suspicious_behavior"]["registry_operations"].append({
                "type": "excessive_operations",
                "count": reg_op_count,
                "risk_score": 6,
                "reason": f"Excessive registry operations: {reg_op_count}"
            })
        
        # Add detailed operations to IOCs
        self.iocs["suspicious_behavior"]["file_operations"].extend(file_ops)
        self.iocs["suspicious_behavior"]["registry_operations"].extend(registry_ops)
        self.iocs["suspicious_behavior"]["process_operations"].extend(process_ops)
    
    def _analyze_frida_results(self, frida_results: List[Dict[str, Any]]) -> None:
        """
        Analyze Frida API monitoring results for suspicious behavior
        
        Args:
            frida_results: List of API calls captured by Frida
        """
        file_ops = []
        registry_ops = []
        network_ops = []
        process_ops = []
        crypto_ops = []
        
        # Group API calls by category
        for api_call in frida_results:
            module = api_call.get("module", "")
            function = api_call.get("function", "")
            args = api_call.get("arguments", {})
            
            # File operations
            if any(api in f"{module}!{function}" for api in config.API_HOOKS["file_operations"]):
                file_path = args.get("lpFileName", "")
                
                # Check for operations on sensitive paths
                for sensitive_path in config.SENSITIVE_PATHS:
                    if sensitive_path in file_path:
                        file_ops.append({
                            "api": f"{module}!{function}",
                            "path": file_path,
                            "risk_score": 6,
                            "reason": f"File operation on sensitive path: {sensitive_path}"
                        })
            
            # Registry operations
            elif any(api in f"{module}!{function}" for api in config.API_HOOKS["registry_operations"]):
                key_path = args.get("lpSubKey", "")
                
                # Check for operations on sensitive registry keys
                for sensitive_path in config.SENSITIVE_PATHS:
                    if "HKEY_" in sensitive_path and sensitive_path in key_path:
                        registry_ops.append({
                            "api": f"{module}!{function}",
                            "path": key_path,
                            "risk_score": 7,
                            "reason": f"Registry operation on sensitive key: {sensitive_path}"
                        })
            
            # Network operations
            elif any(api in f"{module}!{function}" for api in config.API_HOOKS["network_operations"]):
                host = args.get("lpszServerName", args.get("host", ""))
                
                network_ops.append({
                    "api": f"{module}!{function}",
                    "host": host,
                    "risk_score": 6,
                    "reason": "Network communication detected"
                })
            
            # Process operations
            elif any(api in f"{module}!{function}" for api in config.API_HOOKS["process_operations"]):
                if "CreateProcess" in function:
                    cmd_line = args.get("lpCommandLine", "")
                    
                    process_ops.append({
                        "api": f"{module}!{function}",
                        "command": cmd_line,
                        "risk_score": 8,
                        "reason": "Process creation detected"
                    })
                
                elif "VirtualAlloc" in function or "VirtualProtect" in function:
                    protection = args.get("flProtect", 0)
                    
                    # Check for executable memory allocation
                    if protection & 0x10:  # PAGE_EXECUTE
                        process_ops.append({
                            "api": f"{module}!{function}",
                            "protection": protection,
                            "risk_score": 7,
                            "reason": "Executable memory allocation detected"
                        })
            
            # Crypto operations
            elif any(api in f"{module}!{function}" for api in config.API_HOOKS["crypto_operations"]):
                crypto_ops.append({
                    "api": f"{module}!{function}",
                    "risk_score": 4,
                    "reason": "Cryptographic operation detected"
                })
        
        # Add detailed operations to IOCs
        self.iocs["suspicious_behavior"]["file_operations"].extend(file_ops)
        self.iocs["suspicious_behavior"]["registry_operations"].extend(registry_ops)
        self.iocs["suspicious_behavior"]["network_operations"].extend(network_ops)
        self.iocs["suspicious_behavior"]["process_operations"].extend(process_ops)
        self.iocs["suspicious_behavior"]["crypto_operations"].extend(crypto_ops)
    
    def _calculate_risk_score(self) -> None:
        """Calculate overall risk score based on extracted IOCs"""
        risk_score = 0
        max_score = 100
        
        # Add scores from suspicious imports
        for imp in self.iocs["suspicious_imports"]:
            risk_score += imp.get("risk_score", 0)
        
        # Add scores from suspicious sections
        for section in self.iocs["suspicious_sections"]:
            risk_score += section.get("risk_score", 0)
        
        # Add scores from suspicious strings
        for string in self.iocs["suspicious_strings"]:
            risk_score += string.get("risk_score", 0)
        
        # Add scores from suspicious behavior
        for category in self.iocs["suspicious_behavior"]:
            for behavior in self.iocs["suspicious_behavior"][category]:
                risk_score += behavior.get("risk_score", 0)
        
        # Cap the risk score at max_score
        risk_score = min(risk_score, max_score)
        
        # Normalize the risk score to a 0-100 scale
        self.iocs["overall_risk_score"] = risk_score
        
        # Add risk assessment
        if risk_score >= 75:
            risk_level = "Critical"
            recommendation = "Highly suspicious. Likely malicious. Immediate isolation recommended."
        elif risk_score >= 50:
            risk_level = "High"
            recommendation = "Multiple suspicious indicators detected. Further analysis recommended."
        elif risk_score >= 25:
            risk_level = "Medium"
            recommendation = "Some suspicious behavior detected. Caution advised."
        else:
            risk_level = "Low"
            recommendation = "Few or no suspicious indicators. Likely benign."
        
        self.iocs["risk_assessment"] = {
            "risk_level": risk_level,
            "recommendation": recommendation
        }

    def save_to_file(self, output_path: Optional[Path] = None) -> Path:
        """
        Save extracted IOCs to a JSON file
        
        Args:
            output_path: Optional path to save the IOCs. If None, uses default naming.
            
        Returns:
            Path to the saved file
        """
        if output_path is None:
            output_path = Path(config.OUTPUT_DIR) / self.dll_path.stem / "ioc_report.json"
        
        # Ensure the directory exists
        output_path.parent.mkdir(parents=True, exist_ok=True)
        
        # Save the IOCs to file
        with open(output_path, "w") as f:
            json.dump(self.iocs, f, indent=2)
        
        logger.info(f"IOC report saved to {output_path}")
        return output_path 