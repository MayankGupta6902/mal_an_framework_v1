"""
Logger module for DLL Analyzer framework.
Provides unified logging for both JSON and plaintext output.
"""

import json
import logging
import os
import sys
import time
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Optional, Union

# Configure logging directory
LOG_DIR = Path("logs")
LOG_DIR.mkdir(exist_ok=True)

# Log file paths
ACTIVITY_LOG_PATH = LOG_DIR / "activity_trace.json"
ERROR_LOG_PATH = LOG_DIR / "errors.log"
API_CALL_LOG_PATH = LOG_DIR / "api_call_log.json"


class DLLAnalyzerLogger:
    """
    Unified logging system for the DLL Analyzer framework.
    Handles both JSON structured logging and traditional text logging.
    """

    def __init__(self, name: str, verbose: bool = False):
        """
        Initialize the logger with the specified name.
        
        Args:
            name: Logger name (typically module or component name)
            verbose: Whether to output verbose logs to console
        """
        self.name = name
        self.verbose = verbose
        
        # Setup error logger (text-based)
        self.error_logger = logging.getLogger(f"{name}_error")
        self.error_logger.setLevel(logging.DEBUG)
        
        # File handler for error logs
        error_handler = logging.FileHandler(ERROR_LOG_PATH)
        error_handler.setLevel(logging.DEBUG)
        formatter = logging.Formatter(
            '%(asctime)s [%(levelname)s] [%(name)s] - %(message)s',
            '%Y-%m-%d %H:%M:%S'
        )
        error_handler.setFormatter(formatter)
        self.error_logger.addHandler(error_handler)
        
        # Console handler for immediate feedback
        if verbose:
            console_handler = logging.StreamHandler(sys.stdout)
            console_handler.setLevel(logging.INFO)
            console_handler.setFormatter(formatter)
            self.error_logger.addHandler(console_handler)
        
        # Ensure JSON log files exist with proper structure
        self._initialize_json_logs()
    
    def _initialize_json_logs(self) -> None:
        """Initialize JSON log files if they don't exist."""
        # Activity trace log
        if not ACTIVITY_LOG_PATH.exists():
            with open(ACTIVITY_LOG_PATH, 'w') as f:
                json.dump({"events": []}, f)
                
        # API call log
        if not API_CALL_LOG_PATH.exists():
            with open(API_CALL_LOG_PATH, 'w') as f:
                json.dump({"api_calls": []}, f)
    
    def log_activity(self, activity_type: str, details: Dict[str, Any], 
                     status: str = "success") -> None:
        """
        Log an activity to the JSON activity trace log.
        
        Args:
            activity_type: Type of activity (e.g., "invoke_function", "scan_exports")
            details: Dictionary with activity details
            status: Status of activity ("success", "warning", "error")
        """
        timestamp = datetime.now().isoformat()
        
        event = {
            "timestamp": timestamp,
            "module": self.name,
            "type": activity_type,
            "status": status,
            "details": details
        }
        
        try:
            # Read existing log
            with open(ACTIVITY_LOG_PATH, 'r') as f:
                log_data = json.load(f)
                
            # Append new event
            log_data["events"].append(event)
            
            # Write back to file
            with open(ACTIVITY_LOG_PATH, 'w') as f:
                json.dump(log_data, f, indent=2)
                
            if self.verbose:
                print(f"[{timestamp}] {activity_type}: {status}")
                
        except Exception as e:
            self.error("Failed to write to activity log", {"error": str(e)})
    
    def log_api_call(self, api_name: str, arguments: Dict[str, Any],
                    return_value: Any, duration_ms: float) -> None:
        """
        Log an API call to the API call log.
        
        Args:
            api_name: Name of the API function called
            arguments: Dictionary of arguments passed
            return_value: Return value from the call
            duration_ms: Duration of the call in milliseconds
        """
        timestamp = datetime.now().isoformat()
        
        api_call = {
            "timestamp": timestamp,
            "api_name": api_name,
            "arguments": arguments,
            "return_value": str(return_value),
            "duration_ms": duration_ms,
            "process_id": os.getpid()
        }
        
        try:
            # Read existing log
            with open(API_CALL_LOG_PATH, 'r') as f:
                log_data = json.load(f)
                
            # Append new call
            log_data["api_calls"].append(api_call)
            
            # Write back to file
            with open(API_CALL_LOG_PATH, 'w') as f:
                json.dump(log_data, f, indent=2)
                
        except Exception as e:
            self.error("Failed to write to API call log", {"error": str(e)})
    
    def info(self, message: str, details: Optional[Dict[str, Any]] = None) -> None:
        """Log an info message."""
        self.error_logger.info(message)
        if details:
            self.log_activity("info", {"message": message, **details})
        else:
            self.log_activity("info", {"message": message})
    
    def warning(self, message: str, details: Optional[Dict[str, Any]] = None) -> None:
        """Log a warning message."""
        self.error_logger.warning(message)
        if details:
            self.log_activity("warning", {"message": message, **details}, status="warning")
        else:
            self.log_activity("warning", {"message": message}, status="warning")
    
    def error(self, message: str, details: Optional[Dict[str, Any]] = None) -> None:
        """Log an error message."""
        self.error_logger.error(message)
        if details:
            self.log_activity("error", {"message": message, **details}, status="error")
        else:
            self.log_activity("error", {"message": message}, status="error")
    
    def debug(self, message: str, details: Optional[Dict[str, Any]] = None) -> None:
        """Log a debug message."""
        self.error_logger.debug(message)
        if details and self.verbose:
            self.log_activity("debug", {"message": message, **details})
    
    def critical(self, message: str, details: Optional[Dict[str, Any]] = None) -> None:
        """Log a critical error message."""
        self.error_logger.critical(message)
        if details:
            self.log_activity("critical", {"message": message, **details}, status="error")
        else:
            self.log_activity("critical", {"message": message}, status="error")


# API monitoring decorator
def log_api_call(logger: DLLAnalyzerLogger):
    """
    Decorator for logging API calls with timing.
    
    Args:
        logger: The logger instance to use
    """
    def decorator(func):
        def wrapper(*args, **kwargs):
            start_time = time.time()
            
            # Format arguments for logging (handling objects)
            safe_args = {}
            for i, arg in enumerate(args):
                try:
                    # Try to represent the argument as a string or dict
                    if hasattr(arg, '__dict__'):
                        safe_args[f"arg{i}"] = str(arg)
                    else:
                        safe_args[f"arg{i}"] = arg
                except Exception:
                    safe_args[f"arg{i}"] = str(type(arg))
            
            # Add keyword arguments
            for k, v in kwargs.items():
                try:
                    if hasattr(v, '__dict__'):
                        safe_args[k] = str(v)
                    else:
                        safe_args[k] = v
                except Exception:
                    safe_args[k] = str(type(v))
            
            try:
                result = func(*args, **kwargs)
                duration = (time.time() - start_time) * 1000  # ms
                
                # Log the API call
                logger.log_api_call(
                    api_name=func.__name__,
                    arguments=safe_args,
                    return_value=result,
                    duration_ms=duration
                )
                return result
            except Exception as e:
                duration = (time.time() - start_time) * 1000  # ms
                logger.log_api_call(
                    api_name=func.__name__,
                    arguments=safe_args,
                    return_value=f"EXCEPTION: {str(e)}",
                    duration_ms=duration
                )
                raise  # Re-raise the exception
        return wrapper
    return decorator 