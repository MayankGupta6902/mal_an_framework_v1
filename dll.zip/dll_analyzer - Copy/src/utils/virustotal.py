"""
VirusTotal API integration for the DLL Analyzer framework
"""

import json
import os
import time
from pathlib import Path
from typing import Dict, Any, Optional, Union

import requests

from src.utils.logger import DLLAnalyzerLogger as Logger
from src.utils.exceptions import DLLAnalyzerError
from src.utils.file_utils import calculate_file_hash

# Default API URL
VT_API_URL = "https://www.virustotal.com/api/v3"

class VirusTotalError(DLLAnalyzerError):
    """Exception raised for VirusTotal API errors"""
    pass

class VirusTotalClient:
    """Client for VirusTotal API integration"""
    
    def __init__(self, api_key: Optional[str] = None, logger: Optional[Logger] = None):
        """
        Initialize the VirusTotal client
        
        Args:
            api_key: VirusTotal API key (if None, will look in environment variable VT_API_KEY)
            logger: Optional logger instance
        """
        self.logger = logger or Logger("VirusTotal")
        self.api_key = api_key or os.environ.get("VT_API_KEY")
        
        if not self.api_key:
            self.logger.warning("No VirusTotal API key provided. Set the VT_API_KEY environment variable.")
    
    def _make_request(self, endpoint: str, method: str = "GET", data: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        Make a request to the VirusTotal API
        
        Args:
            endpoint: API endpoint to call
            method: HTTP method to use
            data: Optional data to send with the request
            
        Returns:
            API response as dictionary
            
        Raises:
            VirusTotalError: If the API request fails
        """
        if not self.api_key:
            raise VirusTotalError("No VirusTotal API key available")
        
        url = f"{VT_API_URL}/{endpoint.lstrip('/')}"
        headers = {
            "x-apikey": self.api_key,
            "accept": "application/json",
        }
        
        try:
            if method.upper() == "GET":
                response = requests.get(url, headers=headers, params=data)
            elif method.upper() == "POST":
                response = requests.post(url, headers=headers, json=data)
            else:
                raise VirusTotalError(f"Unsupported HTTP method: {method}")
            
            # Check for API errors
            if response.status_code == 401:
                raise VirusTotalError("Invalid VirusTotal API key")
            elif response.status_code == 429:
                raise VirusTotalError("VirusTotal API request quota exceeded")
            elif response.status_code != 200:
                raise VirusTotalError(f"VirusTotal API error: {response.status_code} - {response.text}")
            
            # Parse response
            return response.json()
        
        except requests.RequestException as e:
            raise VirusTotalError(f"Request error: {str(e)}")
        except json.JSONDecodeError:
            raise VirusTotalError("Invalid JSON response from VirusTotal API")
    
    def get_file_report(self, file_hash: str) -> Dict[str, Any]:
        """
        Get a report for a file hash from VirusTotal
        
        Args:
            file_hash: SHA256, SHA1, or MD5 hash of the file
            
        Returns:
            Analysis report from VirusTotal
        """
        self.logger.info(f"Getting VirusTotal report for hash: {file_hash}")
        
        try:
            response = self._make_request(f"/files/{file_hash}")
            data = response.get("data", {})
            
            # Format the response
            attributes = data.get("attributes", {})
            stats = attributes.get("last_analysis_stats", {})
            
            detection_rate = f"{stats.get('malicious', 0)}/{sum(stats.values())}"
            
            result = {
                "resource": file_hash,
                "scan_date": attributes.get("last_analysis_date"),
                "detection_rate": detection_rate,
                "threat_name": self._extract_threat_name(attributes),
                "positives": stats.get("malicious", 0),
                "total": sum(stats.values()),
                "permalink": f"https://www.virustotal.com/gui/file/{file_hash}",
                "scan_results": attributes.get("last_analysis_results", {})
            }
            
            self.logger.info(f"VirusTotal detection rate: {detection_rate}")
            return result
            
        except VirusTotalError:
            raise
        except Exception as e:
            raise VirusTotalError(f"Error getting file report: {str(e)}")
    
    def _extract_threat_name(self, attributes: Dict[str, Any]) -> str:
        """Extract a common threat name from results"""
        results = attributes.get("last_analysis_results", {})
        names = []
        
        # Get all malicious detections
        for engine, result in results.items():
            if result.get("category") == "malicious" and result.get("result"):
                names.append(result.get("result"))
        
        if not names:
            return "Unknown"
            
        # Return the most common name
        from collections import Counter
        return Counter(names).most_common(1)[0][0]
    
    def scan_file(self, file_path: str) -> Dict[str, Any]:
        """
        Submit a file for analysis to VirusTotal
        
        Args:
            file_path: Path to the file to scan
            
        Returns:
            Submission response from VirusTotal
            
        Note: 
            This is a premium API feature and might not work with free API keys
        """
        self.logger.info(f"Submitting file for VirusTotal scanning: {file_path}")
        
        if not os.path.exists(file_path):
            raise VirusTotalError(f"File not found: {file_path}")
        
        if os.path.getsize(file_path) > 32 * 1024 * 1024:  # 32MB limit
            raise VirusTotalError("File size exceeds VirusTotal's 32MB limit")
        
        try:
            # Get upload URL
            response = self._make_request("/files/upload_url")
            upload_url = response.get("data", "")
            
            # Upload the file
            with open(file_path, "rb") as file:
                files = {"file": (os.path.basename(file_path), file)}
                headers = {"x-apikey": self.api_key}
                
                upload_response = requests.post(
                    upload_url, 
                    files=files,
                    headers=headers
                )
            
            if upload_response.status_code != 200:
                raise VirusTotalError(f"File upload failed: {upload_response.text}")
            
            result = upload_response.json()
            analysis_id = result.get("data", {}).get("id")
            
            return {
                "analysis_id": analysis_id,
                "status": "submitted",
                "permalink": f"https://www.virustotal.com/gui/file-analysis/{analysis_id}"
            }
            
        except requests.RequestException as e:
            raise VirusTotalError(f"Error uploading file: {str(e)}")
        except Exception as e:
            raise VirusTotalError(f"Error scanning file: {str(e)}")
    
    def get_analysis_status(self, analysis_id: str) -> Dict[str, Any]:
        """
        Get the status of an analysis
        
        Args:
            analysis_id: VirusTotal analysis ID
            
        Returns:
            Analysis status from VirusTotal
        """
        self.logger.info(f"Getting analysis status for: {analysis_id}")
        
        try:
            response = self._make_request(f"/analyses/{analysis_id}")
            data = response.get("data", {})
            attributes = data.get("attributes", {})
            
            return {
                "status": attributes.get("status"),
                "stats": attributes.get("stats", {}),
                "date": attributes.get("date"),
                "results": attributes.get("results", {})
            }
            
        except Exception as e:
            raise VirusTotalError(f"Error getting analysis status: {str(e)}")
    
    def check_file(self, file_path: str, wait_for_analysis: bool = False, timeout: int = 300) -> Dict[str, Any]:
        """
        Check a file against VirusTotal (get report or submit for analysis)
        
        Args:
            file_path: Path to the file to check
            wait_for_analysis: Whether to wait for analysis to complete
            timeout: Maximum time to wait for analysis in seconds
            
        Returns:
            VirusTotal report
        """
        # Calculate file hash
        file_hash = calculate_file_hash(file_path, ["sha256"])["sha256"]
        
        try:
            # Try to get existing report
            self.logger.info(f"Checking existing VirusTotal report for {file_path}")
            return self.get_file_report(file_hash)
        except VirusTotalError as e:
            if "not found" not in str(e).lower():
                raise
            
            # File not found in VT, submit for analysis if requested
            self.logger.info(f"No existing report found, submitting file for analysis")
            scan_result = self.scan_file(file_path)
            
            if not wait_for_analysis:
                return scan_result
            
            # Wait for analysis to complete
            analysis_id = scan_result.get("analysis_id")
            if not analysis_id:
                raise VirusTotalError("No analysis ID returned from submission")
            
            self.logger.info(f"Waiting for analysis to complete (max {timeout}s)")
            start_time = time.time()
            
            while time.time() - start_time < timeout:
                status = self.get_analysis_status(analysis_id)
                if status.get("status") == "completed":
                    self.logger.info("Analysis completed")
                    return self.get_file_report(file_hash)
                
                self.logger.info(f"Analysis in progress: {status.get('status')}")
                time.sleep(30)  # Wait 30 seconds between checks
            
            raise VirusTotalError("Analysis timed out")

def check_vt_integration():
    """
    Check if VirusTotal integration is available
    
    Returns:
        True if VirusTotal API key is set, False otherwise
    """
    return bool(os.environ.get("VT_API_KEY")) 