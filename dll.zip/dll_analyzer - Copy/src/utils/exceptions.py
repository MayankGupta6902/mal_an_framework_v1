"""
Custom exceptions for the DLL Analyzer framework.
Provides structured error handling with specific exception types.
"""

from typing import Dict, List, Optional, Any


class DLLAnalyzerException(Exception):
    """Base exception class for all DLL Analyzer exceptions."""
    
    def __init__(self, message: str, details: Optional[Dict[str, Any]] = None):
        """
        Initialize the exception.
        
        Args:
            message: Error message
            details: Additional error details as a dictionary
        """
        self.message = message
        self.details = details or {}
        super().__init__(self.message)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert the exception to a dictionary for JSON serialization."""
        return {
            "error_type": self.__class__.__name__,
            "message": self.message,
            "details": self.details
        }


# Base exception
class DLLAnalyzerError(DLLAnalyzerException):
    """Base error class for all DLL Analyzer errors."""
    pass


# Validation errors
class ValidationError(DLLAnalyzerError):
    """Error raised during DLL validation."""
    pass


class NotDLLError(ValidationError):
    """Error raised when a file is not a valid DLL."""
    pass


class PEParsingError(ValidationError):
    """Error raised when PE parsing fails."""
    pass


class CorruptHeadersError(PEParsingError):
    """Error raised when PE headers are corrupt."""
    pass


# Invocation errors
class InvocationError(DLLAnalyzerError):
    """Error raised during DLL function invocation."""
    pass


class LoadLibraryError(InvocationError):
    """Error raised when loading a DLL fails."""
    pass


class ExportNotFoundError(InvocationError):
    """Error raised when a requested export function is not found."""
    pass


class FunctionCallError(InvocationError):
    """Error raised when calling a function fails."""
    pass


# Monitoring errors
class MonitoringError(DLLAnalyzerError):
    """Error raised during DLL execution monitoring."""
    pass


class ProcmonError(MonitoringError):
    """Error raised when Process Monitor operation fails."""
    pass


class FridaError(MonitoringError):
    """Error raised when Frida operation fails."""
    pass


class MissingToolError(DLLAnalyzerError):
    """Error raised when a required external tool is missing."""
    pass


# IOC analysis errors
class IOCExtractionError(DLLAnalyzerError):
    """Error raised during IOC extraction and analysis."""
    pass


class ConfigurationError(DLLAnalyzerException):
    """Exception raised when there's a configuration issue."""
    pass


class PermissionError(DLLAnalyzerException):
    """Exception raised when permission is denied for an operation."""
    pass 