"""
Report Visualizer - Generate HTML reports from DLL analysis results
"""

import json
import os
from pathlib import Path
from typing import Dict, Any, Optional
from datetime import datetime

from src.utils.logger import DLLAnalyzerLogger as Logger

logger = Logger("ReportVisualizer")

class ReportVisualizer:
    """Generate visual HTML reports from DLL analysis results"""
    
    def __init__(self, report_path: Path, ioc_report_path: Optional[Path] = None):
        """
        Initialize the report visualizer
        
        Args:
            report_path: Path to the JSON report file
            ioc_report_path: Optional path to the IOC report file
        """
        self.report_path = Path(report_path)
        self.ioc_report_path = Path(ioc_report_path) if ioc_report_path else None
        self.report_data = self._load_report(self.report_path)
        self.ioc_data = self._load_report(self.ioc_report_path) if self.ioc_report_path else {}
        
    def _load_report(self, report_path: Path) -> Dict[str, Any]:
        """Load a JSON report file"""
        try:
            with open(report_path, "r") as f:
                return json.load(f)
        except Exception as e:
            logger.error(f"Failed to load report from {report_path}: {str(e)}")
            return {}
    
    def generate_html_report(self, output_path: Optional[Path] = None) -> Path:
        """
        Generate an HTML report from the analysis results
        
        Args:
            output_path: Optional path to save the HTML report. If None, uses default naming.
            
        Returns:
            Path to the generated HTML report
        """
        if not output_path:
            output_path = self.report_path.parent / "report.html"
        
        # Generate the HTML content
        html_content = self._generate_html()
        
        # Save the HTML report
        with open(output_path, "w", encoding="utf-8") as f:
            f.write(html_content)
        
        logger.info(f"HTML report generated at {output_path}")
        return output_path
    
    def _generate_html(self) -> str:
        """Generate the HTML content for the report"""
        # Extract data for the report
        dll_info = self.report_data.get("dll_info", {})
        timestamp = self.report_data.get("analysis_timestamp", datetime.now().strftime("%Y%m%d_%H%M%S"))
        execution_time = self.report_data.get("execution_time_seconds", 0)
        
        # Get IOC summary
        ioc_summary = self.report_data.get("ioc_summary", {})
        risk_score = ioc_summary.get("risk_score", 0)
        risk_level = ioc_summary.get("risk_level", "Unknown")
        recommendation = ioc_summary.get("recommendation", "")
        
        # Determine risk color
        risk_color = self._get_risk_color(risk_level)
        
        # Generate HTML
        html = f"""
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>DLL Analysis Report - {dll_info.get("name", "Unknown")}</title>
            <style>
                body {{
                    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                    line-height: 1.6;
                    color: #333;
                    margin: 0;
                    padding: 0;
                    background-color: #f5f5f5;
                }}
                .container {{
                    max-width: 1200px;
                    margin: 0 auto;
                    padding: 20px;
                }}
                .header {{
                    background-color: #2c3e50;
                    color: white;
                    padding: 20px;
                    border-radius: 5px 5px 0 0;
                }}
                .content {{
                    background-color: white;
                    padding: 20px;
                    border-radius: 0 0 5px 5px;
                    box-shadow: 0 2px 5px rgba(0,0,0,0.1);
                }}
                .section {{
                    margin-bottom: 30px;
                    border-bottom: 1px solid #eee;
                    padding-bottom: 20px;
                }}
                .section:last-child {{
                    border-bottom: none;
                }}
                h1, h2, h3 {{
                    margin-top: 0;
                }}
                table {{
                    width: 100%;
                    border-collapse: collapse;
                    margin-bottom: 20px;
                }}
                th, td {{
                    padding: 12px 15px;
                    text-align: left;
                    border-bottom: 1px solid #ddd;
                }}
                th {{
                    background-color: #f8f9fa;
                }}
                .risk-indicator {{
                    display: inline-block;
                    padding: 8px 16px;
                    border-radius: 4px;
                    font-weight: bold;
                    color: white;
                    background-color: {risk_color};
                }}
                .detail-table {{
                    margin-top: 10px;
                    font-size: 14px;
                }}
                .detail-table th {{
                    font-size: 12px;
                }}
                .chart-container {{
                    height: 300px;
                    margin: 20px 0;
                }}
                pre {{
                    background-color: #f8f9fa;
                    padding: 15px;
                    border-radius: 5px;
                    overflow-x: auto;
                    font-family: 'Consolas', 'Courier New', monospace;
                }}
                .footer {{
                    text-align: center;
                    margin-top: 30px;
                    font-size: 12px;
                    color: #777;
                }}
            </style>
            <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
        </head>
        <body>
            <div class="container">
                <div class="header">
                    <h1>DLL Analysis Report</h1>
                    <p>Analysis performed on {timestamp}</p>
                </div>
                
                <div class="content">
                    <div class="section">
                        <h2>Summary</h2>
                        <table>
                            <tr>
                                <td><strong>DLL Name:</strong></td>
                                <td>{dll_info.get("name", "Unknown")}</td>
                            </tr>
                            <tr>
                                <td><strong>Path:</strong></td>
                                <td>{dll_info.get("path", "Unknown")}</td>
                            </tr>
                            <tr>
                                <td><strong>Size:</strong></td>
                                <td>{dll_info.get("size", 0)} bytes</td>
                            </tr>
                            <tr>
                                <td><strong>MD5:</strong></td>
                                <td>{dll_info.get("md5", "Unknown")}</td>
                            </tr>
                            <tr>
                                <td><strong>SHA256:</strong></td>
                                <td>{dll_info.get("sha256", "Unknown")}</td>
                            </tr>
                            <tr>
                                <td><strong>Analysis Duration:</strong></td>
                                <td>{execution_time:.2f} seconds</td>
                            </tr>
                        </table>
                    </div>
                    
                    <div class="section">
                        <h2>Risk Assessment</h2>
                        <div style="display: flex; align-items: center; margin-bottom: 20px;">
                            <div class="risk-indicator">{risk_level}</div>
                            <div style="margin-left: 20px; flex-grow: 1;">
                                <div style="font-size: 18px; font-weight: bold;">Risk Score: {risk_score}/100</div>
                                <div>{recommendation}</div>
                            </div>
                        </div>
                        
                        <div class="chart-container">
                            <canvas id="riskChart"></canvas>
                        </div>
                        
                        <script>
                            const ctx = document.getElementById('riskChart');
                            new Chart(ctx, {{
                                type: 'doughnut',
                                data: {{
                                    labels: ['Risk Score', 'Safe'],
                                    datasets: [{{
                                        data: [{risk_score}, {100 - risk_score}],
                                        backgroundColor: ['{risk_color}', '#e0e0e0'],
                                        borderWidth: 0
                                    }}]
                                }},
                                options: {{
                                    cutout: '70%',
                                    plugins: {{
                                        legend: {{
                                            display: false
                                        }},
                                        tooltip: {{
                                            callbacks: {{
                                                label: function(context) {{
                                                    return context.label + ': ' + context.raw + '%';
                                                }}
                                            }}
                                        }}
                                    }}
                                }}
                            }});
                        </script>
                    </div>
                    
                    {self._generate_ioc_section()}
                    
                    {self._generate_behavior_section()}
                    
                    {self._generate_structure_section()}
                    
                </div>
                
                <div class="footer">
                    <p>Generated by DLL Analyzer Framework</p>
                </div>
            </div>
        </body>
        </html>
        """
        
        return html
    
    def _generate_ioc_section(self) -> str:
        """Generate the IOC section of the HTML report"""
        if not self.ioc_data:
            return ""
            
        suspicious_imports = self.ioc_data.get("suspicious_imports", [])
        suspicious_strings = self.ioc_data.get("suspicious_strings", [])
        suspicious_sections = self.ioc_data.get("suspicious_sections", [])
        
        # Generate imports table
        imports_table = ""
        if suspicious_imports:
            imports_table = """
            <h3>Suspicious Imports</h3>
            <table class="detail-table">
                <tr>
                    <th>Name</th>
                    <th>Library</th>
                    <th>Risk Score</th>
                    <th>Reason</th>
                </tr>
            """
            
            for imp in suspicious_imports:
                imports_table += f"""
                <tr>
                    <td>{imp.get("name", "Unknown")}</td>
                    <td>{imp.get("library", "Unknown")}</td>
                    <td>{imp.get("risk_score", 0)}/10</td>
                    <td>{imp.get("reason", "Unknown")}</td>
                </tr>
                """
            
            imports_table += "</table>"
        
        # Generate strings table
        strings_table = ""
        if suspicious_strings:
            strings_table = """
            <h3>Suspicious Strings</h3>
            <table class="detail-table">
                <tr>
                    <th>String</th>
                    <th>Matched Pattern</th>
                    <th>Risk Score</th>
                    <th>Reason</th>
                </tr>
            """
            
            for string in suspicious_strings:
                strings_table += f"""
                <tr>
                    <td>{string.get("string", "Unknown")}</td>
                    <td>{string.get("matched_pattern", "N/A")}</td>
                    <td>{string.get("risk_score", 0)}/10</td>
                    <td>{string.get("reason", "Unknown")}</td>
                </tr>
                """
            
            strings_table += "</table>"
        
        # Generate sections table
        sections_table = ""
        if suspicious_sections:
            sections_table = """
            <h3>Suspicious Sections</h3>
            <table class="detail-table">
                <tr>
                    <th>Name</th>
                    <th>Entropy</th>
                    <th>Risk Score</th>
                    <th>Reason</th>
                </tr>
            """
            
            for section in suspicious_sections:
                sections_table += f"""
                <tr>
                    <td>{section.get("name", "Unknown")}</td>
                    <td>{section.get("entropy", "N/A")}</td>
                    <td>{section.get("risk_score", 0)}/10</td>
                    <td>{section.get("reason", "Unknown")}</td>
                </tr>
                """
            
            sections_table += "</table>"
        
        # Combine all tables
        return f"""
        <div class="section">
            <h2>Indicators of Compromise</h2>
            {imports_table}
            {strings_table}
            {sections_table}
        </div>
        """
    
    def _generate_behavior_section(self) -> str:
        """Generate the behavior section of the HTML report"""
        if not self.ioc_data or "suspicious_behavior" not in self.ioc_data:
            return ""
            
        behavior = self.ioc_data.get("suspicious_behavior", {})
        
        # Categories to display
        categories = [
            ("file_operations", "File Operations"),
            ("registry_operations", "Registry Operations"),
            ("network_operations", "Network Operations"),
            ("process_operations", "Process Operations"),
            ("crypto_operations", "Cryptographic Operations")
        ]
        
        # Generate behavior tables
        behavior_html = ""
        
        for key, title in categories:
            if key in behavior and behavior[key]:
                behavior_html += f"""
                <h3>{title}</h3>
                <table class="detail-table">
                    <tr>
                        <th>Operation</th>
                        <th>Path/Details</th>
                        <th>Risk Score</th>
                        <th>Reason</th>
                    </tr>
                """
                
                for op in behavior[key]:
                    # Get the appropriate field based on operation type
                    if "api" in op:
                        operation = op.get("api", "Unknown")
                    else:
                        operation = op.get("operation", "Unknown")
                    
                    # Get path or details
                    if "path" in op:
                        details = op.get("path", "Unknown")
                    elif "host" in op:
                        details = op.get("host", "Unknown")
                    elif "command" in op:
                        details = op.get("command", "Unknown")
                    else:
                        details = "N/A"
                    
                    behavior_html += f"""
                    <tr>
                        <td>{operation}</td>
                        <td>{details}</td>
                        <td>{op.get("risk_score", 0)}/10</td>
                        <td>{op.get("reason", "Unknown")}</td>
                    </tr>
                    """
                
                behavior_html += "</table>"
        
        if not behavior_html:
            return ""
            
        return f"""
        <div class="section">
            <h2>Suspicious Behavior</h2>
            {behavior_html}
        </div>
        """
    
    def _generate_structure_section(self) -> str:
        """Generate the structure section of the HTML report"""
        if "results" not in self.report_data or "structure_analysis" not in self.report_data["results"]:
            return ""
            
        structure = self.report_data["results"]["structure_analysis"]
        
        # Extract PE headers
        headers = structure.get("headers", {})
        characteristics = headers.get("characteristics", [])
        
        # Extract sections
        sections = structure.get("sections", [])
        
        # Extract exports
        exports = structure.get("exports", [])
        
        # Generate headers section
        headers_html = f"""
        <h3>PE Headers</h3>
        <table>
            <tr>
                <td><strong>Machine:</strong></td>
                <td>{headers.get("machine", "Unknown")}</td>
            </tr>
            <tr>
                <td><strong>Timestamp:</strong></td>
                <td>{headers.get("timestamp", "Unknown")}</td>
            </tr>
            <tr>
                <td><strong>Characteristics:</strong></td>
                <td>{", ".join(characteristics)}</td>
            </tr>
            <tr>
                <td><strong>Subsystem:</strong></td>
                <td>{headers.get("subsystem", "Unknown")}</td>
            </tr>
        </table>
        """
        
        # Generate sections table
        sections_html = ""
        if sections:
            sections_html = """
            <h3>Sections</h3>
            <table class="detail-table">
                <tr>
                    <th>Name</th>
                    <th>Virtual Size</th>
                    <th>Virtual Address</th>
                    <th>Raw Size</th>
                    <th>Entropy</th>
                    <th>Characteristics</th>
                </tr>
            """
            
            for section in sections:
                sections_html += f"""
                <tr>
                    <td>{section.get("name", "Unknown")}</td>
                    <td>{section.get("virtual_size", 0)}</td>
                    <td>0x{section.get("virtual_address", 0):08x}</td>
                    <td>{section.get("raw_size", 0)}</td>
                    <td>{section.get("entropy", 0):.2f}</td>
                    <td>{", ".join(section.get("characteristics", []))}</td>
                </tr>
                """
            
            sections_html += "</table>"
        
        # Generate exports table
        exports_html = ""
        if exports:
            exports_html = """
            <h3>Exported Functions</h3>
            <table class="detail-table">
                <tr>
                    <th>Name</th>
                    <th>Ordinal</th>
                    <th>Address</th>
                </tr>
            """
            
            for export in exports:
                exports_html += f"""
                <tr>
                    <td>{export.get("name", "Unknown")}</td>
                    <td>{export.get("ordinal", 0)}</td>
                    <td>0x{export.get("address", 0):08x}</td>
                </tr>
                """
            
            exports_html += "</table>"
        
        return f"""
        <div class="section">
            <h2>DLL Structure</h2>
            {headers_html}
            {sections_html}
            {exports_html}
        </div>
        """
    
    def _get_risk_color(self, risk_level: str) -> str:
        """Get the color associated with a risk level"""
        colors = {
            "Critical": "#d9534f",  # Red
            "High": "#f0ad4e",      # Orange
            "Medium": "#ffd700",    # Yellow
            "Low": "#5cb85c",       # Green
            "Unknown": "#5bc0de"    # Blue
        }
        
        return colors.get(risk_level, "#5bc0de") 