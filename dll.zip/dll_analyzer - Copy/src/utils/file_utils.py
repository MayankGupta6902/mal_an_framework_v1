"""
File utility functions for the DLL Analyzer framework.
Provides helpers for file operations, path handling, and hash calculations.
"""

import hashlib
import os
import shutil
import subprocess
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Set, Tuple

from src.utils.exceptions import ConfigurationError, PermissionError


def calculate_file_hash(file_path: str, algorithms: List[str] = None) -> Dict[str, str]:
    """
    Calculate hash values for a file using specified algorithms.
    
    Args:
        file_path: Path to the file to hash
        algorithms: List of algorithms to use (md5, sha1, sha256)
        
    Returns:
        Dictionary mapping algorithm names to hash values
    """
    if algorithms is None:
        algorithms = ['md5', 'sha1', 'sha256']
    
    result = {}
    
    for algorithm in algorithms:
        try:
            hash_obj = hashlib.new(algorithm)
            with open(file_path, 'rb') as f:
                # Read in chunks to handle large files efficiently
                for chunk in iter(lambda: f.read(4096), b''):
                    hash_obj.update(chunk)
            result[algorithm] = hash_obj.hexdigest()
        except Exception as e:
            result[algorithm] = f"ERROR: {str(e)}"
    
    return result


def ensure_directory(directory_path: str) -> None:
    """
    Ensure a directory exists, creating it if necessary.
    
    Args:
        directory_path: Path to the directory
        
    Raises:
        PermissionError: If directory creation fails due to permissions
    """
    try:
        os.makedirs(directory_path, exist_ok=True)
    except OSError as e:
        raise PermissionError(
            f"Failed to create directory '{directory_path}'",
            {"os_error": str(e)}
        )


def get_file_metadata(file_path: str) -> Dict[str, str]:
    """
    Get metadata for a file.
    
    Args:
        file_path: Path to the file
        
    Returns:
        Dictionary with file metadata
    """
    file_path = Path(file_path)
    stat = file_path.stat()
    
    return {
        "name": file_path.name,
        "path": str(file_path.absolute()),
        "size": stat.st_size,
        "created": datetime.fromtimestamp(stat.st_ctime).isoformat(),
        "modified": datetime.fromtimestamp(stat.st_mtime).isoformat(),
        "accessed": datetime.fromtimestamp(stat.st_atime).isoformat(),
    }


def is_tool_available(tool_name: str) -> bool:
    """
    Check if a tool is available on the system PATH.
    
    Args:
        tool_name: Name of the tool binary
        
    Returns:
        True if tool is available, False otherwise
    """
    try:
        devnull = open(os.devnull, 'w')
        subprocess.check_call([tool_name, "--help"], stdout=devnull, stderr=devnull)
        return True
    except (FileNotFoundError, subprocess.SubprocessError):
        # In tools directory?
        tools_dir = Path("tools")
        if (tools_dir / tool_name).exists():
            return True
        if (tools_dir / tool_name).with_suffix('.exe').exists():
            return True
        return False
    finally:
        devnull.close()


def find_tool(tool_name: str) -> Optional[str]:
    """
    Find the path to a tool.
    
    Args:
        tool_name: Name of the tool binary
        
    Returns:
        Path to the tool if found, None otherwise
    """
    # Check for executable in system PATH
    try:
        result = shutil.which(tool_name)
        if result:
            return result
    except Exception:
        pass
    
    # Check in tools directory
    tools_dir = Path("tools")
    tool_path = tools_dir / tool_name
    if tool_path.exists():
        return str(tool_path)
    
    # Check with .exe extension
    tool_path_exe = tool_path.with_suffix('.exe')
    if tool_path_exe.exists():
        return str(tool_path_exe)
    
    # Check subdirectories
    for subdir in tools_dir.iterdir():
        if not subdir.is_dir():
            continue
        
        tool_path = subdir / tool_name
        if tool_path.exists():
            return str(tool_path)
        
        tool_path_exe = tool_path.with_suffix('.exe')
        if tool_path_exe.exists():
            return str(tool_path_exe)
    
    return None


def check_required_tools(tool_names: List[str]) -> Dict[str, bool]:
    """
    Check if required tools are available.
    
    Args:
        tool_names: List of tool names to check
        
    Returns:
        Dictionary mapping tool names to availability
    """
    result = {}
    
    for tool_name in tool_names:
        result[tool_name] = is_tool_available(tool_name)
    
    return result


def copy_file_safe(source: str, destination: str) -> bool:
    """
    Safely copy a file with error handling.
    
    Args:
        source: Source file path
        destination: Destination file path
        
    Returns:
        True if successful, False otherwise
    """
    try:
        ensure_directory(os.path.dirname(destination))
        shutil.copy2(source, destination)
        return True
    except Exception:
        return False


def safe_filename(filename: str) -> str:
    """
    Create a safe filename by replacing invalid characters.
    
    Args:
        filename: Original filename
        
    Returns:
        Safe filename
    """
    # Replace invalid filename characters
    invalid_chars = '<>:"/\\|?*'
    for char in invalid_chars:
        filename = filename.replace(char, '_')
    
    # Limit length
    if len(filename) > 255:
        base, ext = os.path.splitext(filename)
        filename = base[:255-len(ext)] + ext
        
    return filename 