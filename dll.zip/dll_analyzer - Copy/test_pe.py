import pefile

# Load the DLL
pe = pefile.PE('C:\\Windows\\System32\\kernel32.dll')

# Parse directories to make sure exports are loaded
pe.parse_data_directories()

# Check for exports
if hasattr(pe, 'DIRECTORY_ENTRY_EXPORT'):
    print(f"Found {len(pe.DIRECTORY_ENTRY_EXPORT.symbols)} exports")
    
    # Print the first 10 exports
    for i, exp in enumerate(pe.DIRECTORY_ENTRY_EXPORT.symbols[:10]):
        print(f"{i+1}. {exp.name.decode() if exp.name else 'Anonymous'} (Ordinal: {exp.ordinal})")
else:
    print("No exports found") 