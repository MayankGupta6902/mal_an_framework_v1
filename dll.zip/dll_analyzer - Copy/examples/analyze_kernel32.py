#!/usr/bin/env python3
"""
Example script that demonstrates how to use the DLL Analyzer framework
to analyze kernel32.dll
"""

import os
import sys
import time
from pathlib import Path

# Add parent directory to path so we can import from the src package
sys.path.insert(0, str(Path(__file__).parent.parent))

from src.core.dll_validator import DLLValidator
from src.core.ioc_extractor import IOCExtractor
from src.loaders.invocation_engine import InvocationEngine
from src.utils.logger import DLLAnalyzerLogger as Logger
from src.utils.report_visualizer import ReportVisualizer

# Initialize logger
logger = Logger("Example", log_to_file=True)

def main():
    # Path to kernel32.dll - usually found in System32 directory
    kernel32_path = os.path.join(os.environ.get("SystemRoot", "C:\\Windows"), "System32", "kernel32.dll")
    
    if not os.path.exists(kernel32_path):
        logger.error(f"Could not find kernel32.dll at {kernel32_path}")
        return
    
    logger.info(f"Analyzing kernel32.dll from {kernel32_path}")
    
    # Create output directory
    output_dir = Path("output") / "kernel32_example"
    os.makedirs(output_dir, exist_ok=True)
    
    # 1. Analyze DLL structure
    logger.info("Step 1: Analyzing DLL structure")
    validator = DLLValidator(logger)
    structure_results = validator.validate(kernel32_path)
    
    # 2. List exports and find an interesting function
    logger.info("Step 2: Listing DLL exports")
    invocation_engine = InvocationEngine(logger)
    exports = invocation_engine.list_exports(kernel32_path)
    
    # Print the first 5 exports
    logger.info(f"Found {len(exports)} exports. First 5:")
    for i, export in enumerate(exports[:5]):
        logger.info(f"  - {export.get('name', 'Unknown')}")
    
    # 3. Try to invoke a simple function like GetVersion
    logger.info("Step 3: Invoking GetVersion function")
    try:
        result = invocation_engine.invoke_function_ctypes(kernel32_path, "GetVersion", [])
        logger.info(f"GetVersion result: {result}")
    except Exception as e:
        logger.error(f"Failed to invoke GetVersion: {str(e)}")
    
    # 4. Prepare analysis results for reporting
    results = {
        "structure_analysis": structure_results,
        "exports_count": len(exports),
        "invocation_results": {
            "GetVersion": str(result) if 'result' in locals() else "Failed"
        }
    }
    
    # 5. Generate reports
    report_path = output_dir / "report.json"
    ioc_path = output_dir / "ioc_report.json"
    
    # Save basic report
    with open(report_path, "w") as f:
        import json
        json.dump({
            "analysis_timestamp": time.strftime("%Y%m%d_%H%M%S"),
            "dll_info": {
                "name": "kernel32.dll",
                "path": kernel32_path,
                "size": os.path.getsize(kernel32_path)
            },
            "results": results
        }, f, indent=2)
    
    # Extract IoCs
    ioc_extractor = IOCExtractor(results, kernel32_path)
    iocs = ioc_extractor.extract_iocs()
    ioc_extractor.save_to_file(ioc_path)
    
    # 6. Generate HTML report
    visualizer = ReportVisualizer(report_path, ioc_path)
    html_path = visualizer.generate_html_report()
    
    logger.info(f"Analysis complete. Reports saved to {output_dir}")
    logger.info(f"HTML report: {html_path}")

if __name__ == "__main__":
    main() 