#!/usr/bin/env python3
"""
DLL Analyzer - Main entry point for the DLL analysis framework
"""

import os
import sys
import time
import click
import json
import subprocess
from datetime import datetime
from pathlib import Path

from src.utils.logger import DLLAnalyzerLogger as Logger
from src.utils.exceptions import DLLAnalyzerError, ValidationError
from src.utils.file_utils import calculate_file_hash
from src.utils.report_visualizer import ReportVisualizer
from src.utils.virustotal import VirusTotalClient, check_vt_integration
from src.core.dll_validator import DLLValidator
from src.core.ioc_extractor import IOCExtractor
from src.loaders.invocation_engine import InvocationEngine
from src.monitors.procmon_monitor import ProcmonMonitor
from src.monitors.frida_monitor import FridaMonitor

import config

# Initialize logger
logger = Logger("DLLAnalyzer", log_to_file=True)

def setup_environment(dll_path, output_dir=None):
    """Set up the analysis environment and output directories"""
    dll_path = Path(dll_path).resolve()
    dll_name = dll_path.stem
    
    if not output_dir:
        output_dir = Path("output") / dll_name
    else:
        output_dir = Path(output_dir)
    
    # Create output directories
    os.makedirs(output_dir, exist_ok=True)
    os.makedirs(output_dir / "artifacts", exist_ok=True)
    
    return {
        "dll_path": dll_path,
        "dll_name": dll_name,
        "output_dir": output_dir,
        "timestamp": datetime.now().strftime("%Y%m%d_%H%M%S"),
    }

def generate_report(env, results, execution_time):
    """Generate a summary report of the analysis"""
    # Extract IOCs from results
    ioc_extractor = IOCExtractor(results, env["dll_path"])
    iocs = ioc_extractor.extract_iocs()
    ioc_report_path = ioc_extractor.save_to_file(env["output_dir"] / "ioc_report.json")
    
    report = {
        "analysis_timestamp": env["timestamp"],
        "dll_info": {
            "name": env["dll_name"],
            "path": str(env["dll_path"]),
            "size": os.path.getsize(env["dll_path"]),
            "md5": calculate_file_hash(env["dll_path"], "md5"),
            "sha256": calculate_file_hash(env["dll_path"], "sha256"),
        },
        "execution_time_seconds": execution_time,
        "results": results,
        "ioc_summary": {
            "risk_score": iocs["overall_risk_score"],
            "risk_level": iocs["risk_assessment"]["risk_level"],
            "recommendation": iocs["risk_assessment"]["recommendation"],
            "suspicious_imports_count": len(iocs["suspicious_imports"]),
            "suspicious_strings_count": len(iocs["suspicious_strings"]),
            "suspicious_behaviors_count": sum(len(iocs["suspicious_behavior"][category]) 
                                             for category in iocs["suspicious_behavior"]),
        }
    }
    
    report_path = env["output_dir"] / "report.json"
    with open(report_path, "w") as f:
        json.dump(report, f, indent=2)
    
    logger.info(f"Analysis report saved to {report_path}")
    logger.info(f"IOC report saved to {ioc_report_path}")
    
    return report_path

def analyze_structure(dll_path):
    """Analyze the DLL structure using DLLValidator"""
    logger.info(f"Analyzing structure of {dll_path}")
    validator = DLLValidator(logger)
    return validator.validate(dll_path)

def invoke_function(dll_path, function_name=None, timeout=60):
    """Invoke a specific function or DllMain"""
    logger.info(f"Invoking {'DllMain' if not function_name else function_name} from {dll_path}")
    engine = InvocationEngine(logger)
    
    if function_name:
        # Use ctypes invocation with default parameter types
        return engine.invoke_function_ctypes(dll_path, function_name, timeout=timeout)
    else:
        return engine.invoke_dllmain(dll_path, timeout=timeout)

def monitor_execution(dll_path, function_name=None, timeout=60):
    """Monitor the execution of a DLL using available monitors"""
    results = {}
    output_dir = Path("output") / Path(dll_path).stem
    
    # Start Procmon monitoring
    procmon = ProcmonMonitor(output_dir=output_dir, logger=logger)
    procmon.start_monitoring()
    
    # Start Frida monitoring
    frida = FridaMonitor(output_dir=output_dir, logger=logger)
    
    try:
        # Use rundll32 for invocation
        cmd = ["rundll32.exe", str(dll_path)]
        if function_name:
            cmd.append(function_name)
        
        # Record the process ID for Frida monitoring
        process = subprocess.Popen(cmd)
        process_id = process.pid
        
        # Attach Frida to the process
        try:
            frida_session = frida.attach_to_process(process_id)
        except Exception as e:
            logger.warning(f"Failed to attach Frida: {str(e)}")
        
        # Wait for the specified timeout
        logger.info(f"Monitoring for {timeout} seconds")
        time.sleep(timeout)
        
        # Allow some time for monitors to capture post-execution activity
        process.terminate()
        time.sleep(2)
    finally:
        # Stop monitoring and collect results
        results["procmon"] = procmon.monitor_dll_execution(1)  # Just retrieve results
        
        # Get Frida results
        results["frida"] = {
            "api_calls": frida.api_calls,
            "dll_loads": frida.dll_loads
        }
        
        # Extract IOCs from monitoring
        results["iocs"] = frida.extract_ioc_from_calls()
    
    return results

@click.command()
@click.option("--input", "-i", required=True, help="Path to the DLL file to analyze")
@click.option("--mode", "-m", default="full", 
              type=click.Choice(["full", "ftn", "structure", "monitor"]),
              help="Analysis mode")
@click.option("--function", "-f", help="When using ftn mode, specify the export function name")
@click.option("--output", "-o", help="Custom output directory")
@click.option("--timeout", "-t", default=60, help="Maximum execution time in seconds")
@click.option("--verbose", "-v", is_flag=True, help="Enable detailed console output")
@click.option("--html", "-h", is_flag=True, help="Generate HTML report")
@click.option("--report-only", "-r", is_flag=True, help="Generate report from existing results without running analysis")
@click.option("--virustotal", "-vt", is_flag=True, help="Check file against VirusTotal")
def main(input, mode, function, output, timeout, verbose, html, report_only, virustotal):
    """DLL Analyzer - Analyze DLL files for behavior and potential malicious indicators"""
    start_time = time.time()
    results = {}
    
    if verbose:
        logger.set_console_level("DEBUG")
    
    try:
        # Validate input file
        if not os.path.exists(input):
            logger.error(f"Input file not found: {input}")
            sys.exit(1)
            
        # Setup environment
        env = setup_environment(input, output)
        
        if report_only:
            # Load existing results instead of running analysis
            report_json_path = env['output_dir'] / 'report.json'
            ioc_json_path = env['output_dir'] / 'ioc_report.json'
            
            if not report_json_path.exists():
                logger.error(f"Report file not found at {report_json_path}")
                sys.exit(1)
                
            logger.info(f"Loading existing results from {report_json_path}")
            with open(report_json_path, 'r') as f:
                report_data = json.load(f)
                results = report_data.get('results', {})
        else:
            # Run the analysis
            logger.info(f"Analyzing {env['dll_path']} in {mode} mode")
            
            # Perform analysis based on mode
            if mode in ["full", "structure"]:
                results["structure_analysis"] = analyze_structure(env["dll_path"])
                
            if mode in ["full", "ftn"]:
                if function:
                    results["function_invocation"] = invoke_function(env["dll_path"], function, timeout)
                else:
                    results["dllmain_invocation"] = invoke_function(env["dll_path"], None, timeout)
                    
            if mode in ["full", "monitor"]:
                results["monitoring"] = monitor_execution(env["dll_path"], function, timeout)
            
            # Generate JSON report
            execution_time = time.time() - start_time
            report_path = generate_report(env, results, execution_time)
            
            logger.info(f"Analysis completed in {execution_time:.2f} seconds")
            logger.info(f"Report available at: {report_path}")
        
        # Check VirusTotal if requested
        if virustotal:
            if check_vt_integration():
                logger.info("Checking file against VirusTotal")
                vt_client = VirusTotalClient(logger=logger)
                try:
                    vt_results = vt_client.check_file(str(env["dll_path"]))
                    
                    # Save VirusTotal results
                    vt_output_path = env["output_dir"] / "virustotal_report.json"
                    with open(vt_output_path, "w") as f:
                        json.dump(vt_results, f, indent=2)
                    
                    logger.info(f"VirusTotal detection: {vt_results['detection_rate']}")
                    logger.info(f"VirusTotal report: {vt_results['permalink']}")
                    
                    # Add to main report
                    with open(env["output_dir"] / "report.json", "r") as f:
                        report_data = json.load(f)
                    
                    report_data["virustotal"] = {
                        "detection_rate": vt_results["detection_rate"],
                        "threat_name": vt_results["threat_name"],
                        "permalink": vt_results["permalink"],
                    }
                    
                    # Update the report file
                    with open(env["output_dir"] / "report.json", "w") as f:
                        json.dump(report_data, f, indent=2)
                        
                except Exception as e:
                    logger.error(f"VirusTotal check failed: {str(e)}")
            else:
                logger.warning("VirusTotal API key not found. Set VT_API_KEY environment variable.")
        
        # Generate HTML report if requested
        if html:
            logger.info("Generating HTML report")
            report_json_path = env['output_dir'] / 'report.json'
            ioc_json_path = env['output_dir'] / 'ioc_report.json'
            
            visualizer = ReportVisualizer(report_json_path, ioc_json_path)
            html_path = visualizer.generate_html_report()
            
            logger.info(f"HTML report generated at: {html_path}")
            
    except ValidationError as e:
        logger.error(f"Validation error: {str(e)}")
        sys.exit(1)
    except DLLAnalyzerError as e:
        logger.error(f"Analysis error: {str(e)}")
        sys.exit(1)
    except Exception as e:
        logger.error(f"Unexpected error: {str(e)}", exc_info=True)
        sys.exit(1)

if __name__ == "__main__":
    main() 