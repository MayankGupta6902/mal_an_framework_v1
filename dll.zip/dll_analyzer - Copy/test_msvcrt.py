#!/usr/bin/env python3
"""
DLL Export Analyzer
Tests all exported functions in any DLL using multiple invocation methods.
Logs results, errors, and runtime behavior in a structured format.
"""

import os
import sys
import time
import json
import ctypes
import logging
import subprocess
from pathlib import Path
from typing import Dict, List, Any, Optional, Tuple

from src.utils.logger import DLLAnalyzerLogger
from src.core.dll_validator import DLLValidator
from src.loaders.invocation_engine import InvocationEngine
from src.monitors.procmon_monitor import ProcmonMonitor
from src.utils.exceptions import DLLAnalyzerError, InvocationError, ExportNotFoundError

# Configure paths
OUTPUT_DIR = Path("output/dll_analysis")
LOGS_DIR = Path("logs")

# Configure logging
os.makedirs(LOGS_DIR, exist_ok=True)
os.makedirs(OUTPUT_DIR, exist_ok=True)

# Create loggers
logger = DLLAnalyzerLogger("DllExportAnalyzer", verbose=True)
output_log = logging.getLogger("output_log")
output_log.setLevel(logging.INFO)
error_log = logging.getLogger("error_log")
error_log.setLevel(logging.ERROR)

# Add file handlers
output_handler = logging.FileHandler(LOGS_DIR / "output.log")
output_handler.setFormatter(logging.Formatter('%(asctime)s [%(levelname)s] %(message)s'))
output_log.addHandler(output_handler)

error_handler = logging.FileHandler(LOGS_DIR / "errors.log")
error_handler.setFormatter(logging.Formatter('%(asctime)s [%(levelname)s] %(message)s'))
error_log.addHandler(error_handler)

# Prevent duplicate messages to console
output_log.propagate = False
error_log.propagate = False


class DllExportAnalyzer:
    """Tests all exports from any DLL using multiple invocation methods"""
    
    def __init__(self, dll_path: Path):
        """Initialize the analyzer"""
        self.dll_path = dll_path
        self.exports = []
        self.results = {
            "dll_path": str(dll_path),
            "exports_tested": 0,
            "successful_invocations": 0,
            "failed_invocations": 0,
            "by_engine": {
                "rundll32": {"success": 0, "failure": 0},
                "ctypes": {"success": 0, "failure": 0},
                "c_harness": {"success": 0, "failure": 0},
                "debugger": {"success": 0, "failure": 0},
            },
            "errors": []
        }
        
        # Initialize components
        self.validator = DLLValidator(logger)
        self.engine = InvocationEngine(logger)
        self.procmon = ProcmonMonitor(output_dir=str(OUTPUT_DIR), logger=logger)
    
    def analyze_dll(self) -> Dict[str, Any]:
        """Analyze the DLL structure and exports"""
        logger.info(f"Analyzing {self.dll_path}")
        output_log.info(f"Starting analysis of {self.dll_path}")
        
        try:
            # Validate DLL structure
            structure_info = self.validator.validate(str(self.dll_path))
            
            # Extract exports - try multiple methods to ensure we get exports
            if "pe_info" in structure_info and "exports" in structure_info["pe_info"] and structure_info["pe_info"]["exports"]:
                self.exports = structure_info["pe_info"]["exports"]
                logger.info(f"Extracted {len(self.exports)} exports using PE parsing")
            else:
                # Try using invocation engine's export listing
                logger.info(f"PE parsing didn't yield exports, trying InvocationEngine...")
                try:
                    self.exports = self.engine.list_exports(str(self.dll_path))
                    logger.info(f"Extracted {len(self.exports)} exports using InvocationEngine")
                except Exception as e:
                    logger.error(f"Error extracting exports with InvocationEngine: {str(e)}")
                    
                # If still no exports, try dumpbin as a last resort
                if not self.exports:
                    logger.info("Attempting to extract exports using dumpbin...")
                    try:
                        self.exports = self._extract_exports_dumpbin()
                        logger.info(f"Extracted {len(self.exports)} exports using dumpbin")
                    except Exception as e:
                        logger.error(f"Error extracting exports with dumpbin: {str(e)}")
            
            # Log results
            if self.exports:
                output_log.info(f"Found {len(self.exports)} exports in {self.dll_path.name}")
                logger.info(f"Found {len(self.exports)} exports")
                return structure_info
            else:
                error_msg = "No exports found in DLL using multiple extraction methods"
                logger.error(error_msg)
                error_log.error(error_msg)
                return {"error": error_msg}
                
        except Exception as e:
            logger.error(f"Error analyzing DLL: {str(e)}")
            error_log.error(f"Error analyzing DLL: {str(e)}")
            return {"error": str(e)}
    
    def _extract_exports_dumpbin(self) -> List[Dict[str, Any]]:
        """
        Extract exports using dumpbin utility as a fallback method
        
        Returns:
            List of dictionaries containing export information
        """
        try:
            # Create temporary directory
            import tempfile
            temp_dir = tempfile.mkdtemp()
            
            # Create dumpbin command
            dumpbin_cmd = ["dumpbin", "/EXPORTS", str(self.dll_path)]
            
            # Run dumpbin
            logger.info(f"Running command: {' '.join(dumpbin_cmd)}")
            result = subprocess.run(dumpbin_cmd, capture_output=True, text=True)
            
            if result.returncode != 0:
                logger.error(f"Dumpbin failed: {result.stderr}")
                return []
            
            # Parse output
            exports = []
            in_export_section = False
            
            for line in result.stdout.splitlines():
                line = line.strip()
                
                # Find export section
                if "ordinal hint RVA" in line.lower() and "name" in line.lower():
                    in_export_section = True
                    continue
                
                if in_export_section and line and not line.startswith("----"):
                    # Parse export line
                    parts = line.split()
                    if len(parts) >= 4:
                        try:
                            # Extract ordinal and name
                            ordinal = int(parts[0])
                            name = parts[3]
                            
                            exports.append({
                                "name": name,
                                "ordinal": ordinal
                            })
                        except (ValueError, IndexError) as e:
                            logger.warning(f"Error parsing export line '{line}': {str(e)}")
            
            return exports
            
        except Exception as e:
            logger.error(f"Error extracting exports with dumpbin: {str(e)}")
            return []
    
    def _is_stdcall_compatible(self, export_name: str) -> bool:
        """
        Determine if function is likely compatible with rundll32 stdcall convention
        
        Args:
            export_name: Name of the function
            
        Returns:
            True if likely compatible with rundll32, False otherwise
        """
        # Functions not suitable for rundll32
        if not export_name or not isinstance(export_name, str):
            return False
            
        # Exclude functions with special naming patterns
        excluded_patterns = [
            # Internal/private functions typically start with underscore
            lambda n: n.startswith('_'),
            
            # Decorated C++ names
            lambda n: '@@' in n,
            
            # Functions with calling convention hints
            lambda n: '@' in n and any(c.isdigit() for c in n),
            
            # C++ mangled names
            lambda n: n.startswith('?') and ('@@' in n or '?' in n[1:]),
            
            # Private implementation details
            lambda n: 'Internal' in n or 'Impl' in n or '_impl' in n,
            
            # Common patterns for data exports (not functions)
            lambda n: any(n.endswith(s) for s in ['_data', 'Data', 'TABLE', '_table']),
        ]
        
        for pattern in excluded_patterns:
            if pattern(export_name):
                return False
        
        # Include if name suggests it's a typical Win32 API function
        # Common Win32 API naming patterns with verb prefixes
        win32_patterns = [
            'Create', 'Get', 'Set', 'Initialize', 'Open', 'Close', 'Read', 'Write',
            'Alloc', 'Free', 'Lock', 'Unlock', 'Start', 'Stop', 'Register', 'Unregister',
            'Connect', 'Disconnect', 'Find', 'Enum', 'Query', 'Send', 'Receive'
        ]
        
        for pattern in win32_patterns:
            if pattern in export_name:
                return True
                
        # If name is a simple function name with proper casing (not all lowercase or uppercase)
        # and contains both upper and lowercase characters (typical for exported functions),
        # it might be compatible
        if (not export_name.islower() and not export_name.isupper() and 
            any(c.isupper() for c in export_name) and 
            any(c.islower() for c in export_name) and
            len(export_name) > 2):
            return True
            
        # Default to False for safety - other methods will be used
        return False
    
    def _select_invocation_engine(self, export_info: Dict[str, Any]) -> str:
        """
        Select the appropriate invocation engine for a given export
        
        Args:
            export_info: Dictionary with export information
            
        Returns:
            Engine name: "rundll32", "ctypes", "c_harness", or "debugger"
        """
        export_name = export_info.get("name", "")
        
        # If name is empty or non-string, use ctypes
        if not export_name or not isinstance(export_name, str):
            return "ctypes"
        
        # High-risk functions should use the debugger approach
        if self._is_high_risk_function(export_name):
            return "debugger"
        
        # For stdcall compatible exports, try rundll32 first
        if self._is_stdcall_compatible(export_name):
            return "rundll32"
        
        # For functions with known parameter types, use ctypes
        if self._get_param_types(export_name):
            return "ctypes"
            
        # For C++ exports or complex functions, use C harness
        if ('@@' in export_name or 
            export_name.startswith('?') or 
            any(t in export_name.lower() for t in ['class', 'object', 'instance'])):
            return "c_harness"
        
        # Default to ctypes for other cases
        return "ctypes"
    
    def invoke_export_rundll32(self, export_name: str) -> Dict[str, Any]:
        """Invoke an export using rundll32"""
        output_log.info(f"Invoking {export_name} via rundll32")
        
        try:
            # Start monitoring
            self.procmon.start_monitoring()
            
            # Prepare command
            cmd = ["rundll32.exe", str(self.dll_path), export_name]
            
            # Execute with monitoring
            start_time = time.time()
            process = subprocess.Popen(cmd, 
                                      stdout=subprocess.PIPE, 
                                      stderr=subprocess.PIPE)
            
            # Wait for process to complete (with timeout)
            try:
                stdout, stderr = process.communicate(timeout=10)
                return_code = process.returncode
            except subprocess.TimeoutExpired:
                process.kill()
                stdout, stderr = process.communicate()
                return_code = -1
                error_log.error(f"Timeout invoking {export_name} via rundll32")
            
            # Stop monitoring
            self.procmon.stop_monitoring()
            
            # Process results
            execution_time = time.time() - start_time
            
            result = {
                "export": export_name,
                "engine": "rundll32",
                "return_code": return_code,
                "execution_time_ms": round(execution_time * 1000, 2),
                "stdout": stdout.decode('utf-8', errors='replace').strip(),
                "stderr": stderr.decode('utf-8', errors='replace').strip(),
                "success": return_code == 0 and not stderr
            }
            
            # Export procmon data
            try:
                csv_file = self.procmon.export_to_csv()
                if csv_file:
                    result["procmon_csv"] = csv_file
            except Exception as e:
                logger.warning(f"Failed to export Procmon data: {e}")
            
            return result
            
        except Exception as e:
            self.procmon.stop_monitoring()
            error_msg = f"Error invoking {export_name} via rundll32: {str(e)}"
            logger.error(error_msg)
            error_log.error(error_msg)
            return {
                "export": export_name,
                "engine": "rundll32",
                "success": False,
                "error": str(e)
            }
    
    def invoke_export_ctypes(self, export_name: str) -> Dict[str, Any]:
        """Invoke an export using ctypes"""
        output_log.info(f"Invoking {export_name} via ctypes")
        
        try:
            # Define parameter types for common msvcrt functions
            param_types = self._get_param_types(export_name)
            
            # Create safe arguments if we have param types
            args = self._create_safe_args(export_name, param_types) if param_types else []
            
            # Use our engine for ctypes invocation
            start_time = time.time()
            result = self.engine.invoke_function_ctypes(
                str(self.dll_path), 
                export_name,
                argtypes=param_types,
                args=args,
                timeout=10
            )
            execution_time = time.time() - start_time
            
            return {
                "export": export_name,
                "engine": "ctypes",
                "return_value": str(result),
                "execution_time_ms": round(execution_time * 1000, 2),
                "parameters": str(param_types) if param_types else "None",
                "args": str(args),
                "success": True
            }
            
        except Exception as e:
            error_msg = f"Error invoking {export_name} via ctypes: {str(e)}"
            logger.error(error_msg)
            error_log.error(error_msg)
            return {
                "export": export_name,
                "engine": "ctypes",
                "success": False,
                "error": str(e)
            }
    
    def _get_param_types(self, export_name: str) -> Optional[List[Any]]:
        """
        Get parameter types for a function using heuristics and common patterns
        
        Args:
            export_name: Name of the export
            
        Returns:
            List of ctypes parameter types or None if unknown
        """
        # Common function name patterns and their parameter signatures
        # This helps with common Win32 API and C runtime functions
        common_signatures = {
            # Memory management
            "alloc": [ctypes.c_size_t],
            "malloc": [ctypes.c_size_t],
            "calloc": [ctypes.c_size_t, ctypes.c_size_t],
            "realloc": [ctypes.c_void_p, ctypes.c_size_t],
            "free": [ctypes.c_void_p],
            "memcpy": [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_size_t],
            "memset": [ctypes.c_void_p, ctypes.c_int, ctypes.c_size_t],
            
            # String functions
            "strlen": [ctypes.c_char_p],
            "strcpy": [ctypes.c_char_p, ctypes.c_char_p],
            "strcat": [ctypes.c_char_p, ctypes.c_char_p],
            "strcmp": [ctypes.c_char_p, ctypes.c_char_p],
            "strstr": [ctypes.c_char_p, ctypes.c_char_p],
            
            # Wide string functions
            "wcslen": [ctypes.c_wchar_p],
            "wcscpy": [ctypes.c_wchar_p, ctypes.c_wchar_p],
            "wcscat": [ctypes.c_wchar_p, ctypes.c_wchar_p],
            "wcscmp": [ctypes.c_wchar_p, ctypes.c_wchar_p],
            
            # I/O functions
            "printf": [ctypes.c_char_p],
            "sprintf": [ctypes.c_char_p, ctypes.c_char_p],
            "fopen": [ctypes.c_char_p, ctypes.c_char_p],
            "fclose": [ctypes.c_void_p],
            "fread": [ctypes.c_void_p, ctypes.c_size_t, ctypes.c_size_t, ctypes.c_void_p],
            "fwrite": [ctypes.c_void_p, ctypes.c_size_t, ctypes.c_size_t, ctypes.c_void_p],
            "fseek": [ctypes.c_void_p, ctypes.c_long, ctypes.c_int],
            "ftell": [ctypes.c_void_p],
            
            # Time functions
            "time": [ctypes.c_void_p],
            "localtime": [ctypes.POINTER(ctypes.c_long)],
            "gmtime": [ctypes.POINTER(ctypes.c_long)],
            
            # Character classification
            "toupper": [ctypes.c_int],
            "tolower": [ctypes.c_int],
            "isalpha": [ctypes.c_int],
            "isdigit": [ctypes.c_int],
            "isalnum": [ctypes.c_int],
            
            # Math functions
            "abs": [ctypes.c_int],
            "labs": [ctypes.c_long],
            "fabs": [ctypes.c_double],
            "sqrt": [ctypes.c_double],
            "pow": [ctypes.c_double, ctypes.c_double],
            "sin": [ctypes.c_double],
            "cos": [ctypes.c_double],
            "tan": [ctypes.c_double],
            
            # Win32 API common patterns
            "create": [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p],
            "get": [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p],
            "set": [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p],
            "query": [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p],
            "open": [ctypes.c_char_p, ctypes.c_int, ctypes.c_int],
            "close": [ctypes.c_void_p],
            "read": [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_uint, ctypes.POINTER(ctypes.c_uint)],
            "write": [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_uint, ctypes.POINTER(ctypes.c_uint)],
        }
        
        # First, normalize name by removing leading underscores and common prefixes
        normalized_name = export_name.lstrip('_')
        
        # Remove common prefixes
        prefixes = ["dll", "api", "win32", "win", "lib", "rtl", "nt", "zw"]
        for prefix in prefixes:
            if normalized_name.lower().startswith(prefix) and len(normalized_name) > len(prefix) + 1:
                if normalized_name[len(prefix)].isupper():
                    normalized_name = normalized_name[len(prefix):]
        
        # Check for exact function name match
        for func_name, param_types in common_signatures.items():
            if normalized_name.lower() == func_name.lower():
                return param_types
        
        # Check for function names containing pattern
        for pattern, param_types in common_signatures.items():
            if pattern.lower() in normalized_name.lower():
                # For common pattern matches, some additional validation
                # Make sure pattern is a significant part of the name not just a substring
                if len(pattern) >= 3 and (
                    normalized_name.lower().startswith(pattern.lower()) or
                    normalized_name.lower().endswith(pattern.lower()) or
                    len(pattern) / len(normalized_name) > 0.5
                ):
                    return param_types
        
        # Special handling for functions with A/W suffix (ANSI/Wide char versions)
        if normalized_name.endswith('A') and len(normalized_name) > 2:
            base_name = normalized_name[:-1]
            for func_name, param_types in common_signatures.items():
                if base_name.lower() == func_name.lower():
                    # Convert wchar params to char for ANSI versions
                    return [
                        ctypes.c_char_p if param == ctypes.c_wchar_p else param
                        for param in param_types
                    ]
        
        elif normalized_name.endswith('W') and len(normalized_name) > 2:
            base_name = normalized_name[:-1]
            for func_name, param_types in common_signatures.items():
                if base_name.lower() == func_name.lower():
                    # Convert char params to wchar for wide versions
                    return [
                        ctypes.c_wchar_p if param == ctypes.c_char_p else param
                        for param in param_types
                    ]
        
        # Heuristics for other functions
        if normalized_name.lower().startswith('get') and normalized_name.lower().endswith('size'):
            # GetXXXSize functions typically return size and take void* or similar
            return [ctypes.c_void_p]
            
        if normalized_name.lower().startswith('is') and len(normalized_name) > 3:
            # IsXXX functions typically take a single parameter
            return [ctypes.c_void_p]
            
        if normalized_name.lower().startswith('has') and len(normalized_name) > 4:
            # HasXXX functions typically take a single parameter
            return [ctypes.c_void_p]
        
        # No match found
        return None
    
    def _create_safe_args(self, export_name: str, param_types: List[Any]) -> List[Any]:
        """
        Create safe arguments for calling a function with more realistic test data
        
        Args:
            export_name: Name of the export
            param_types: List of parameter types
            
        Returns:
            List of safe argument values
        """
        args = []
        
        # Test data for string operations - include various patterns that might trigger behavior
        test_strings = [
            b"DLLAnalyzer test string",
            b"C:\\Windows\\System32\\test.txt",
            b"http://example.com/test",
            b"SELECT * FROM users",
            b"<script>alert('test')</script>",
            b"%TEMP%\\test.log",
            b"HKEY_LOCAL_MACHINE\\Software\\Test",
            b"--help"
        ]
        
        # Default test string
        test_string = test_strings[0]
        
        # Test data for wide strings
        test_wstrings = [s.decode('utf-8') for s in test_strings]
        test_wstring = test_wstrings[0]
        
        # Memory allocations to track
        memory_allocations = []
        
        # Buffer for holding temporary data
        temp_data_buffer = ctypes.create_string_buffer(1024)
        
        for i, param_type in enumerate(param_types):
            # Choose appropriate argument based on parameter type
            
            # String parameters
            if param_type == ctypes.c_char_p:
                # Vary test string based on function name to detect different behaviors
                lower_name = export_name.lower()
                
                if any(term in lower_name for term in ['file', 'open', 'path', 'directory']):
                    # File-related function - test with file paths
                    test_string = test_strings[1]  # Path
                elif any(term in lower_name for term in ['url', 'http', 'connect', 'web']):
                    # Network-related function - test with URL
                    test_string = test_strings[2]  # URL
                elif any(term in lower_name for term in ['sql', 'query', 'database']):
                    # Database-related function
                    test_string = test_strings[3]  # SQL
                elif any(term in lower_name for term in ['html', 'xml', 'parse']):
                    # HTML/XML parsing
                    test_string = test_strings[4]  # HTML
                elif any(term in lower_name for term in ['log', 'write']):
                    # Logging functions
                    test_string = test_strings[5]  # Log file path
                elif any(term in lower_name for term in ['reg', 'registry']):
                    # Registry operations
                    test_string = test_strings[6]  # Registry path
                elif any(term in lower_name for term in ['command', 'arg', 'option']):
                    # Command line operations
                    test_string = test_strings[7]  # Command line arg
                    
                string_buffer = ctypes.create_string_buffer(test_string)
                args.append(string_buffer)
                logger.debug(f"Using test string for {export_name}: {test_string}")
                
            # Wide string parameters
            elif param_type == ctypes.c_wchar_p:
                # Use same logic as char_p but with wide strings
                lower_name = export_name.lower()
                
                if any(term in lower_name for term in ['file', 'open', 'path', 'directory']):
                    test_wstring = test_wstrings[1]
                elif any(term in lower_name for term in ['url', 'http', 'connect', 'web']):
                    test_wstring = test_wstrings[2]
                
                wstring_buffer = ctypes.create_unicode_buffer(test_wstring)
                args.append(wstring_buffer)
                logger.debug(f"Using test wide string for {export_name}: {test_wstring}")
                
            # Integer parameters with realistic values based on context
            elif param_type in (ctypes.c_int, ctypes.c_long, ctypes.c_uint, ctypes.c_ulong):
                # Choose value based on function context
                lower_name = export_name.lower()
                
                if 'size' in lower_name or 'length' in lower_name:
                    # Size or length parameter
                    args.append(1024)  # Common buffer size
                elif 'index' in lower_name or 'position' in lower_name:
                    # Index or position
                    args.append(0)  # Start position
                elif 'flag' in lower_name or 'option' in lower_name or 'mode' in lower_name:
                    # Flag or option parameter
                    args.append(1)  # Typically 1 is a valid flag
                elif 'count' in lower_name:
                    # Count parameter
                    args.append(10)  # Small count
                else:
                    # Default integer value
                    args.append(1)
                    
            # Size parameters - use realistic sizes
            elif param_type == ctypes.c_size_t:
                if 'alloc' in export_name.lower() or 'malloc' in export_name.lower():
                    # Memory allocation - use moderate size
                    args.append(4096)  # 4KB - common allocation size
                else:
                    # Default size
                    args.append(1024)
                    
            # Float/double parameters
            elif param_type in (ctypes.c_float, ctypes.c_double):
                # Use 1.0 as a safe value
                args.append(1.0)
                
            # Function pointers (callbacks)
            elif hasattr(param_type, '_type_') and param_type._type_.__name__.startswith('CFUNCTYPE'):
                # For callback functions, create a dummy callback of appropriate type
                def dummy_callback(*args):
                    logger.debug(f"Dummy callback called with args: {args}")
                    return 0
                
                callback = param_type(dummy_callback)
                args.append(callback)
                
            # Pointer types
            elif hasattr(param_type, '_type_'):
                # For pointer types, allocate memory of the appropriate type
                pointed_type = param_type._type_
                if pointed_type == ctypes.c_char:
                    # Char buffer for string output
                    buffer = ctypes.create_string_buffer(256)
                    args.append(ctypes.cast(buffer, param_type))
                    memory_allocations.append(buffer)  # Keep reference
                elif pointed_type == ctypes.c_wchar:
                    # WChar buffer for wide string output
                    buffer = ctypes.create_unicode_buffer(128)
                    args.append(ctypes.cast(buffer, param_type))
                    memory_allocations.append(buffer)  # Keep reference
                else:
                    # For other pointer types, create an instance of the pointed type
                    try:
                        instance = pointed_type()
                        args.append(ctypes.pointer(instance))
                        memory_allocations.append(instance)  # Keep reference
                    except (TypeError, AttributeError):
                        # If we can't instantiate, use NULL pointer
                        args.append(None)
                
            # Void pointer parameters
            elif param_type == ctypes.c_void_p:
                # For memory functions that need a valid pointer
                if export_name.lower() in ("free", "realloc"):
                    # For free/realloc, need previously allocated memory
                    try:
                        # Try to get malloc function and use it
                        malloc_func = self.engine.get_function_pointer(
                            str(self.dll_path), "malloc", [ctypes.c_size_t], ctypes.c_void_p
                        )
                        if malloc_func:
                            ptr = malloc_func(16)
                            memory_allocations.append(ptr)  # Keep track for cleanup
                            args.append(ptr)
                        else:
                            # If malloc not found, use a dummy buffer
                            args.append(ctypes.cast(temp_data_buffer, ctypes.c_void_p))
                    except Exception as e:
                        logger.debug(f"Error getting malloc: {str(e)}")
                        # Use NULL pointer as fallback
                        args.append(None)
                else:
                    # For general purpose void* parameters, use a data buffer
                    args.append(ctypes.cast(temp_data_buffer, ctypes.c_void_p))
                    
            # Handle pointer by reference (output parameters common in Win32 API)
            elif "LP" in str(param_type) or "P" in str(param_type):
                # For output parameters (LPDWORD, etc.)
                try:
                    # Try to create an output parameter
                    if "DWORD" in str(param_type) or "ULONG" in str(param_type):
                        buffer = ctypes.c_ulong()
                    elif "LONG" in str(param_type):
                        buffer = ctypes.c_long()
                    elif "WORD" in str(param_type) or "SHORT" in str(param_type):
                        buffer = ctypes.c_ushort()
                    elif "BYTE" in str(param_type):
                        buffer = ctypes.c_ubyte()
                    elif "BOOL" in str(param_type):
                        buffer = ctypes.c_bool()
                    else:
                        # Generic pointer
                        buffer = ctypes.c_void_p()
                        
                    args.append(ctypes.byref(buffer))
                    memory_allocations.append(buffer)  # Keep reference
                except Exception:
                    # Fallback to None for unknown types
                    args.append(None)
                
            # Default to None for unknown types
            else:
                args.append(None)
        
        # Store memory allocations for potential cleanup
        self._memory_to_cleanup = memory_allocations
        
        return args
    
    def invoke_export_c_harness(self, export_name: str) -> Dict[str, Any]:
        """
        Invoke an export using a C harness
        
        Generates a simple C program that calls the export function with
        appropriate safety measures, compiles and executes it.
        """
        output_log.info(f"Invoking {export_name} via C harness")
        
        # Skip certain dangerous or complex functions
        dangerous_functions = ["system", "_wsystem", "remove", "rename"]
        if export_name in dangerous_functions:
            return {
                "export": export_name,
                "engine": "c_harness",
                "success": False,
                "error": "Function potentially dangerous, skipped"
            }
        
        try:
            # Create harness directory
            harness_dir = OUTPUT_DIR / "harness"
            os.makedirs(harness_dir, exist_ok=True)
            
            # Generate unique filename for this export
            timestamp = int(time.time())
            c_file = harness_dir / f"{export_name}_{timestamp}.c"
            exe_file = harness_dir / f"{export_name}_{timestamp}.exe"
            
            # Generate C code
            c_code = self._generate_c_harness(export_name)
            
            # Write C file
            with open(c_file, "w") as f:
                f.write(c_code)
            
            # Compile the C file
            output_log.info(f"Compiling C harness for {export_name}")
            compile_cmd = [
                "cl.exe",
                "/nologo",
                "/W4",  # Warning level 4
                "/EHsc",  # Enable exception handling
                "/Fo" + str(harness_dir),  # Output directory
                "/Fe" + str(exe_file),  # Output executable
                str(c_file)
            ]
            
            # Try to compile
            try:
                process = subprocess.Popen(
                    compile_cmd,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE
                )
                stdout, stderr = process.communicate(timeout=30)
                
                if process.returncode != 0:
                    return {
                        "export": export_name,
                        "engine": "c_harness",
                        "success": False,
                        "error": f"Compilation failed: {stderr.decode('utf-8', errors='replace')}"
                    }
                
            except subprocess.TimeoutExpired:
                return {
                    "export": export_name,
                    "engine": "c_harness",
                    "success": False,
                    "error": "Compilation timed out"
                }
            except Exception as e:
                return {
                    "export": export_name,
                    "engine": "c_harness",
                    "success": False,
                    "error": f"Compilation error: {str(e)}"
                }
            
            # Start monitoring
            self.procmon.start_monitoring()
            
            # Run the executable
            output_log.info(f"Running C harness for {export_name}")
            try:
                start_time = time.time()
                process = subprocess.Popen(
                    [str(exe_file)],
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE
                )
                stdout, stderr = process.communicate(timeout=10)
                execution_time = time.time() - start_time
                
                # Stop monitoring
                self.procmon.stop_monitoring()
                
                # Export procmon data
                csv_file = None
                try:
                    csv_file = self.procmon.export_to_csv()
                except Exception as e:
                    logger.warning(f"Failed to export Procmon data: {e}")
                
                return {
                    "export": export_name,
                    "engine": "c_harness",
                    "return_code": process.returncode,
                    "execution_time_ms": round(execution_time * 1000, 2),
                    "stdout": stdout.decode('utf-8', errors='replace').strip(),
                    "stderr": stderr.decode('utf-8', errors='replace').strip(),
                    "procmon_csv": csv_file,
                    "c_file": str(c_file),
                    "success": process.returncode == 0
                }
                
            except subprocess.TimeoutExpired:
                process.kill()
                self.procmon.stop_monitoring()
                return {
                    "export": export_name,
                    "engine": "c_harness",
                    "success": False,
                    "error": "Execution timed out",
                    "c_file": str(c_file)
                }
            
        except Exception as e:
            if self.procmon.is_monitoring:
                self.procmon.stop_monitoring()
            
            error_msg = f"Error creating C harness for {export_name}: {str(e)}"
            logger.error(error_msg)
            error_log.error(error_msg)
            return {
                "export": export_name,
                "engine": "c_harness",
                "success": False,
                "error": str(e)
            }
    
    def _generate_c_harness(self, export_name: str) -> str:
        """
        Generate C code to safely call a function from msvcrt.dll
        
        Args:
            export_name: Name of the export function
            
        Returns:
            C code as a string
        """
        # Get parameter types for function
        param_types = self._get_param_types(export_name)
        
        # Determine return type - default to int for unknown functions
        return_type = "int"
        if export_name in ["malloc", "calloc", "realloc"]:
            return_type = "void*"
        elif export_name in ["fabs", "sqrt", "pow"]:
            return_type = "double"
        elif export_name in ["time"]:
            return_type = "time_t"
        
        # Create prototype based on parameter types
        parameters = []
        param_init = []
        param_names = []
        
        if param_types:
            for i, param_type in enumerate(param_types):
                param_name = f"param{i+1}"
                param_names.append(param_name)
                
                if param_type == ctypes.c_char_p:
                    parameters.append(f"const char* {param_name}")
                    param_init.append(f'    const char* {param_name} = "DLLAnalyzer";')
                elif param_type == ctypes.c_void_p:
                    parameters.append(f"void* {param_name}")
                    # For input void* parameters, use NULL
                    param_init.append(f"    void* {param_name} = NULL;")
                elif param_type == ctypes.c_size_t:
                    parameters.append(f"size_t {param_name}")
                    param_init.append(f"    size_t {param_name} = 16;")
                elif param_type in (ctypes.c_int, ctypes.c_long):
                    parameters.append(f"int {param_name}")
                    param_init.append(f"    int {param_name} = 1;")
                elif param_type in (ctypes.c_float, ctypes.c_double):
                    parameters.append(f"double {param_name}")
                    param_init.append(f"    double {param_name} = 1.0;")
                else:
                    # Default to void* for unknown types
                    parameters.append(f"void* {param_name}")
                    param_init.append(f"    void* {param_name} = NULL;")
        
        # Create parameter string for function call
        call_params = ", ".join(param_names)
        
        # Generate the C code
        c_code = f"""/**
 * Auto-generated C harness for testing {export_name} in msvcrt.dll
 * Generated by DLL Analyzer
 */

#include <stdio.h>
#include <stdlib.h>
#include <windows.h>
#include <time.h>

// Function prototype
typedef {return_type} (*{export_name}_func)({", ".join(parameters)});

int main() {{
    // Set up exception handling
    __try {{
        // Load the DLL
        HMODULE hModule = LoadLibrary("msvcrt.dll");
        if (!hModule) {{
            printf("Failed to load msvcrt.dll, error: %d\\n", GetLastError());
            return 1;
        }}
        
        // Get function pointer
        {export_name}_func func = ({export_name}_func)GetProcAddress(hModule, "{export_name}");
        if (!func) {{
            printf("Failed to get address of {export_name}, error: %d\\n", GetLastError());
            FreeLibrary(hModule);
            return 2;
        }}
        
        // Initialize parameters
{"\\n".join(param_init)}
        
        // Call the function
        printf("Calling {export_name}...\\n");
        {return_type} result = func({call_params});
        
        // Print result (for some types)
        if ("{return_type}" == "int" || "{return_type}" == "size_t") {{
            printf("Result: %d\\n", (int)result);
        }} else if ("{return_type}" == "double") {{
            printf("Result: %f\\n", (double)result);
        }} else if ("{return_type}" == "void*") {{
            printf("Result pointer: %p\\n", result);
            // Free memory if allocated
            if (result && ("{export_name}" == "malloc" || "{export_name}" == "calloc" || "{export_name}" == "realloc")) {{
                free(result);
            }}
        }}
        
        // Clean up
        FreeLibrary(hModule);
        printf("{export_name} executed successfully!\\n");
        return 0;
    }}
    __except(EXCEPTION_EXECUTE_HANDLER) {{
        printf("Exception occurred while executing {export_name}: %d\\n", GetExceptionCode());
        return -1;
    }}
}}
"""
        return c_code
    
    def invoke_export_debugger(self, export_name: str) -> Dict[str, Any]:
        """
        Invoke an export using a debugger approach
        
        This is a simplified approach using Windows Debug API rather than
        a full x64dbg integration, which would require more setup. We create
        a minimal process and attach to it to control execution.
        """
        output_log.info(f"Invoking {export_name} via debugger")
        
        # Check if we should use this method
        if not self._is_high_risk_function(export_name):
            return {
                "export": export_name,
                "engine": "debugger",
                "success": False,
                "error": "Debugger method reserved for high-risk functions only"
            }
        
        try:
            # Create a debug harness file
            harness_dir = OUTPUT_DIR / "debugger"
            os.makedirs(harness_dir, exist_ok=True)
            
            # Generate a PowerShell script that uses WinDbg to call the function
            script_file = self._generate_windbg_script(export_name, harness_dir)
            
            # Start monitoring
            self.procmon.start_monitoring()
            
            # Run the script
            output_log.info(f"Running WinDbg script for {export_name}")
            start_time = time.time()
            
            try:
                process = subprocess.Popen(
                    ["powershell.exe", "-ExecutionPolicy", "Bypass", "-File", str(script_file)],
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE
                )
                stdout, stderr = process.communicate(timeout=30)
                execution_time = time.time() - start_time
                
                # Stop monitoring
                self.procmon.stop_monitoring()
                
                # Export procmon data
                csv_file = None
                try:
                    csv_file = self.procmon.export_to_csv()
                except Exception as e:
                    logger.warning(f"Failed to export Procmon data: {e}")
                
                return {
                    "export": export_name,
                    "engine": "debugger",
                    "return_code": process.returncode,
                    "execution_time_ms": round(execution_time * 1000, 2),
                    "stdout": stdout.decode('utf-8', errors='replace').strip(),
                    "stderr": stderr.decode('utf-8', errors='replace').strip(),
                    "script_file": str(script_file),
                    "procmon_csv": csv_file,
                    "success": process.returncode == 0 and "Exception" not in stdout.decode('utf-8', errors='replace')
                }
                
            except subprocess.TimeoutExpired:
                process.kill()
                self.procmon.stop_monitoring()
                return {
                    "export": export_name,
                    "engine": "debugger",
                    "success": False,
                    "error": "Execution timed out",
                    "script_file": str(script_file)
                }
                
        except Exception as e:
            if self.procmon.is_monitoring:
                self.procmon.stop_monitoring()
                
            error_msg = f"Error using debugger for {export_name}: {str(e)}"
            logger.error(error_msg)
            error_log.error(error_msg)
            return {
                "export": export_name,
                "engine": "debugger",
                "success": False,
                "error": str(e)
            }
    
    def _is_high_risk_function(self, export_name: str) -> bool:
        """
        Determine if a function is high risk and should use debugger
        
        Args:
            export_name: Function name
            
        Returns:
            True if high risk, False otherwise
        """
        # Known high-risk operations that should use debugger
        high_risk_patterns = [
            # System operations
            'system', 'exec', 'spawn', 'command', 'shell',
            
            # Process operations
            'process', 'createproc', 'launch', 'run',
            
            # File operations that might be dangerous
            'delete', 'remove', 'rmdir', 'unlink',
            'rename', 'move',
            
            # Registry operations
            'registry', 'reg', 'hkey',
            
            # Network operations
            'socket', 'connect', 'listen', 'accept', 'bind',
            'http', 'ftp', 'smtp', 'dns',
            
            # Memory manipulation
            'virtualalloc', 'virtualprot', 'memcpy', 'writeproc',
            
            # Injection techniques
            'inject', 'hook', 'detour', 'patch',
            
            # Persistence
            'startup', 'scheduled', 'task', 'service',
        ]
        
        # Check function name against high-risk patterns
        name_lower = export_name.lower()
        for pattern in high_risk_patterns:
            if pattern in name_lower:
                return True
                
        return False
    
    def _generate_windbg_script(self, export_name: str, output_dir: Path) -> Path:
        """
        Generate a PowerShell script that uses WinDbg to call a function
        
        Args:
            export_name: Function to call
            output_dir: Output directory
            
        Returns:
            Path to the generated script file
        """
        timestamp = int(time.time())
        script_file = output_dir / f"{export_name}_{timestamp}.ps1"
        log_file = output_dir / f"{export_name}_{timestamp}.log"
        
        # Simple script that creates a process, attaches WinDbg, and executes a command
        script_content = f"""
# PowerShell script to call {export_name} safely using WinDbg
$logFile = "{log_file}"

# Create a dummy process to attach to
$notepadProcess = Start-Process notepad -PassThru

try {{
    # Give notepad time to start
    Start-Sleep -Seconds 2
    
    # Create a temporary WinDbg command file
    $dbgCommandFile = [System.IO.Path]::GetTempFileName()
    
    # Write commands to the file
    @"
.load msvcrt.dll
.sympath+ c:\\windows\\symbols
.reload
? msvcrt!{export_name}
.echo Calling {export_name}...
$$>a< "{{$dbgCommandFile}}"
.echo Function call completed
q
"@ | Out-File -FilePath $dbgCommandFile -Encoding ascii
    
    # Call WinDbg with the command file
    $windbgOutput = & cdb -p $notepadProcess.Id -c "`$<$dbgCommandFile" 2>&1
    
    # Log the output
    $windbgOutput | Out-File -FilePath $logFile
    
    # Return the output
    $windbgOutput
}}
catch {{
    "Error executing WinDbg: $_" | Out-File -FilePath $logFile -Append
    throw $_
}}
finally {{
    # Clean up
    if ($notepadProcess -ne $null) {{
        try {{ Stop-Process -Id $notepadProcess.Id -Force -ErrorAction SilentlyContinue }} catch {{ }}
    }}
}}
"""
        
        with open(script_file, "w") as f:
            f.write(script_content)
        
        return script_file
    
    def invoke_export(self, export_info: Dict[str, Any]) -> Dict[str, Any]:
        """
        Invoke an export using the appropriate method
        
        Args:
            export_info: Dictionary with export information
            
        Returns:
            Dictionary with invocation results
        """
        export_name = export_info.get("name", "")
        if not export_name:
            error_msg = "Export name not provided"
            error_log.error(error_msg)
            return {"success": False, "error": error_msg}
        
        # Select invocation engine
        engine = self._select_invocation_engine(export_info)
        
        # Invoke using selected engine
        try:
            if engine == "rundll32":
                return self.invoke_export_rundll32(export_name)
            elif engine == "ctypes":
                return self.invoke_export_ctypes(export_name)
            elif engine == "c_harness":
                return self.invoke_export_c_harness(export_name)
            elif engine == "debugger":
                return self.invoke_export_debugger(export_name)
            else:
                error_msg = f"Unknown engine: {engine}"
                error_log.error(error_msg)
                return {"success": False, "error": error_msg}
                
        except Exception as e:
            error_msg = f"Error invoking {export_name}: {str(e)}"
            logger.error(error_msg)
            error_log.error(error_msg)
            return {
                "export": export_name,
                "engine": engine,
                "success": False,
                "error": str(e)
            }
    
    def test_all_exports(self, max_exports: Optional[int] = None) -> Dict[str, Any]:
        """
        Test all exports in the DLL
        
        Args:
            max_exports: Maximum number of exports to test (None for all)
            
        Returns:
            Dictionary with test results
        """
        if not self.exports:
            error_msg = "No exports found"
            logger.error(error_msg)
            error_log.error(error_msg)
            return {
                "success": False, 
                "error": error_msg,
                "exports_tested": 0,
                "successful_invocations": 0,
                "failed_invocations": 0
            }
        
        # Limit number of exports if requested
        exports_to_test = self.exports
        if max_exports is not None and max_exports > 0:
            exports_to_test = self.exports[:max_exports]
        
        # Process each export
        export_results = []
        for export in exports_to_test:
            export_name = export.get("name", "")
            logger.info(f"Testing export: {export_name}")
            
            result = self.invoke_export(export)
            export_results.append(result)
            
            # Update statistics
            self.results["exports_tested"] += 1
            
            if result.get("success", False):
                self.results["successful_invocations"] += 1
                self.results["by_engine"][result.get("engine", "unknown")]["success"] += 1
            else:
                self.results["failed_invocations"] += 1
                self.results["by_engine"][result.get("engine", "unknown")]["failure"] += 1
                self.results["errors"].append({
                    "export": export_name,
                    "engine": result.get("engine", "unknown"),
                    "error": result.get("error", "Unknown error")
                })
            
            # Log result
            if result.get("success", False):
                output_log.info(f"Successfully invoked {export_name} via {result.get('engine', 'unknown')}")
            else:
                error_log.error(f"Failed to invoke {export_name} via {result.get('engine', 'unknown')}: {result.get('error', 'Unknown error')}")
        
        # Summarize results
        self.results["export_results"] = export_results
        
        # Log summary
        output_log.info(f"Tested {self.results['exports_tested']} exports")
        output_log.info(f"Successful invocations: {self.results['successful_invocations']}")
        output_log.info(f"Failed invocations: {self.results['failed_invocations']}")
        
        return self.results
    
    def save_results(self, output_path: Optional[Path] = None) -> Path:
        """
        Save test results to JSON file
        
        Args:
            output_path: Path to save results (default: output_dir/msvcrt_test_results.json)
            
        Returns:
            Path to saved file
        """
        if output_path is None:
            output_path = OUTPUT_DIR / "msvcrt_test_results.json"
        
        with open(output_path, "w") as f:
            json.dump(self.results, f, indent=2)
        
        logger.info(f"Results saved to {output_path}")
        return output_path
    
    def analyze_failures(self) -> List[Dict[str, Any]]:
        """
        Analyze failures and suggest fixes
        
        Returns:
            List of dictionaries with failure details and suggested fixes
        """
        fixes = []
        
        for error in self.results["errors"]:
            export = error.get("export", "")
            engine = error.get("engine", "")
            error_msg = error.get("error", "")
            
            # Analyze error and suggest fix
            if "argument types" in error_msg.lower() or "parameters" in error_msg.lower():
                # Missing or incorrect parameter types
                param_types = self._get_param_types(export)
                if param_types:
                    fix_action = "update_param_types"
                    suggested_fix = f"Provide correct parameter types for {export}: {param_types}"
                else:
                    fix_action = "add_param_types"
                    suggested_fix = f"Add parameter type definition for {export} in _get_param_types method"
                
                fixes.append({
                    "export": export,
                    "engine": engine,
                    "error": error_msg,
                    "suggested_fix": suggested_fix,
                    "action": fix_action,
                    "severity": "medium"
                })
                
            elif "not found" in error_msg.lower() or "unable to find" in error_msg.lower():
                # Export not found
                fixes.append({
                    "export": export,
                    "engine": engine,
                    "error": error_msg,
                    "suggested_fix": f"Export {export} not found or not accessible, consider skipping",
                    "action": "skip_export",
                    "severity": "low"
                })
                
            elif any(crash_term in error_msg.lower() for crash_term in 
                    ["access violation", "segmentation fault", "exception", "crashed"]):
                # Crashes and exceptions
                fix_action = "use_safe_params"
                if engine == "rundll32":
                    suggested_fix = f"Export {export} crashed with rundll32 - try ctypes with safe parameters"
                    alt_engine = "ctypes"
                elif engine == "ctypes":
                    suggested_fix = f"Export {export} crashed with ctypes - try C harness with SEH"
                    alt_engine = "c_harness"
                else:
                    suggested_fix = f"Export {export} crashed - try debugger method for controlled execution"
                    alt_engine = "debugger"
                
                fixes.append({
                    "export": export,
                    "engine": engine,
                    "error": error_msg,
                    "suggested_fix": suggested_fix,
                    "action": fix_action,
                    "alternative_engine": alt_engine,
                    "severity": "high"
                })
                
            elif "timeout" in error_msg.lower():
                # Execution timeout
                fixes.append({
                    "export": export,
                    "engine": engine,
                    "error": error_msg,
                    "suggested_fix": f"Export {export} timed out - possible infinite loop or waiting for input",
                    "action": "increase_timeout",
                    "severity": "medium"
                })
                
            elif "invalid argument" in error_msg.lower() or "invalid parameter" in error_msg.lower():
                # Invalid arguments
                fixes.append({
                    "export": export,
                    "engine": engine,
                    "error": error_msg,
                    "suggested_fix": f"Export {export} received invalid arguments - update _create_safe_args logic",
                    "action": "fix_args",
                    "severity": "medium"
                })
                
            else:
                # Unknown errors
                fixes.append({
                    "export": export,
                    "engine": engine,
                    "error": error_msg,
                    "suggested_fix": f"Unknown error in {export} - try alternative invocation method",
                    "action": "try_alternative_engine",
                    "severity": "medium"
                })
        
        # Group and sort fixes by severity
        fixes.sort(key=lambda x: {
            "high": 0,
            "medium": 1,
            "low": 2
        }.get(x.get("severity", "medium"), 1))
        
        return fixes
    
    def apply_fixes(self, fixes: List[Dict[str, Any]]) -> Dict[str, Any]:
        """
        Apply fixes to failed exports and retry
        
        Args:
            fixes: List of fixes from analyze_failures
            
        Returns:
            Dictionary with fix results
        """
        fix_results = {
            "fixes_applied": 0,
            "successful_fixes": 0,
            "failed_fixes": 0,
            "fix_details": []
        }
        
        # Process each fix
        for fix in fixes:
            export = fix.get("export", "")
            action = fix.get("action", "")
            severity = fix.get("severity", "medium")
            
            logger.info(f"Applying fix for {export}: {fix.get('suggested_fix')}")
            output_log.info(f"Applying fix for {export}: {fix.get('suggested_fix')}")
            
            # Find the original export data
            export_data = None
            for exp in self.exports:
                if exp.get("name", "") == export:
                    export_data = exp
                    break
            
            if not export_data:
                logger.error(f"Could not find export data for {export}")
                fix_results["failed_fixes"] += 1
                fix_results["fix_details"].append({
                    "export": export,
                    "action": action,
                    "success": False,
                    "error": "Export data not found"
                })
                continue
                
            fix_results["fixes_applied"] += 1
            
            # Apply fix based on action
            if action == "skip_export":
                # Just skip this export
                fix_results["successful_fixes"] += 1
                fix_results["fix_details"].append({
                    "export": export,
                    "action": action,
                    "success": True,
                    "result": "Export skipped"
                })
                
            elif action == "try_alternative_engine":
                # Try an alternative engine
                alt_engine = fix.get("alternative_engine")
                if not alt_engine:
                    # Determine alternative engine
                    current_engine = fix.get("engine", "")
                    if current_engine == "rundll32":
                        alt_engine = "ctypes"
                    elif current_engine == "ctypes":
                        alt_engine = "c_harness"
                    else:
                        alt_engine = "debugger"
                
                # Invoke with alternative engine
                try:
                    if alt_engine == "rundll32":
                        result = self.invoke_export_rundll32(export)
                    elif alt_engine == "ctypes":
                        result = self.invoke_export_ctypes(export)
                    elif alt_engine == "c_harness":
                        result = self.invoke_export_c_harness(export)
                    elif alt_engine == "debugger":
                        result = self.invoke_export_debugger(export)
                    else:
                        raise ValueError(f"Unknown engine: {alt_engine}")
                    
                    if result.get("success", False):
                        fix_results["successful_fixes"] += 1
                        fix_results["fix_details"].append({
                            "export": export,
                            "action": action,
                            "success": True,
                            "alternative_engine": alt_engine,
                            "result": f"Successfully invoked with {alt_engine}"
                        })
                    else:
                        fix_results["failed_fixes"] += 1
                        fix_results["fix_details"].append({
                            "export": export,
                            "action": action,
                            "success": False,
                            "alternative_engine": alt_engine,
                            "error": result.get("error", "Unknown error")
                        })
                        
                except Exception as e:
                    fix_results["failed_fixes"] += 1
                    fix_results["fix_details"].append({
                        "export": export,
                        "action": action,
                        "success": False,
                        "alternative_engine": alt_engine,
                        "error": str(e)
                    })
            
            elif action in ["update_param_types", "add_param_types", "fix_args"]:
                # These require code changes and can't be applied automatically
                # Log that manual intervention is needed
                fix_results["failed_fixes"] += 1
                fix_results["fix_details"].append({
                    "export": export,
                    "action": action,
                    "success": False,
                    "error": "Manual code update required",
                    "required_changes": fix.get("suggested_fix")
                })
            
            else:
                # Unknown action
                fix_results["failed_fixes"] += 1
                fix_results["fix_details"].append({
                    "export": export,
                    "action": action,
                    "success": False,
                    "error": f"Unknown action: {action}"
                })
        
        return fix_results
    
    def generate_html_report(self, output_path: Optional[Path] = None) -> Path:
        """
        Generate an HTML report from test results
        
        Args:
            output_path: Optional path to save the HTML report
            
        Returns:
            Path to the generated HTML report
        """
        if output_path is None:
            output_path = OUTPUT_DIR / "msvcrt_test_report.html"
        
        # Calculate statistics
        total_exports = len(self.exports)
        tested_exports = self.results["exports_tested"]
        successful = self.results["successful_invocations"]
        failed = self.results["failed_invocations"]
        
        success_rate = (successful / tested_exports * 100) if tested_exports > 0 else 0
        
        # Prepare engine statistics
        engine_stats = []
        for engine, stats in self.results["by_engine"].items():
            total = stats["success"] + stats["failure"]
            if total > 0:
                success_rate_engine = (stats["success"] / total * 100)
                engine_stats.append({
                    "name": engine,
                    "total": total,
                    "success": stats["success"],
                    "failure": stats["failure"],
                    "success_rate": success_rate_engine
                })
        
        # Generate HTML
        html = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MSVCRT.DLL Test Results</title>
    <style>
        body {{
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            line-height: 1.6;
            color: #333;
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }}
        .header {{
            text-align: center;
            margin-bottom: 30px;
            padding-bottom: 20px;
            border-bottom: 1px solid #eee;
        }}
        .summary-box {{
            display: flex;
            justify-content: space-between;
            margin-bottom: 30px;
        }}
        .summary-item {{
            background-color: #f5f5f5;
            border-radius: 5px;
            padding: 20px;
            text-align: center;
            width: 22%;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }}
        .summary-item h3 {{
            margin-top: 0;
            font-size: 16px;
            color: #555;
        }}
        .summary-item .value {{
            font-size: 24px;
            font-weight: bold;
            margin: 10px 0;
        }}
        .success-rate {{
            color: hsl({min(success_rate * 1.2, 120)}, 70%, 45%);
        }}
        table {{
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 30px;
        }}
        th, td {{
            padding: 12px 15px;
            border-bottom: 1px solid #ddd;
            text-align: left;
        }}
        th {{
            background-color: #f8f9fa;
            font-weight: 600;
        }}
        tr:hover {{
            background-color: #f5f5f5;
        }}
        .success {{
            color: #28a745;
        }}
        .failure {{
            color: #dc3545;
        }}
        .engine-stats {{
            display: flex;
            justify-content: space-between;
            margin-bottom: 30px;
        }}
        .engine-item {{
            background-color: #f9f9f9;
            border-radius: 5px;
            padding: 15px;
            width: 22%;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
        }}
        .engine-item h3 {{
            margin-top: 0;
            text-transform: uppercase;
            font-size: 14px;
            color: #666;
        }}
        .error-box {{
            background-color: #fff5f5;
            border-left: 4px solid #dc3545;
            padding: 15px;
            margin-bottom: 15px;
            border-radius: 0 5px 5px 0;
        }}
        .fix-box {{
            background-color: #f0fff4;
            border-left: 4px solid #28a745;
            padding: 15px;
            margin-bottom: 15px;
            border-radius: 0 5px 5px 0;
        }}
        .section {{
            margin-bottom: 40px;
        }}
        .section h2 {{
            border-bottom: 2px solid #eee;
            padding-bottom: 10px;
            margin-top: 40px;
        }}
        footer {{
            text-align: center;
            margin-top: 50px;
            padding-top: 20px;
            border-top: 1px solid #eee;
            color: #777;
            font-size: 14px;
        }}
    </style>
</head>
<body>
    <div class="header">
        <h1>MSVCRT.DLL Test Results</h1>
        <p>Test conducted on {time.strftime("%Y-%m-%d %H:%M:%S")}</p>
    </div>
    
    <div class="summary-box">
        <div class="summary-item">
            <h3>Total Exports</h3>
            <div class="value">{total_exports}</div>
        </div>
        <div class="summary-item">
            <h3>Tested</h3>
            <div class="value">{tested_exports}</div>
        </div>
        <div class="summary-item">
            <h3>Successful</h3>
            <div class="value">{successful}</div>
        </div>
        <div class="summary-item">
            <h3>Success Rate</h3>
            <div class="value success-rate">{success_rate:.1f}%</div>
        </div>
    </div>
    
    <div class="section">
        <h2>Engine Performance</h2>
        <div class="engine-stats">
"""

        # Add engine statistics
        for engine in engine_stats:
            html += f"""
            <div class="engine-item">
                <h3>{engine['name']}</h3>
                <div><strong>Total:</strong> {engine['total']}</div>
                <div><strong>Success:</strong> <span class="success">{engine['success']}</span></div>
                <div><strong>Failed:</strong> <span class="failure">{engine['failure']}</span></div>
                <div><strong>Rate:</strong> {engine['success_rate']:.1f}%</div>
            </div>"""
        
        html += """
        </div>
    </div>
    
    <div class="section">
        <h2>Export Results</h2>
        <table>
            <tr>
                <th>Export Name</th>
                <th>Engine</th>
                <th>Status</th>
                <th>Execution Time</th>
                <th>Details</th>
            </tr>
"""

        # Add results for each export
        for result in self.results.get("export_results", []):
            export = result.get("export", "Unknown")
            engine = result.get("engine", "Unknown")
            success = result.get("success", False)
            status = '<span class="success">Success</span>' if success else '<span class="failure">Failed</span>'
            execution_time = result.get("execution_time_ms", 0)
            
            # Get details
            details = ""
            if success:
                return_value = result.get("return_value", "N/A")
                if return_value:
                    details = f"Return value: {return_value}"
            else:
                error = result.get("error", "Unknown error")
                details = f"Error: {error}"
            
            html += f"""
            <tr>
                <td>{export}</td>
                <td>{engine}</td>
                <td>{status}</td>
                <td>{execution_time} ms</td>
                <td>{details}</td>
            </tr>"""
        
        html += """
        </table>
    </div>
"""

        # Add error analysis section if there are errors
        if self.results.get("failed_invocations", 0) > 0:
            html += """
    <div class="section">
        <h2>Error Analysis</h2>
"""
            # Group errors by type
            error_types = {}
            for error in self.results.get("errors", []):
                error_msg = error.get("error", "Unknown error")
                if error_msg not in error_types:
                    error_types[error_msg] = []
                error_types[error_msg].append(error)
            
            # Show common errors and affected exports
            for error_msg, errors in error_types.items():
                # Skip if too many of the same error
                if len(errors) > 10:
                    affected_exports = [e.get("export", "Unknown") for e in errors[:5]]
                    export_list = ", ".join(affected_exports) + f" and {len(errors) - 5} more..."
                else:
                    affected_exports = [e.get("export", "Unknown") for e in errors]
                    export_list = ", ".join(affected_exports)
                
                html += f"""
        <div class="error-box">
            <h3>Error: {error_msg}</h3>
            <p><strong>Affected exports ({len(errors)}):</strong> {export_list}</p>
        </div>"""
            
            html += """
    </div>
"""

        # Add fixes section if there are fixes
        if hasattr(self, "fixes") and self.fixes:
            html += """
    <div class="section">
        <h2>Recommended Fixes</h2>
"""
            for fix in self.fixes:
                export = fix.get("export", "Unknown")
                suggestion = fix.get("suggested_fix", "No suggestion")
                severity = fix.get("severity", "medium")
                action = fix.get("action", "unknown")
                
                html += f"""
        <div class="fix-box">
            <h3>Fix for: {export}</h3>
            <p><strong>Suggestion:</strong> {suggestion}</p>
            <p><strong>Severity:</strong> {severity}</p>
            <p><strong>Action needed:</strong> {action}</p>
        </div>"""
            
            html += """
    </div>
"""

        # Close HTML document
        html += """
    <footer>
        <p>Generated by DLL Analyzer Framework - MSVCRT Tester</p>
    </footer>
</body>
</html>
"""
        
        # Write the HTML to file
        with open(output_path, "w") as f:
            f.write(html)
        
        logger.info(f"HTML report generated at {output_path}")
        return output_path


def ensure_msvcrt_dll():
    """
    Ensure msvcrt.dll exists in the testing_sample directory
    
    If not found, copy from Windows system directory
    """
    # Check if testing_sample directory exists
    testing_dir = Path("testing_sample")
    if not testing_dir.exists():
        os.makedirs(testing_dir)
    
    # Check if msvcrt.dll exists in testing directory
    msvcrt_path = testing_dir / "msvcrt.dll"
    if msvcrt_path.exists():
        logger.info(f"Using existing msvcrt.dll at {msvcrt_path}")
        return str(msvcrt_path)
    
    # Find msvcrt.dll in the system directory
    system_dir = os.environ.get("SystemRoot", "C:\\Windows") + "\\System32"
    system_msvcrt = Path(system_dir) / "msvcrt.dll"
    
    if not system_msvcrt.exists():
        logger.error(f"Could not find msvcrt.dll at {system_msvcrt}")
        raise FileNotFoundError(f"msvcrt.dll not found at {system_msvcrt}")
    
    # Copy the file
    import shutil
    logger.info(f"Copying msvcrt.dll from {system_msvcrt} to {msvcrt_path}")
    shutil.copy2(system_msvcrt, msvcrt_path)
    
    return str(msvcrt_path)


def get_common_msvcrt_exports():
    """
    Return a list of common msvcrt.dll exports for testing
    
    Used as a fallback when export extraction fails
    """
    # Common exports from msvcrt.dll
    common_exports = [
        {"name": "malloc", "ordinal": 1},
        {"name": "free", "ordinal": 2},
        {"name": "printf", "ordinal": 3},
        {"name": "fopen", "ordinal": 4},
        {"name": "fclose", "ordinal": 5},
        {"name": "strlen", "ordinal": 6},
        {"name": "strcpy", "ordinal": 7},
        {"name": "time", "ordinal": 8},
        {"name": "fwrite", "ordinal": 9},
        {"name": "fread", "ordinal": 10},
        {"name": "system", "ordinal": 11},
        {"name": "toupper", "ordinal": 12},
        {"name": "tolower", "ordinal": 13},
        {"name": "abs", "ordinal": 14},
        {"name": "atoi", "ordinal": 15},
        {"name": "atof", "ordinal": 16},
        {"name": "calloc", "ordinal": 17},
        {"name": "realloc", "ordinal": 18},
        {"name": "rand", "ordinal": 19},
        {"name": "srand", "ordinal": 20}
    ]
    
    return common_exports


def main():
    """Main entry point"""
    # Parse command line arguments
    import argparse
    parser = argparse.ArgumentParser(description="DLL Export Analyzer")
    parser.add_argument("dll_path", type=str, help="Path to the DLL file to analyze")
    parser.add_argument("--max-exports", type=int, default=0,
                      help="Maximum number of exports to test (default: 0 for all)")
    parser.add_argument("--html", action="store_true",
                      help="Generate HTML report")
    parser.add_argument("--output-dir", type=str, default=None,
                      help="Custom output directory (default: output/dll_analysis/DLLNAME)")
    parser.add_argument("--engine", choices=["all", "rundll32", "ctypes", "c_harness", "debugger"],
                      default="all", help="Invocation engine to use (default: all)")
    
    args = parser.parse_args()
    
    try:
        # Check if specified DLL exists
        dll_path = Path(args.dll_path)
        if not dll_path.exists():
            logger.error(f"Specified DLL not found: {dll_path}")
            sys.exit(1)
            
        # Set output directory
        if args.output_dir:
            global OUTPUT_DIR
            OUTPUT_DIR = Path(args.output_dir)
        else:
            # Use DLL name for the output directory
            dll_name = dll_path.stem
            OUTPUT_DIR = Path(f"output/dll_analysis/{dll_name}")
            
        os.makedirs(OUTPUT_DIR, exist_ok=True)
        
        logger.info(f"Starting DLL export analyzer for {dll_path}")
        output_log.info(f"Starting DLL export analyzer for {dll_path}")
        
        # Create analyzer
        analyzer = DllExportAnalyzer(dll_path)
        
        # Analyze DLL
        structure_info = analyzer.analyze_dll()
        if "error" in structure_info:
            logger.error(f"Analysis failed: {structure_info['error']}")
            sys.exit(1)
        
        # Check if we have exports to test
        if not analyzer.exports:
            logger.error("No exports found in DLL analysis")
            output_log.error("No exports found in DLL analysis")
            sys.exit(1)
            
        # Filter exports by engine if specified
        if args.engine != "all":
            logger.info(f"Filtering exports to use only {args.engine} engine")
            # Keep original count for reporting
            original_count = len(analyzer.exports)
            analyzer.exports = [
                export for export in analyzer.exports 
                if analyzer._select_invocation_engine(export) == args.engine
            ]
            logger.info(f"Filtered from {original_count} to {len(analyzer.exports)} exports")
        
        # Set max exports
        max_exports = None if args.max_exports == 0 else args.max_exports
        
        # Test exports
        results = analyzer.test_all_exports(max_exports=max_exports)
        
        # Save results
        results_path = analyzer.save_results()
        logger.info(f"Results saved to {results_path}")
        
        # Generate HTML report if requested
        if args.html:
            html_path = analyzer.generate_html_report()
            logger.info(f"HTML report generated at {html_path}")
            
            # Try to open the report in the default browser
            try:
                import webbrowser
                webbrowser.open(str(html_path))
            except Exception as e:
                logger.warning(f"Could not open HTML report in browser: {e}")
        
        logger.info("Testing complete")
        output_log.info(f"DLL analysis of {dll_path.name} completed")
        
        # Return success if at least some exports were tested successfully
        sys.exit(0 if results.get("successful_invocations", 0) > 0 else 1)
        
    except Exception as e:
        logger.error(f"Unexpected error: {str(e)}")
        error_log.error(f"Unexpected error: {str(e)}")
        sys.exit(1)

if __name__ == "__main__":
    main() 