"""
Configuration settings for the DLL Analyzer Framework
"""

import os
from pathlib import Path
from dotenv import load_dotenv

# Load environment variables from .env file if it exists
load_dotenv()

# Base paths
BASE_DIR = Path(__file__).resolve().parent
TOOLS_DIR = BASE_DIR / "tools"
OUTPUT_DIR = BASE_DIR / "output"
LOGS_DIR = BASE_DIR / "logs"

# External tools configuration
PROCMON_PATH = os.environ.get("PROCMON_PATH", str(TOOLS_DIR / "procmon" / "Procmon.exe"))
PROCMON_FILTER_PATH = os.environ.get("PROCMON_FILTER_PATH", str(TOOLS_DIR / "procmon" / "filters.pmc"))

# Analysis settings
DEFAULT_TIMEOUT = int(os.environ.get("DEFAULT_TIMEOUT", 60))
MAX_MEMORY_USAGE = int(os.environ.get("MAX_MEMORY_USAGE", 1024 * 1024 * 1024))  # 1GB default
SANDBOX_ENABLED = os.environ.get("SANDBOX_ENABLED", "True").lower() == "true"

# Monitoring settings
MONITOR_REGISTRY = os.environ.get("MONITOR_REGISTRY", "True").lower() == "true"
MONITOR_FILE_SYSTEM = os.environ.get("MONITOR_FILE_SYSTEM", "True").lower() == "true"
MONITOR_NETWORK = os.environ.get("MONITOR_NETWORK", "True").lower() == "true"
MONITOR_PROCESS = os.environ.get("MONITOR_PROCESS", "True").lower() == "true"

# API hooking configuration
API_HOOKS = {
    "file_operations": [
        "kernel32.dll!CreateFileW",
        "kernel32.dll!WriteFile",
        "kernel32.dll!ReadFile",
        "kernel32.dll!DeleteFileW",
        "kernel32.dll!CopyFileW",
        "kernel32.dll!MoveFileW",
    ],
    "registry_operations": [
        "advapi32.dll!RegOpenKeyExW",
        "advapi32.dll!RegCreateKeyExW",
        "advapi32.dll!RegSetValueExW",
        "advapi32.dll!RegDeleteValueW",
        "advapi32.dll!RegDeleteKeyW",
    ],
    "process_operations": [
        "kernel32.dll!CreateProcessW",
        "kernel32.dll!CreateProcessA",
        "kernel32.dll!CreateThread",
        "kernel32.dll!VirtualAlloc",
        "kernel32.dll!VirtualProtect",
    ],
    "network_operations": [
        "ws2_32.dll!socket",
        "ws2_32.dll!connect",
        "ws2_32.dll!send",
        "ws2_32.dll!recv",
        "wininet.dll!InternetOpenW",
        "wininet.dll!InternetConnectW",
        "wininet.dll!HttpOpenRequestW",
        "wininet.dll!HttpSendRequestW",
    ],
    "crypto_operations": [
        "advapi32.dll!CryptAcquireContextW",
        "advapi32.dll!CryptCreateHash",
        "advapi32.dll!CryptHashData",
        "advapi32.dll!CryptEncrypt",
        "advapi32.dll!CryptDecrypt",
    ],
}

# IOC detection thresholds
IOC_THRESHOLDS = {
    "suspicious_strings": 3,  # Number of suspicious strings to trigger alert
    "entropy_threshold": 7.0,  # Shannon entropy threshold for encrypted/packed sections
    "max_api_calls": 1000,  # Maximum number of API calls before considering suspicious
    "max_file_operations": 50,  # Maximum number of file operations before considering suspicious
    "max_registry_operations": 50,  # Maximum number of registry operations before considering suspicious
}

# Suspicious patterns
SUSPICIOUS_STRINGS = [
    "cmd.exe",
    "powershell",
    "wscript",
    "cscript",
    "regsvr32",
    "rundll32",
    "schtasks",
    "vssadmin",
    "bcdedit",
    "wmic",
]

# File paths to monitor closely
SENSITIVE_PATHS = [
    r"C:\Windows\System32",
    r"C:\Windows\SysWOW64",
    r"C:\Windows\Temp",
    r"C:\Users\*\AppData\Roaming\Microsoft\Windows\Start Menu\Programs\Startup",
    r"HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Run",
    r"HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Run",
]

# Logging configuration
LOG_LEVEL = os.environ.get("LOG_LEVEL", "INFO")
LOG_FORMAT = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
JSON_LOGS = os.environ.get("JSON_LOGS", "True").lower() == "true" 